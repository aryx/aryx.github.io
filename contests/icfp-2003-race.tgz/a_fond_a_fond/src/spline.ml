open Lib

type splineCubique = { a:float; b:float; c:float; d:float }

let (splineF: float -> float -> float array -> float array -> splineCubique array) = 
  fun df0 dfn x f ->
    let n=(Array.length x)-1 in
    let a=(Array.create (n+1) 0.) in
    let l=(Array.create (n+1) 0.) in
    let u=(Array.create (n+1) 0.) in
    let z=(Array.create (n+1) 0.) in
    let b=(Array.create (n+1) 0.) in
    let c=(Array.create (n+1) 0.) in
    let d=(Array.create (n+1) 0.) in
    let p=(Array.create n {a=0.; b=0.; c=0.; d=0.}) in
      a.(0) <- 3.*.(f.(1)-.f.(0))/.(x.(1)-.x.(0)) -. 3.*.df0;
      a.(n) <- 3.*.dfn-.3.*.(f.(n)-.f.(n-1))/.(x.(n)-.x.(n-1));
(* (9.*.f.(n-1)-.6.*.f.(n))/.(x.(n)-.x.(n-1)); *)
      for i=1 to (n-1) do
	a.(i) <- 3.*.(f.(i+1)*.(x.(i)-.x.(i-1))-.
		       	f.(i)*.(x.(i+1)-.x.(i-1))+.
		       	f.(i-1)*.(x.(i+1)-.x.(i)))/.
	  ((x.(i+1)-.x.(i))*.(x.(i)-.x.(i-1)))
      done;
      l.(0) <- 2.*.(x.(1)-.x.(0));
      u.(0) <- 0.5;
      z.(0) <- a.(0)/.(2.*.(x.(1)-.x.(0)));
      for i=1 to (n-1) do
	l.(i) <- 2.*.(x.(i+1)-.x.(i-1))-.(x.(i)-.x.(i-1))*.u.(i-1);
	u.(i) <- (x.(i+1)-.x.(i))/.l.(i);
	z.(i) <- (a.(i)-.(x.(i)-.x.(i-1))*.z.(i-1))/.l.(i)
      done;
      l.(n) <- (x.(n)-.x.(n-1))*.(2.-.u.(n-1));
      z.(n) <- (a.(n)-.(x.(n)-.x.(n-1))*.z.(n-1))/.l.(n);
      c.(n) <- z.(n);
      for j=(n-1) downto 0 do
	c.(j) <- z.(j)-.u.(j)*.c.(j+1);
	b.(j) <- (f.(j+1)-.f.(j))/.(x.(j+1)-.x.(j))-.
	           (x.(j+1)-.x.(j))*.(c.(j+1)+.2.*.c.(j))/.3.;
	d.(j) <- (c.(j+1)-.c.(j))/.(3.*.(x.(j+1)-.x.(j)))
      done;
      for i=0 to (n-1) do
	p.(i) <- {a=f.(i); b=b.(i); c=c.(i); d=d.(i)}
      done;
      p

let (norm: float*float -> float*float -> float) = 
  fun (xa,ya) (xb,yb) ->
  let u = (xa -. xb) 
  and v = (ya -. yb) in
  (sqrt ((u*.u)+.(v*.v)))


let (spline: (float*float) array -> (float array)*(splineCubique array)*(splineCubique array)) = 
  fun p ->
    let x=(Array.map fst p) in
    let y=(Array.map snd p) in
    let n=(Array.length p)-1 in
    let t=(Array.create (n+1) 0.) in
      t.(0) <- 0.;
      for i=1 to n do
	t.(i) <-  (norm p.(i-1) p.(i))+.t.(i-1) 
      done;
      (t,(splineF 1. 1. t x),(splineF 0. 0. t y))



(*

t=[|(0,0);(1,0);(2,2)|]




*)
