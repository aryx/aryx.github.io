{
  open Lib
}

rule actionLex = parse
  |  "b." {Brake} 
  |  "l." {Left}  
  |  "r." {Right }
  | "a." {Accel}  
  | ("ar."|"ra.") {AccelRight} 
  | ("al."|"la.") {AccelLeft }
  | "." {Roll}
