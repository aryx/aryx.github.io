open Common
open Lib
open Algo


let build_naive frequency map = 
  let goal = one_random_goal_cell map in
  let map_dist = build_map_dist map goal in
  let freq = ref frequency in let last = ref Roll in (* OPT *)
  let (engine: map -> state -> action) = fun map state -> 
    if !freq <= 0 then let _ = freq := frequency in (* OPT *)
    let action = 
      let coms = action_list in
      let coms = defense map frequency state coms in 
      let coms = 
	if (empty coms) then (print_string "PB, should have previewed this\n"; [Brake])
	else coms
      in
      
      let (com_states: (action * state) list) = 
	List.map (fun com -> (com, next_state state com)) coms in
      
      let current_cellcoord = posx_to_posmap state.pos in
      let next_cell_goal = best_next_cell map map_dist current_cellcoord goal in
      let _ = Vizualiser.draw_stuff  Graphics.magenta next_cell_goal in
      
      let already_in = com_states +> List.filter (fun (com, state) -> posx_to_posmap state.pos = next_cell_goal) in
      if List.length already_in > 0 then
	let next_next = best_next_cell map map_dist next_cell_goal goal in
	already_in    
	  +> List.map (fun (com, state) -> (com, distance_pixel_pixel state.pos (center_cell next_next)))
	  +> List.sort (fun (dir, dis) (dir', dis') -> dis <=> dis')
	  +> List.hd
	  +> fst
      else 
	com_states 
	  +> List.map (fun (com, state) -> (com, distance_pixel_pixel state.pos (center_cell next_cell_goal)))
	  +> List.sort (fun (dir, dis) (dir', dis') -> dis <=> dis')
       (* +> pack_sorted (fun (dir, dis) (dir', dis') -> dis = dis') *)
	  +> List.hd
	  +> fst
	  in
    (last := action; action) (* OPT *)
    else (freq := !freq - 1; !last) (* OPT *)
  in
  engine
	
    

