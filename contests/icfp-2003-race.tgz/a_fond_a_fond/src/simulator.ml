
open Common
open Lib

let test_run = repeat Roll 1000

let  (run_to_states_run: state -> run -> states_run) = 
  let rec aux here = function
    | [] -> []
    | act::xs -> 
	let next = next_state here act in
	next::(aux next xs)
		in
  aux

let (simulator2: state -> simulator) = fun start_state -> fun map engine -> 
  let rec aux state time = 
    let action = engine map state in
    let newstate = next_state state action in
    if(is_crash_cell map newstate) then (pr2 "You Sux"; None)
    else 
      if((is_goal_cell map newstate) && 
	 (supx (newstate.pos.x) (state.pos.x))) then Some time
      else aux newstate (time + 1)
  in 
  aux start_state 0

let (simulator_run: state -> map -> run -> int option) = fun start_state map run -> 
  let rec aux state time = function 
    | [] -> (Printf.printf "You Sux but do it in %d\n" time  ;None)
    | action::xs -> 
	let newstate = next_state state action in
	let _ = 
	  if(is_crash_cell map newstate) then (Printf.printf "You Sux but do it in %d\n" time;) in
	
	if((is_goal_cell map newstate) && 
	     (supx (newstate.pos.x) (state.pos.x))) then Some time
	  else aux newstate (time + 1) xs
  in 
  aux start_state 0 run

let (simulator: simulator) = fun map engine -> 
  let start_state = {d = i_to_fix 0; v = i_to_fix 0; pos = posmap_to_posx map.start } in
  simulator2 start_state map engine



let (simulator_dump: simulator) = fun map engine -> 
  let (cellx, celly) = map.start in
  let start_state = {d = i_to_fix 0; v = i_to_fix 0;
		      pos = posmap_to_posx (cellx, celly)
		    } in
  
  let rec aux state time = 
    print_int time ; print_string " " ; print_string (string_of_state state) ; print_string "\n" ; flush stdout;
    let action = engine map state in
    let newstate = next_state state action in
    (*if (is_crash_cell map newstate) then None *)
    (*else 
      if((is_goal_cell map newstate) && 
	 (supx (newstate.pos.x) (state.pos.x))) then Some time
      else *) aux newstate (time + 1)
  in 
  aux start_state 0

open Parsers
let exec_simulator map_file trace_file =
  let trace = ref (read_run trace_file) in
  let map = read_map map_file in
  let engine _map _state =
    match !trace with
	[]  -> failwith "Unexpected end of trace"
      | t::l -> trace := l ; t in
  simulator_dump map engine

(*
Simulator.exec_simulator "Een.trk" "Een.trc";;*)


let interactive_simulator display_old_trace initial_time_offset map_name =
  Vizualiser.init_display();
  let map = read_map map_name in
  let init_car = { pos = posmap_to_posx map.start ; v = i_to_fix 0; d = i_to_fix 0 } in

  let trace = read_trace map_name in

   let actions_already_done =
     (match initial_time_offset with
     | Some s -> 
	 let nb = int_of_string s in 
	 let l = last trace in
	 if List.length l < nb then
	   (prerr_endline (Printf.sprintf "no way, max time is %d" (List.length l)) ; exit 1) ;
	 take nb l
     | None -> []) in

   let car = ref (List.fold_left next_state init_car actions_already_done) in
   let counter = ref (List.length actions_already_done) in
   let save_trace = ref None in
   let actions = ref actions_already_done in

   let center_display() =
     (*Vizualiser.adapt_zoom_to_current_pos !car ;*)
     Graphics.clear_graph();
     Vizualiser.display_map map ;
     Vizualiser.display_one_trace Graphics.white init_car !actions ;
     Vizualiser.display_car !counter !car
   in

   let goto() = 
     print_endline "Which number?";
     actions := take (int_of_string (read_line())) !actions ; 
     car := List.fold_left next_state init_car !actions ;
     center_display() in

   let prev_action = ref None in
   let rec char2action = function
     | ' ' -> Roll
     | 'a' -> Accel
     | 'b' -> Brake
     | 'r' -> Right
     | 'R' -> AccelRight
     | 'l' -> Left
     | 'L' -> AccelLeft
     | 'g' -> goto(); next_action()
     | 'c' -> center_display() ; next_action()
     | 'q' -> exit 0
     | _ -> next_action()
   and next_action() =
     if false then
       char2action (Graphics.read_key())
     else
     match !prev_action with
     | None ->
	 let action = char2action (Graphics.read_key()) in
	 prev_action := Some action ;
	 action
     | Some action ->
	 if Graphics.key_pressed() then
	   let _ = Graphics.read_key() in
	   prev_action := None ; next_action()
	 else
	   (usleep 10000 ; action)
   in

   center_display() ;

   if display_old_trace then Vizualiser.display_trace init_car trace ;

     while true do
       Vizualiser.display_car !counter !car ;
       incr counter ;
       let action = next_action() in

       if !save_trace = None then save_trace := Some (prepare_save_trace map_name actions_already_done) ;
       actions := !actions @ [action] ;
       (some !save_trace) action ;
       car := next_state !car action ;

       if is_crash_cell map !car then (prerr_endline (Printf.sprintf "died! (time is: %d)" !counter) ; exit 1);

       if is_goal_cell map !car  then (prerr_endline (Printf.sprintf "GOAL! (time is: %d)" !counter) ; exit 0);
     done ;

  pause()

