(**************************************************************************)
(* following a given trajectory!! *)
(**************************************************************************)


(* this trajectory can be: 
 - fradet 
 - fradet + gimp + assisted
 - fradet + gimp + sampled arbitraly 
 - checkpoint pixel + gimp + sampled

and optimise only accel/brake following the trajectory, does not go in an another cell
PROPERTY_TO_CHECK: y'a une solution ? c sur ? 

idea: backward forward centered on the idea of computing max velocity (that
 translate the idea of how take virage at max without too much deriving, it does not
 optimise the angle of arrival, it optimise the speed of arrival

can we make a more naive version to test it !!! just given a trajectory (in cell position, a path), compute a good run
   (morover then will be able to use line editor, ...)
  the pb is that you need an indication of speed limit, cos can have a straight line
    and so go the fastest but then not be able to turn, 
    we could think that by constraining the trajectory, we can infer the brake and turn,
    but it requires to go in the futur to know that (can do this tech ? optimise is hard, to big search space)
  => as need speed limit => human => you will not do better than the human :), cos you will not be able
     to get rid of roll (or would like to infer that this roll coule be replace by accel/brake 
  BUT make an abstraction of a fradet race, partitionne, keep the speed limit at each bound of the portion
     but just do faster in this bound 
  REPLACE ROLL BY ACCEL/BRAKE
  how ? use assisted_trajectory_solver but do not call it with step of the race of 
   )

*)

open Common
open Lib

(* 
  *)
let (optimise_accel_brake_roll: map -> run -> run) = fun map run -> 
  (* TODO let pixel_positions = op run in compute_best_accel_brake_roll positions *)

  run

let (compute_best_accel_brake_roll: map -> pixelcoord list -> action list) = fun map positions -> 
(* CODE PLAN: reuse stuff in algo.ml (=> make better code, avoid in algo
   to make decision (=> put a defense2 which does not call red zone algo, decouple this algo 
  best_next_action_given_samples
  ...
  
  DOUBTS: do we really need many points ?
  DOUBTS: can we find a path satisfying ? what is the percentage of ecartement tol�r� ?

   
  *)

    (* first: FORWARD, compute the best velocity 
       HOW ? take a state and calculate 
    *)
  
    
    (* second: BACKWARD, using info table computer below *)
  []

  
