open Common

open Lib

open Vizualiser
open Parsers
open Algo

open Car_naive
open Simulator

open Trajectory

let start_main () = 
  let _ = init_display () in
  let map_name1 = "maps/1_Simple.trk" in
  let map_name2 = "maps/2_Hairpins.trk" in
  let map_name3 = "maps/3_Sepang.trk" in
  let map_name4 = "maps/4_EatYouAlive.trk" in
  let map_name5 = "maps/5_Car.trk" in
  let map_name6 = "maps/6_IcfpContest.trk" in
  let map_name7 = "maps/7_Gothenburg.trk" in
  let map_name8 = "maps/8_ManyWays.trk" in
  let map_name9 = "maps/9_PhilAndSimon.trk" in

  let better_map1 = "maps/better_one_spline" in
  map_name5

let _ = 

(*
  let _Add_speed = read_int () in
  let _Freinage = read_int () in
*)
  let map_name = start_main () in

  let _Update = true in
  let _Add_speed = 100 in
  let _Freinage = 200 in

  let _ = if _Update then try Trajectory.doit map_name with _ -> () in

  let _UseBrake = if _Freinage <= 0 then false else true in


  let _ = Assisted_trajectory._MaxFreinage := _Freinage in
  let _ = Assisted_trajectory._UseBrake := _UseBrake in
  
  try (
  ( (* ------ *)
   
   (
    let map = Parsers.read_map map_name in

    (*******************************************************************************)
    (* TODO take spline pixel of good traj or compute one from run *)
    (*
       compute_spline
          float max = 1024
          float max = 768
        -> (fixed_int, fixed_int)
    *)
    let trc = Parsers.read_run (chop map_name ^ "c") in
    (* OPTIONPAD2: _bis or not *)
    let points = ref (try read_points (map_name ^ ".spline.fix.more") with _ -> prune  (trc2points trc map)) in
    let _ = 
(*  Vizualiser.zoom_factor := 4;*)
    Vizualiser.init_display();
    draw_points map !points trc ;
    in
    (*******************************************************************************)

    let (times, polyXs, polyYs) = Spline.spline (Array.of_list !points) in

    let trajectory = (fun time -> ({x = zerox; y = zerox})) in

    let trajectory = 
      let spline_float = compute_spline (times, polyXs, polyYs) in
      (
       fun time -> let (xfloat, yfloat) = spline_float time in
       let trans = fun xf -> (xf *. (float (power 2 16))) +> int_of_float +> i_to_fix in 
       { x = trans xfloat; y = trans yfloat}
      )
    in
        (*******************************************************************************)

    let _ = (enum 0 ((Array.length times) - 2)) +> List.iter (fun i -> 
      
      let ti, ti' = times.(i), times.(i+1) in
      let nb_step = 100 in
      let ti_step = (ti' -. ti) /. (float_of_int nb_step) in

      let t = ref ti in
      for _i = 1 to nb_step do
	t := !t +. ti_step ;
	let pointx = trajectory  !t in

	(*
	let polyX, polyY = polyXs.(i), polyYs.(i) in
	let point = compute_spline_in_step (ti, polyX, polyY) !t in
	*)
(*	let _ = assert (pointx = point) in *)
(*	Vizualiser.colored_point_at Graphics.red (point_from_float pointx)      *)
	
(*	draw_stuff Graphics.red (posx_to_posmap pointx) *)
	()
      done
						       )
	(*  *)
    in

    let start_state = {pos = posmap_to_posx map.start;
			v = zerox; d = zerox
		      }
    in


    (*******************************************************************************)
    let oracle1 = (fun time -> {vmax = i_to_fix 13000}) in (* PARAMETER *)



    (*******************************************************************************)
    let tangeants = 
      let spline_float = compute_spline_tangent (times, polyXs, polyYs) in
      (
       fun time -> let (xfloat, yfloat) = spline_float time
       in
       let trans = fun xf -> (xf *. (float (power 2 16))) +> int_of_float +> i_to_fix in 
       { x = trans xfloat; y = trans yfloat}
      ) in

    let maxcoeff = ref 0.0 in
    let mincoeff = ref 200.0 in
    let oracle2 = 

      (fun time -> 
	let posy = tangeants time in
	let posx = trajectory time in
	let dist = Lib.norm posy posx in
	{vmax = 
	  (* PARAMETER *)
	  let straight_coeff  = (dist /. 100.0) in
	  let _ = (
	    maxcoeff :=  max straight_coeff !maxcoeff ;
	    mincoeff :=  min straight_coeff !mincoeff ;
	   ) in
	  let borne_max = 16000 in
	  let borne_min = 15000 in
	  let diff = borne_max - borne_min in
	  let diff_coeff = 8 in
	  let one_portion = diff / 8 in

	  let adjust = ((straight_coeff -. 2.0) *. (float one_portion)) in
	  
	  (borne_min + (int_of_float adjust))
	    +> (fun x -> 
                 if x < borne_min then borne_min
		 else if x > borne_max then borne_max
		 else x)
	    +> i_to_fix} 
       (* PARAMETER *)
	  
      ) in

    let oracle2 = 
      (fun time -> 

	let data check_point_number = fun x -> x in
	  
	let nearest_check_point_number_backward time = time
	in
	  
	{vmax = zerox
	    (* time +> nearest_check_point_number_backward +> data +> i_to_fix *)
	} 
      )
      0 in
(* TODO look tps pascal sur les points *)

    (*******************************************************************************)
    (* pixel *)
    let max_speeds = 
      try Trajectory.backstep !points with _ -> failwith "HERE1"
    in
      
    let oracle3 = 
      let f = 
	try max_speeds2oracle max_speeds with _ -> failwith "Here2"
      in
      (* OPTIONPAD1 *)
      (fun time -> {vmax = (i_to_fix (
			    (f time) + _Add_speed (* No Brake_Simple = 1500
					    *)
(* min 20000 *)
			   ))
		   }) in
      
    (*******************************************************************************)
    let oracle = oracle3 in
    (*******************************************************************************)
    let start = {pos = posmap_to_posx map.start;
		   v = zerox; d = zerox
		 } in

    let rec call_assisted_loop depth  trajectory oracle state t_state = 
	(* assert len remain_traj = len remain + 1 *)
      if depth <= 0 then (print_string "fail but run"; [])
      else if t_state > (times.((Array.length times) - 2)) then (print_string "no more spline"; [])
      else 
	let action = Assisted_trajectory.assisted state t_state trajectory oracle in
	let next = next_state state action in
(*	let _ = Printf.printf "\n XXX action = %s\n" (string_of_action action) in *)
	let time_time_plus_d = t_state +. (Lib.norm state.pos next.pos)  in (* PLUG BETTER *)

	(* TODO HERERERERERERERE RECOMPUTE BETTER TIME BY BOURRIN 
	   il est entre t_state et time_time_plus_d * 2
	*)
	let taille_borne = ((Lib.norm state.pos next.pos) *. 2.0) in
	let taille_cell  = taille_borne /. 10.0 in
(*	let _ = Printf.printf "taille_borne = %f, taille_cell = %f\n" taille_borne taille_cell in *)
	let times = (enum 0 9) +> List.map (fun cell -> t_state +. ((float cell) *. taille_cell)) in
	let distance_to_next = times +> List.map 
	    (fun time -> 
	      let dist_to_this_one = dist_escalier (trajectory time) next.pos in
(*	      let _ = Printf.printf "sample: %f, dist: %d\n" time (fix_to_i dist_to_this_one) in *)
	      (time, dist_to_this_one)
	    )
	    +> List.sort (fun (time1, dist1) (time2, dist2) -> dist1 <=> dist2)
	    in
	let really_time_next = distance_to_next +> List.hd +> fst in
	
	action::(call_assisted_loop (depth - 1) trajectory oracle (next_state state action) really_time_next) 
    in
    
    let run2 = call_assisted_loop 15000 trajectory oracle start 0.0 in
    let _ = Printf.printf "max = %f; min = %f \n" !maxcoeff !mincoeff in
(*    let run2 = (run2 ++ (repeat  Accel 240)) in *)
    
    let _ = display_one_trace Graphics.magenta {pos = posmap_to_posx map.start;
				       v = zerox; d = zerox
				     }  run2 in

    let chan = open_out "best_run.trc" in
    let _ = run2 +> List.iter (fun action -> output_string chan (action2string action)) in
    let _ = flush chan in
    let _ = close_out chan in
    
    
    
    let _ = Printf.printf "Score: %d, old score = %d\n" (List.length run2)  in
    let x = simulator_run start map run2 in
    let _ = 
    match x with
    | None -> pr2 "\nPascool"
    | Some t -> Printf.printf "\n\nwe dit: %d\n" t
    in

(*
    let x = simulator_run start map trc  in
    let _ = 
    match x with
    | None -> pr2 "\nPascool"
    | Some t -> Printf.printf "\n\nwe dit: %d\n" t
    in
*)

    ()
    
    (*******************************************************************************)

   );

(*   pause (); *)

  ) ) with x -> (pause (); raise x)

