open Common

open Lib

(**************************************************************************)
(* defense *)
(**************************************************************************)
(* frequency is the number of step we may be forced (for optimisation reason) to keep
   the same trajectory
*)
let rec (defense: map ->  int -> state -> action list -> action list) = fun map frequency state xs -> 
  (* TODO invariant smaller *)
  xs +> List.filter 
    (fun action -> 
      let next = next_state state action in
      (* 1: basic *)
      if is_crash_cell map next then false 
      else 
	(
	 if ((is_goal_cell map next) &&  (* TODO duplication with simulator *)
	     (* 2: must pass from left *)
	     not (supx (next.pos.x) (state.pos.x))) then false 
	 else 
	   (
	    (* 3: naive estimation braking in the same direction *)
	    not (is_crash_when_keep map next action frequency)
	   )
	)
    )
and (is_crash_when_keep: map -> state -> action -> int -> bool) = fun map state action forhowlong -> 
  let rec aux limit state frequency = 
    if limit = 0 then (pr2 "PB"; failwith "Fradet dit pas besoin de tant que ca pour freiner, 2000 c assez"; false ) (* PARAM: true/false *)  (* OPT *)
    else  
      if is_crash_cell map state then true
      else if state.v = zerox then false
      else aux (limit - 1) 
	  (next_state state 
	     (if (frequency + (if is_direction_action action then 0 (* PARAM *) else 0)) <= 0 
	     then Brake 
	     else action)) 
	  (frequency - 1)
  in
  aux 2000 (* PARAM *) state forhowlong (* TODO how much to be sure ? *)

(**************************************************************************)
(* shortest *)
(**************************************************************************)

(*--------------------*)
(* cell x cell *)
(*--------------------*)
(* naive: bird fly *)
(* dijkstra *)
(* optimised diskstra (wave) *)
type map_dist = {wave: Wave.dist_space; goal: cellcoord}
let (build_map_dist: map -> cellcoord -> map_dist) = fun map goal -> 
  (* special case: when come from right => have to stop *)
  {wave = 
    Wave.add_distance 
      (Wave.empty_dist_space (Array.length map.world) (Array.length map.world.(0)))
      map.world  
      goal;
    goal = goal
  } 

let (distance_cellmeter: map_dist -> cellcoord -> cellcoord -> int) = fun map_dist cell1 goal -> 
  let _ = assert (goal = map_dist.goal) in
  Wave.get_distance map_dist.wave goal cell1

let (best_next_cell: map -> map_dist -> cellcoord -> cellcoord -> cellcoord) = fun map map_dist cell goal -> 
  let arounds = cellcoords_around cell in
  arounds +> List.filter (fun cell -> not (is_crash_cell map (fake_state cell))) 
    +> List.map (fun cell2 -> (cell2, (distance_cellmeter map_dist cell2 goal)))
    +> List.sort (fun (dir, dis) (dir', dis') -> dis <=> dis')
    (* +> pack_sorted (fun (dir, dis) (dir', dis') -> dis = dis') *)
    +> List.hd
    +> fst

exception FoundCell of cellcoord
let (one_random_goal_cell: map -> cellcoord) = fun map -> 
  try 
    ((for x = 0 to Array.length map.world - 1 do
      for y = 0 to Array.length map.world.(0) -1 do
	match map.world.(x).(y) with
	| Goal -> raise (FoundCell (x,y))
	| _ -> ()
      done
    done
	
     )
       ;failwith "no goal"
    )
  with FoundCell c -> c | _ -> failwith "no goal"
  
let (best_path: map -> cellcoord -> cellcoord -> cellcoord list) = fun map start goal -> 
  (* print the best path *)
  let map_dist = build_map_dist map goal in
  let rec aux cell = 
    if(is_goal_cell map (fake_state cell)) then [cell]
    else 
      let next_cell = best_next_cell map map_dist cell goal in
      next_cell::(aux next_cell)
  in
  start::aux start


(*--------------------*)
(* pixel x pixel *)
(*--------------------*)
(* suppose that pixel are in square close TODO inv *)
let (distance_pixel_pixel: posx -> posx -> float) = fun a b -> match (a, b) with 
| ({ x = Fixed ax; y = Fixed ay}, {x = Fixed bx; y = Fixed by}) -> 
    sqrt (square (float (bx - ax)) +. square (float (by - ay)))

let (direction_pixel_pixel: posx -> posx -> fixed_int) = fun a b -> 
  angle2 a b

(*--------------------*)
(* pixel x cell *)
(*--------------------*)
(* could also try pixel * cell list but they say that one cannot in one step jump over a case 
   _Limit do this = size of arete (optimal case) / 655 ...
*)

let (distance_pixel_cell: state -> cellcoord -> float) = fun state cell -> 
  (* take center of cell *)
  distance_pixel_pixel state.pos (posmap_to_posx cell +> 
				  (* center of cell *)
				  (fun {x = x; y = y} -> { x = (plusx x (i_to_fix (power 2 16)));
							   y = (plusx y (i_to_fix (power 2 16)))
							 } ))
  
  
(*******************************************************************************************)
(*******************************************************************************************)
let rec (commands_until_stop: state -> int) = fun state ->
    if state.v = zerox then 0
    else 1 + (commands_until_stop (next_state state Brake))

let rec (commands_until_good_direction: state -> cellcoord -> action -> int) = fun state new_target action -> 
  let next = next_state state action in
  let dir = direction_pixel_pixel state.pos (center_cell new_target) in
  (* (Lib.divx (Fixed 64) (Fixed 20000))  = 209 *)
  if ((abs (fix_to_i (minusx state.d dir))) <= 209 + 100) then
    1
  else 1 + commands_until_good_direction next new_target action



  
  
  




