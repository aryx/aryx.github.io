(********************)
(* vectors          *)

let vector_of_pos {x=xa;y=ya} {x=xb;y=yb} =
  {x = minusx xb xa ; y = minusx yb ya}

let scalar_product pos_a pos_b =
  let {x=xa ; y=ya} = posa 
  and {x=xb ; y=yb} = posb in
  (mulx xa xb) + (mul ya yb)

