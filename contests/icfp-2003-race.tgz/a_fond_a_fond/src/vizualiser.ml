open Common
open Graphics

open Lib

let cell2color = function 
  | Wall Green -> green
  | Wall Red -> red
  | Wall White -> white 
  | Wall Blue -> blue
  | Space -> black 
  | Goal -> yellow
  
let init_display () = Graphics.open_graph " 1024x768"

let max_x = ref 1024
let max_y = ref 768
let zoom_factor = ref 1
let zoom_offset_x = ref 0
let zoom_offset_y = ref 0

let apply_zoom (x, y) =
  !zoom_factor * (x + !zoom_offset_x), 710 - !zoom_factor *(y + !zoom_offset_y)

let unapply_zoom (x, y) =
  x / !zoom_factor - !zoom_offset_x, (710 - y) / !zoom_factor - !zoom_offset_y

let adapt_zoom_to_current_pos car =
  let x, y = posx_to_posmap car.pos in
  zoom_offset_x := - (max (x - 1000 / !zoom_factor / 2) 0) ;
  zoom_offset_y := - (max (y - 700 / !zoom_factor / 2) 0)


let colored_point_at_ color (x, y) size =
  set_color color;
  let x', y' = apply_zoom (x, y) in
  fill_rect x' y' size size

let colored_point_at color (x,y) = colored_point_at_ color (x,y) !zoom_factor

let saved_image_map = ref None
let (display_map: map -> unit) = fun map -> 
  match !saved_image_map with
  | None ->
      auto_synchronize false ;
      max_x := Array.length map.world ;
      max_y := Array.length map.world.(0) ;
      (map.world +> Array.iteri (fun x row -> 
	row +> Array.iteri (fun y cell -> colored_point_at (cell2color cell) (x, y)))) ;
      saved_image_map := Some (get_image 0 0 1024 768) ;
      auto_synchronize true
  | Some image -> draw_image image 0 0



let prev_car = ref None

let display_car_minimal color car =
  colored_point_at color (posx_to_posmap car.pos)

let (display_car : int -> state -> unit) = fun counter car ->
  let car_next = next_state (*{ car with v = i_to_fix (max (fix_to_i car.v) 30) }*) car Roll in

  set_color black ;
  fill_rect 0 0 250 15 ;
  moveto 0 0 ;
  set_color white ;
  draw_string (Printf.sprintf "%d (%.2f, %.2f) v=%d d=%d" counter (float_of_int (fix_to_i car.pos.x) /. 65536.) (float_of_int (fix_to_i car.pos.y) /. 65536.) (fix_to_i car.v) (fix_to_i car.d)) ;

  let beg_x, beg_y = apply_zoom (posx_to_posmap car.pos) in
  let dx, dy = fix_to_i (minusx car_next.pos.x car.pos.x), fix_to_i (minusx car_next.pos.y car.pos.y) in
  let k = 250 in
  let dx, dy = dx / k, -dy / k in
  let end_x, end_y = beg_x + dx, beg_y + dy in
  let mid1_x, mid1_y = end_x - (dx - dy) / 4, end_y - (dx + dy) / 4 in
  let mid2_x, mid2_y = end_x - (dx + dy) / 4, end_y - (-dx+ dy) / 4 in
  let car_lines = [| beg_x, beg_y ; 
		     end_x, end_y ; mid1_x, mid1_y ; 
		     end_x, end_y ; mid2_x, mid2_y |] in
  (match !prev_car with
  | None -> ()
  | Some(x, y, image) -> draw_image image x y);

  display_car_minimal white car ;

  let min_x, min_y = min beg_x (min mid1_x (min mid2_x end_x)), min beg_y (min mid1_y (min mid2_y end_y)) in
  let max_x, max_y = max beg_x (max mid1_x (max mid2_x end_x)), max beg_y (max mid1_y (max mid2_y end_y)) in
  prev_car := Some(min_x, min_y, get_image min_x min_y (max_x - min_x + 1) (max_y - min_y + 1)) ;

  set_color yellow ;
  draw_poly_line car_lines

let display_speed speed (x,y) =
  let x, y = apply_zoom (x + 5, y - 5) in
  set_color black ;
  fill_rect x y 20 15 ;
  moveto x y ;
  set_color white ;
  draw_string (string_of_int (speed / 100))

let display_one_trace color init_car actions =
    let counter, _ = List.fold_left (fun (counter, car) action ->
      display_car_minimal color car ;
      let car = next_state car action in
      (*if counter mod 200 = 1 then display_speed (fix_to_i car.v) (posx_to_posmap car.pos) ;*)
      counter + 1, car
    ) (0, init_car) actions in
    prerr_endline (Printf.sprintf "trace stopped at %d" counter)

let display_trace init_car trace =
  auto_synchronize false ;
  List.iter (display_one_trace (rgb 100 100 100) init_car) trace ;
  auto_synchronize true
   
let draw_stuff color cellcoord = 
  (set_color color;
   let x, y = apply_zoom cellcoord in
   draw_circle x y 2;
(*   Unix.sleep 1; *)
  )


  
let (map_test: map) = 
  { height = 10; width = 10; start = (3, 3);
    world = 
    [|
      [| Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green |];
      [| Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green |];
      [| Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green |];
      [| Wall Green; Wall Green; Wall Green; Space ; Space ; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green |];
      [| Wall Green; Wall Green; Wall Green; Space ; Space ; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green |];

      [| Wall Green; Wall Green; Wall Green; Space; Space; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green |];
      [| Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green |];
      [| Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green |];
      [| Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green |];
      [| Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green; Wall Green |]
    |]
  }
    
