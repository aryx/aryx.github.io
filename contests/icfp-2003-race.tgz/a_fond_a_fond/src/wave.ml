open Common
open Lib

(* PATCHPAD TODO what is the interface *)

type position = cellcoord

type dist_space = {
    nb_slots : int ;
    time : float ;
    x_nb : int ;
    y_nb : int ;
    pos2distances : (position * (int, Bigarray.int16_unsigned_elt, Bigarray.c_layout) B_Array.t) list ;
  }
let wall = 0xffff
let unreachable = 0xfffe
let max_dist = 0xfffd



let new_dist_map x_nb y_nb space =
  let dist_space = B_Array.create Bigarray.int16_unsigned Bigarray.c_layout x_nb y_nb in
  for x = 0 to x_nb-1 do
    for y = 0 to y_nb-1 do
      let v = 
	match space.(x).(y) with
(* PATCHPAD OLD:	| Wall2 | Water2 -> wall | _ -> unreachable in *)
	| Wall _ -> wall | _ -> unreachable in
      B_Array.set dist_space x y v
    done
  done ;
  dist_space

(* Compute the next wave in place and update the space *)

let compute_next_wave space x_nb y_nb v current next =
  let n_i = ref 0 in
  let push (x,y) = 
    if B_Array.get space x y = unreachable then
      begin
	Array.set next !n_i x ;
	Array.set next (!n_i + 1) y ;
	n_i := !n_i + 2
      end
  in
  let rec do_it c_i =
    let x = Array.get current c_i in
    if x <> -1 then begin
      let y = Array.get current (c_i + 1) in
      if B_Array.get space x y = unreachable then begin
	B_Array.set space x y v;
	if x+1 < x_nb then push (x+1,y) ;
	if x-1 > 0    then push (x-1,y) ;
	if y+1 < y_nb then push (x,y+1) ;
	if y-1 > 0    then push (x,y-1) ;
	(* PATCH PAD for last icfp *)
	if (x-1 > 0) && (y-1 > 0)    then push (x-1, y-1);
	if (x-1 > 0) && (y+1 < y_nb) then push (x-1, y+1);
	if (x+1 > x_nb) && (y-1 > 0)    then push (x+1, y-1);
	if (x+1 > x_nb) && (y+1 < y_nb) then push (x+1, y+1);
      end ;
      do_it (c_i + 2)
    end
  in
  do_it 0 ;
  Array.set next !n_i (-1) ;
  !n_i > 0

let waves space (x, y) =
  let x_nb, y_nb = B_Array.dim1 space, B_Array.dim2 space in
  let rec wave v current next =
    if compute_next_wave space x_nb y_nb v current next then
      wave (min (v+1) max_dist) next current
  in
  let current = Array.create (8*(y_nb+x_nb)) (-1) in
  let next = Array.create (8*(y_nb+x_nb)) (-1) in
  Array.set current 0 x ;
  Array.set current 1 y ;
  wave 0 current next ;
  space
  

let put_front dist_space pos = 
  try 
    let l = dist_space.pos2distances in
    let e = List.assoc pos l in
    let l = List.filter (fun (pos2,_) -> pos <> pos2) l in
    Some { dist_space with pos2distances = (pos,e) :: l }
  with Not_found -> None

let print_one_dist_space dist_space one_dist_space =
  for y = dist_space.y_nb-1 downto 0 do
    for x = 0 to dist_space.x_nb-1 do
      Printf.printf "%4d " (B_Array.get one_dist_space x y)
    done ;
    print_string "\n" ;
  done
  

let empty_dist_space x_nb y_nb =
  let nb_slots = 15 * 1024 * 1024 / 2 / x_nb / y_nb in
  Printf.printf "nb_slots allocated to wave distance cache %d\n" nb_slots ;
  {
   nb_slots = nb_slots ;
   time = 0. ;
   x_nb = x_nb ; y_nb = y_nb ;
   pos2distances = [] ;
 }

let drop_distance_using dist_space one_dist_space =
  let pos2distances = dist_space.pos2distances in
  let l = List.map (fun ((x,y), _ as e) ->
    B_Array.get one_dist_space x y, e
  ) pos2distances in
  let l = List.sort (fun (a,_) (b,_) -> compare b a) l in

  let (x,y) = fst (snd (List.hd l)) in
  Printf.printf "dropping (%d,%d)\n" x y ;
  let l_ = List.rev (List.tl (List.map snd l)) in

  { dist_space with pos2distances = l_ }

let add_distance dist_space space pos =
  match put_front dist_space pos with
  | Some dist_space -> dist_space
  | None ->
    
  let before = Sys.time() in
  let one_dist_space = waves (new_dist_map dist_space.x_nb dist_space.y_nb space) pos in
  let after = Sys.time() in
  Printf.printf "add_distance took %0.2f (currently having %d slots)\n" (after -. before) (List.length dist_space.pos2distances) ; flush stdout ;

  let space = 
    if List.length dist_space.pos2distances >= dist_space.nb_slots then
      let r = { dist_space with pos2distances = Common.removelast dist_space.pos2distances } in
      if dist_space.x_nb * dist_space.y_nb > 400000 then Gc.full_major() ;
      r
    else
      dist_space
  in
  { space with 
    time = if space.time >= 0. then (space.time +. after -. before) /. 2. else after -. before ;
    pos2distances = (pos, one_dist_space) :: space.pos2distances }

let get_distance dist_space pos_cached (x,y) =
  let one_dist_space = List.assoc pos_cached dist_space.pos2distances in
  B_Array.get one_dist_space x y
