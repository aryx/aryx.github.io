let (pixel_to_cell_distance: posx -> cellcoord -> fixed_int) = fun xy cellxy -> 
 _TODO()

(*
p -> 
N : {x=p.x y=(posx_to_posmap p.y)}
W : {x=(posx_to_posmap p.x) y=p.y}
S : {x=p.x y=((posx_to_posmap p.y)+1)}
E : {x=((posx_to_posmap p.x)+1) y=p.y}

*)
