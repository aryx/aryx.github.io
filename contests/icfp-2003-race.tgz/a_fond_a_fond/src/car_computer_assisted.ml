open Common

open Lib

(* take fradet (or fradet sampled gimp  (or checkpoint pixel sampled gimp)) run and optimise *)


