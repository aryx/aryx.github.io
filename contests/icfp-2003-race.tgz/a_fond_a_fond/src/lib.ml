
open Common
(*******************************************************************************************)
(* fixed point arithmetic *)
(*******************************************************************************************)
type fixed_int = Fixed of int (* newtype tech, safer *)
(* (int * int) was possible but sux cos cant use directly + ...
   so prefer simply int, and just redefine mul and div to expand the int to 
   make the computatin and go back to optimised type 
*)

let (i_to_fix: int -> fixed_int) = fun i -> 
  (*int*int: (i / (power 2 16), i mod (power 2 16)) *)
  (* TODO assert? not more than 10 digits ? *)
  Fixed i

let (fix_to_i: fixed_int -> int) = fun (Fixed i) -> i

(* DONT USE *)
let (int_to_fix: int -> fixed_int) =  fun i -> i_to_fix (i * (power 2 16))

let fix_to_float i = float_of_int (fix_to_i i) /. 65536.

let (pi_div_2_x: fixed_int) = i_to_fix 102944
let (pi_x: fixed_int)       = i_to_fix 205887
let (two_pi_x: fixed_int)   = i_to_fix 411775

let (zerox: fixed_int) = i_to_fix 0

let inv_fixed a = 
(*  prerr_endline (Printf.sprintf "%d %d %d" (fix_to_i a) (power 2 16) (power 2 10)); *)
  (*let _ = assert ((fix_to_i a / (power 2 16)) <= (power 2 10)) in*)
  a

(* 32 bits is enough *)
let (plusx:  fixed_int -> fixed_int -> fixed_int) = fun a b -> 
  i_to_fix ((fix_to_i a) + (fix_to_i b)) +> inv_fixed
let (minusx: fixed_int -> fixed_int -> fixed_int) = fun a b -> 
  i_to_fix ((fix_to_i a) - (fix_to_i b)) +> inv_fixed
let (negx: fixed_int -> fixed_int) = fun a -> 
  i_to_fix (- (fix_to_i a)) +> inv_fixed

let (infx: fixed_int -> fixed_int -> bool) = fun a b -> 
  (fix_to_i a) < (fix_to_i b) 
let (supx: fixed_int -> fixed_int -> bool) = fun a b -> 
  (fix_to_i a) > (fix_to_i b)
let (infeqx: fixed_int -> fixed_int -> bool) = fun a b -> 
  (fix_to_i a) <= (fix_to_i b)
let (supeqx: fixed_int -> fixed_int -> bool) = fun a b -> 
  (fix_to_i a) >= (fix_to_i b)

let (maxx:  fixed_int -> fixed_int -> fixed_int) =
  fun a b -> if infx a b then b else a



(*
let (mulx:  fixed_int -> fixed_int -> fixed_int) = fun a b -> 
  i_to_fix ((fix_to_i a) * (fix_to_i b))
let (divx:  fixed_int -> fixed_int -> fixed_int) = fun a b -> 
  i_to_fix ((fix_to_i a) / (fix_to_i b))
*)

(* need more than 32 bits *)
let (mulx: fixed_int -> fixed_int -> fixed_int) = fun a b -> 
  let (x, y) = (fix_to_i a, fix_to_i b) in
  let (x', y') = (Int64.of_int x, Int64.of_int y) in
  (* Int64.div (Int64.mul x' y') (Int64.of_int (power 2 16)) *)
  Int64.shift_right (Int64.mul x' y') 16
    +> Int64.to_int +> i_to_fix +> inv_fixed
let mulx_ex = mulx (i_to_fix 40) (i_to_fix (- 209));;  

let (divx: fixed_int -> fixed_int -> fixed_int) = fun a b -> 
  if fix_to_i b = 0 then failwith "division by zero" 
  else
    let (x,y) = (fix_to_i a, fix_to_i b) in
    let (x', y') = (Int64.of_int x, Int64.of_int y) in
    Int64.div 
      (* (Int64.mul x' (Int64.of_int (power 2 16)))  *)
      (Int64.shift_left x' 16)
      y'
      +> Int64.to_int +> i_to_fix +> inv_fixed

let rec (sinxx: fixed_int -> fixed_int) = fun x -> 
  if(infx x zerox) then negx (sinxx (negx x))
  else 
    (if (supx x pi_div_2_x) then sinxx (minusx pi_x x)
    else
      let x2 = mulx x x in
      let x3 = mulx x x2 in
      let x5 = mulx x3 x2 in
      let x7 = mulx x5 x2 in
      (minusx
	 (plusx x (i_to_fix ((fix_to_i x5) / 120)))
	 (plusx (i_to_fix ((fix_to_i x3) /  6)) (i_to_fix ((fix_to_i x7) / 5040)))
      )
    )
let sinx x = 
  let res = sinxx x in
  let _ = assert ((infeqx res pi_x) || (supeqx res (negx pi_x))) in
  res +> inv_fixed
      
let (cosx: fixed_int -> fixed_int) = fun x -> 
  let x = (plusx x (pi_div_2_x)) in
  let x = if(supx x pi_x) then (minusx x two_pi_x) else x in
  sinx x +> inv_fixed
  




(*******************************************************************************************)
(* car *)
(*******************************************************************************************)
type posx       = {x: fixed_int; y: fixed_int}

type state = {pos: posx; v: fixed_int; d: fixed_int}
  let (state_invariant: state -> bool) = fun _car -> _TODO() (* v >= 0, -pi <= <= pi *)

type action = Roll | Brake | Left | Right | Accel | AccelRight | AccelLeft
let action_list = [Roll; Brake; Left; Right; Accel; AccelRight; AccelLeft] (* PARAM *)

(*   *)
let string_of_state state =
  let xy = state.pos in
  let (x,y) = pair (compose string_of_int fix_to_i) (xy.x, xy.y) in
  let (v,d) = pair (compose string_of_int  fix_to_i)  (state.v,state.d) in
  x^" "^y^" "^v^" "^" "^d

let is_direction_action = function
| Left | Right | AccelRight | AccelLeft -> true
| _ -> false

let string_of_action = function
  | Roll -> "Roll" | Brake -> "Brake" | Left -> "Left" | Right -> "Right" | Accel -> "Accel" | AccelRight -> "AccelRight" | AccelLeft -> "AccelLeft"

(*******************************************************************************************)
(* model *)
(*******************************************************************************************)

let (_Accelerator: fixed_int) = i_to_fix 24
let (_Braking: fixed_int) = i_to_fix 36 
let (_Turning: fixed_int) = i_to_fix 64 
let (_Limit: fixed_int) = i_to_fix 20000
let ((_F0, _F1 , _F2):(fixed_int * fixed_int * fixed_int)) = (i_to_fix 4, i_to_fix 12, i_to_fix 24)

let (next_state: state -> action -> state) = fun car action -> 
  let x = ref car.pos.x in 
  let y = ref car.pos.y in
  let v = ref car.v in
  let d = ref car.d in
  (
   v := (minusx !v 
	   (plusx _F0 (plusx (mulx _F1 !v) (mulx _F2 (mulx !v !v)))));
   (match action with 
   | Accel | AccelRight | AccelLeft -> 
       v := (plusx !v _Accelerator)
   | _ -> ());
   (if action = Brake then v := (minusx !v _Braking));
   (if (infx !v zerox) then v := zerox);
   (match action with 
   | Left | AccelLeft -> d := (minusx !d (divx _Turning 
					   (plusx (mulx !v !v) _Limit)))
   | _ -> ());
   (match action with 
   | Right | AccelRight -> d := (plusx !d (divx _Turning 
					   (plusx (mulx !v !v) _Limit)))
   | _ -> ());
   while (infx !d (negx pi_x)) do d := (plusx !d two_pi_x) done;
   while (supx !d pi_x)        do d := (minusx !d two_pi_x) done;
   x := plusx !x (mulx !v (cosx !d));
   y := plusx !y (mulx !v (sinx !d));
   {pos = {x = !x; y = !y}; v = !v; d = !d}
  )
   

(* _TODO when rally *)
let ex1 = {pos = {x = Fixed 23265280; y = Fixed 21102592}; v = Fixed 0; d = Fixed 0}
let nextex1 = next_state ex1 Accel
(* {pos = {x = Fixed 23172311; y = Fixed 21102592}; v = Fixed 20; d = Fixed 0} *)
(*    1 :  23265299  21102592        20         0         0 *)
let ex2 = {pos = {x = Fixed 23265299; y = Fixed 21102592 }; v = Fixed 20; d = Fixed 0}
let nextex2 = next_state ex2 AccelLeft

(* me: 2 23265338 21102591 40 -209 *)

(*******************************************************************************************)
(* map *)
(*******************************************************************************************)
type cell = Goal | Wall of color | Space
     and  color = Green | Red | White | Blue

type posmap = int

type cellcoord  = (int * int)
type pixelcoord = (fixed_int * fixed_int)

type map = {height: int; width: int; world: cell array array; start: (int * int) }
(* x growing, y growing (from (0,0) to (width, height) *)


let (posmap_to_fixed_int: posmap -> fixed_int) = fun cellcoord ->
  i_to_fix (cellcoord * (power 2 16))
  
(* vue grossiere *)
let (fixed_int_to_posmap: fixed_int -> posmap) = fun fixed -> 
  let v = ((fix_to_i fixed) / (power 2 16)) in
(*  let _ = Printf.printf "coord xy = %d\n" v in *)
  v

let posmap_to_posx (x, y) = { x = posmap_to_fixed_int x ; y = posmap_to_fixed_int y }
(* approximate *)
let posx_to_posmap posx = fixed_int_to_posmap posx.x, fixed_int_to_posmap posx.y

let (center_cell: cellcoord -> posx) = fun (x, y) -> 
  ((x +> int_to_fix +> fix_to_i)  + ((power 2 16) / 2),
   (y +> int_to_fix +> fix_to_i)  + ((power 2 16) / 2)
  ) +> (fun (x,y) -> ({x = i_to_fix x; y = i_to_fix y}))

let (cell_at: map -> state -> cell) = fun map state -> 
  let (cellx, celly) = posx_to_posmap state.pos in
  map.world.(cellx).(celly)
  
let (is_crash_cell: map -> state -> bool) = fun map state -> 
  match cell_at map state with
  | Wall _ -> true
  | _ -> false
	
let (is_goal_cell: map -> state -> bool) = fun map state -> 
  cell_at map state = Goal

type direction = N | E | W | S
let move (x,y) = function
  | N -> x, y+1
  | S -> x, y-1
  | E -> x+1, y
  | W -> x-1, y


let (cellcoords_around: cellcoord -> cellcoord list) = fun cell -> 
    [N;E;W;S] +> List.map (fun dir -> move cell dir)

let (fake_state: cellcoord -> state) = fun cell -> 
  {pos = posmap_to_posx cell; v = zerox; d = zerox}


(*******************************************************************************************)
(* runs (trace) *)
(*******************************************************************************************)
type run = action list
let (valid_run: map -> run -> bool) = fun _map _run -> _TODO()

let (winning_run: map -> run -> bool) = fun _map _run -> _TODO()

let (better_race: map -> run -> run -> bool) = fun _map _better _old -> _TODO()

type states_run = state list

(*******************************************************************************************)
(* engine *)
(*******************************************************************************************)
type engine = (map -> state -> action)

type nbstep = int (* score *)
type simulator = (map -> engine -> nbstep option) (* return None when program crashed *)

(*******************************************************************************************)
(* algo *)
(*******************************************************************************************)

(* spline powa *)
type time = float

type trajectory = (time -> posx) (* spline(t) -> pos *)
type vmax = { vmax: fixed_int}
type oracle = (time -> vmax)
 
(*******************************************************************************************)
(* rally *)
(*******************************************************************************************)

type action_rally = 
   | Roll2 
   | Left2 | Right2 
   | Brake2 | BrakeLeft2 | BrakeRight2
   | Accel2 | AccelLeft2 | AccelRight2

let (next_state_rally: state -> state) = fun _s -> _TODO()

let (absx: fixed_int -> fixed_int) = 
  fun  (x:fixed_int) -> 
    if (infx x zerox)
    then negx x
    else x

let (sqrtx: fixed_int -> fixed_int) = 
  fun x -> 
    let u = ref (maxx x (int_to_fix 1)) in
    let l = ref (i_to_fix 0) in
    let g = ref (i_to_fix 0)in
    while not (u = l)
    do
      g := divx (plusx !u !l) (int_to_fix 2);
      if supx (mulx !g !g) x 
      then u := !g 
      else l:= plusx !g (i_to_fix 1)
    done;
      !u

let un_x = (int_to_fix 1)



let (asinx: fixed_int -> fixed_int ) = 
  fun x0 -> 
    let x = i_to_fix 0 in
    let x = minusx x (divx  (minusx (sinx x) x0) (cosx x)) in
    let x = minusx x (divx ( minusx (sinx x) x0) (cosx x)) in
    let (x:fixed_int) = minusx x  (divx ( minusx (sinx x) x0) (cosx x)) in
    x

let (float_of_fix: fixed_int -> float) = fun x ->
  let p = (power 2 16) in
  let ix = (fix_to_i x) in
    (float_of_int ix) /. (float_of_int p)

let (fix_of_float: float -> fixed_int) = fun r ->
  let p = (power 2 16) in
  let i = (r*.(float_of_int p)) in
    (Fixed (int_of_float i))

let (norm: posx -> posx -> float) = fun a b ->
  let u=(float_of_fix a.x)-.(float_of_fix b.x)
  and v=(float_of_fix a.y)-.(float_of_fix b.y) in
  (sqrt ((u*.u)+.(v*.v)))

let (dist_escalier: posx -> posx -> fixed_int) = fun a b ->
  let u=abs ((fix_to_i a.x) - (fix_to_i b.x))
  and v=abs ((fix_to_i a.y) - (fix_to_i b.y)) in
   i_to_fix (u + v)


let (vec2angle: (float*float) -> (float*float) -> float) =
  fun (x1,y1) (x2,y2) ->
    let pi=4.*.(atan 1.) in 
    let theta2=(atan2 y2 x2) in
    let theta1=(atan2 y1 x1) in
    let diff= theta2-.theta1 in 
      if diff>pi then diff-.pi
      else if diff<(-1.*.pi) then diff+.pi
      else diff


let (atanr: fixed_int -> fixed_int -> fixed_int ) = 
  fun y x -> 
    (fix_of_float (atan2 (float_of_fix y) (float_of_fix x)))

let (angle2: posx -> posx -> fixed_int) = fun a b ->
  let y=(minusx b.y a.y) in
  let x=(minusx b.x a.x) in
    (atanr y x)


let (atan2x: fixed_int -> fixed_int) = fun _a ->  _TODO() 

let rec (atanx: fixed_int -> fixed_int) = 
  fun k -> 
    if infx k (i_to_fix 0)
    then negx (atanx (negx k))
    else (
      if supx k un_x
      then minusx pi_div_2_x (atanx (divx un_x k))
      else asinx (divx k (sqrtx (plusx un_x (mulx k k)))))





let (anglediffx: fixed_int -> fixed_int-> fixed_int) = 
  fun u v-> 
    let diff = minusx u v in
    if (infx diff (negx pi_x)) 
    then  plusx diff two_pi_x
    else 
      (if supx diff pi_x
      then minusx diff  two_pi_x
      else diff)
      
