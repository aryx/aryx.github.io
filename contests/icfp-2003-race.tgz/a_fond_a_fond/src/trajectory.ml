open Common
open Lib

let max_speed = 46341

let trc2points trc map =
  let init_state = {Lib.d = i_to_fix 0; v = i_to_fix 0; pos = posmap_to_posx map.start } in
  let state2point state = fix_to_float state.pos.x, fix_to_float state.pos.y in
  let points, state = map_withenv (fun state action ->
    state2point state, next_state state action
  ) init_state trc
  in
  points @ [ state2point state ]

let distance (x1,y1) (x2,y2) = sqrt (sqr (x1-.x2) +. sqr (y1-.y2))

let point_from_float (x,y) = int_of_float x, int_of_float y
let point_to_float (x,y) = float_of_int x, float_of_int y

let prune points = grep_with_previous (fun p1 p2 -> distance p1 p2 > 100.) points

let find_indice_for_spline_time spline_times t =
  try array_find_index (fun t' -> t < t') spline_times - 1
  with Not_found -> Array.length spline_times - 2

let prev_indice_for_spline_time = ref 0
let fast_find_indice_for_spline_time spline_times t =
  if t < spline_times.(!prev_indice_for_spline_time) || t >= spline_times.(!prev_indice_for_spline_time + 1) then 
    (* the cached value is no good anymore *) 
    prev_indice_for_spline_time := find_indice_for_spline_time spline_times t ;
  !prev_indice_for_spline_time
    
let d_angle2angle d_angle = 
  let d_angle = if d_angle > 205887 then d_angle - 411775 else d_angle in
  float_of_int d_angle /. 205887. *. 3.14

let curve2max_speed_table1 = Array.create (int_of_float (600. /. 0.05) + 1) (-1)
let curve2max_speed_table2 = Array.create (int_of_float (1. /. 0.002) + 1) (-1)
let curve2max_speed curve =
  let inv_curve = 1. /. curve in
  if inv_curve > 600. then max_speed else
  if inv_curve > 1. then
    curve2max_speed_table1.(int_of_float (inv_curve /. 0.05 +. 0.5))
  else
    curve2max_speed_table2.(int_of_float (inv_curve /. 0.002 +. 0.5))
let curve2max_speed_table_fill =
  let init_car v = {d = i_to_fix 0; v = i_to_fix v; pos = posmap_to_posx (0, 0) } in
  let fill speed =
    let car = next_state (init_car speed) AccelRight in
    let angle = d_angle2angle (fix_to_i car.d) in
    let curve = angle /. distance (fix_to_float car.pos.x, fix_to_float car.pos.y) (0., 0.) in
    let inv_curve = 1. /. curve in
    if inv_curve > 1. then
      curve2max_speed_table1.(int_of_float (inv_curve /. 0.05 +. 0.5)) <- speed
    else
      curve2max_speed_table2.(int_of_float (inv_curve /. 0.002 +. 0.5)) <- speed
  in
  for i = 0 to 2000 do fill i done ;
  for i = 0 to max_speed / 100 do fill (i * 100) done ;
  List.iter (fun table -> 
    Array.iteri (fun i v -> if v = -1 && i > 1 then table.(i) <- table.(i-1)) table
  ) [ curve2max_speed_table1 ; curve2max_speed_table2 ]

let compute_spline_in_step (ti, polyX, polyY) t =
  let dt = t -. ti in
  pair (fun poly -> poly.Spline.a +. dt *. (poly.Spline.b +. dt *. (poly.Spline.c +. dt *. poly.Spline.d))) (polyX, polyY)

let compute_spline_tangent_in_step (ti, polyX, polyY) t =
  let dt = t -. ti in
  pair (fun poly -> poly.Spline.b +. dt *. (2. *. poly.Spline.c +. dt *. 3. *. poly.Spline.d)) (polyX, polyY)

let compute_spline (times, polyXs, polyYs) t =
  let t_indice = fast_find_indice_for_spline_time times t in
  compute_spline_in_step (times.(t_indice), polyXs.(t_indice), polyYs.(t_indice)) t
let compute_spline_tangent (times, polyXs, polyYs) t =
  let t_indice = fast_find_indice_for_spline_time times t in
  compute_spline_tangent_in_step (times.(t_indice), polyXs.(t_indice), polyYs.(t_indice)) t

let speed2inv_break_speed_table_hash = 40
let speed2inv_break_speed_table = Array.create (max_speed / speed2inv_break_speed_table_hash + 2) 0.
let speed2inv_break_speed v = 
  if v > max_speed then max_speed else
  int_of_float (float_of_int v *. speed2inv_break_speed_table.((v - 1) / speed2inv_break_speed_table_hash + 1)) + 40
let prepare_speed2inv_break_speed =
  let init_car v = {Lib.d = i_to_fix 0; v = i_to_fix v; pos = posmap_to_posx (0, 0) } in
  for i = 0 to (max_speed/speed2inv_break_speed_table_hash) do
    let car = next_state (init_car (i * speed2inv_break_speed_table_hash)) Brake in
    speed2inv_break_speed_table.(i) <- if fix_to_i car.v = 0 then 1. else float_of_int ((i * speed2inv_break_speed_table_hash) - 40) /. float_of_int (fix_to_i car.v)
  done

let speed2inv_friction_speed_table_hash = 40
let speed2inv_friction_speed_table = Array.create (max_speed / speed2inv_friction_speed_table_hash + 2) 0
let speed2inv_friction_speed v = 
  if v > max_speed then max_speed else
  speed2inv_friction_speed_table.((v - 1) / speed2inv_friction_speed_table_hash + 1)
let prepare_speed2inv_friction_speed =
  let init_car v = {Lib.d = i_to_fix 0; v = i_to_fix v; pos = posmap_to_posx (0, 0) } in
  for i = 0 to (max_speed/speed2inv_friction_speed_table_hash) do
    let car = next_state (init_car (i * speed2inv_friction_speed_table_hash)) Left in
    speed2inv_friction_speed_table.(i) <- if fix_to_i car.v = 0 then 40 else fix_to_i car.v
  done

let speed2max_curve_mixed_brake_table_hash = 40
let speed2max_curve_mixed_brake_table = Array.create (max_speed / speed2max_curve_mixed_brake_table_hash + 2) 0.
let speed2max_curve_mixed_brake v = speed2max_curve_mixed_brake_table.((v - 1) / speed2max_curve_mixed_brake_table_hash + 1)
let prepare_speed2max_curve_mixed_brake =
  let init_car v = {Lib.d = i_to_fix 0; v = i_to_fix v; pos = posmap_to_posx (0, 0) } in
  for i = 0 to (max_speed/speed2max_curve_mixed_brake_table_hash) do
    let speed = i * speed2max_curve_mixed_brake_table_hash in
    let car = next_state (init_car speed) Right in
    let car = next_state car Brake in
    let angle = d_angle2angle (fix_to_i car.d) in
    let curve = angle /. distance (fix_to_float car.pos.x, fix_to_float car.pos.y) (0., 0.) in
    speed2max_curve_mixed_brake_table.(i) <- curve
  done

let backstep points =
  let points_a = Array.of_list points in
  let (spline_times, _, _ as spline) = Spline.spline points_a in
  let speed2dist v =
    let car = next_state {Lib.d = i_to_fix 0; v = i_to_fix v; pos = posmap_to_posx (0, 0) } Roll in
    fix_to_float car.pos.x
  in
  let get_previous_point_on_spline dist ti _point =
    let ti = max (ti -. dist) 0. in
    compute_spline spline ti, ti, compute_spline_tangent spline ti
  in
  let small_backstep (point, vmax, ti, direction) =
    let dist = speed2dist vmax in
    let prev_point, prev_ti, prev_direction = get_previous_point_on_spline dist ti point in
    let dist = distance prev_point point in
    let curve = abs_float (vec2angle prev_direction direction) /. dist in    
    let valid_speed = curve2max_speed curve in
    let new_vmax =
      if valid_speed < vmax then (
	(* too fast ! *)
	(* we can break so that previous speed can be even faster than vmax *)
	(*if valid_speed < 100 then prerr_endline "Eurk!" ; *)
	valid_speed
      ) else
	if false then (* OPTION1: don't use this? *)
	  speed2inv_break_speed vmax
	else
	  let mixed_brake_curve = speed2max_curve_mixed_brake vmax in
	  if curve < mixed_brake_curve then
	    if false then (* OPTION2: the curve is not that bad, but it may break?? *)
	      speed2inv_break_speed vmax
	    else
	      let d_speed = speed2inv_break_speed vmax - vmax in
	      let curve_ratio = mixed_brake_curve /. curve in
	      let brake_ratio = if curve_ratio > 6. then if curve_ratio > 50. then 1. else 0.9 else 0.5 in
	      vmax + int_of_float (float_of_int d_speed *. brake_ratio)
	  else
	    speed2inv_friction_speed vmax in

    (*prerr_endline (Printf.sprintf "vmax is %d at (%6.1f, %6.1f)" (vmax/100) (fst point) (snd point)) ;*)
    prev_point, new_vmax, prev_ti, prev_direction
  in
  let rec small_backsteps oracle (point, vmax, ti, direction) =
    let prev_point, prev_vmax, prev_ti, prev_direction = small_backstep (point, vmax, ti, direction) in
    if prev_ti = 0. then oracle else
    small_backsteps ((point, ti, vmax) :: oracle) (prev_point, prev_vmax, prev_ti, prev_direction)
  in
  let ti_last = spline_times.(Array.length spline_times - 1) in
  let point_last = compute_spline spline ti_last in
  let direction_last = compute_spline_tangent spline ti_last in
  small_backsteps [] (point_last, max_speed, ti_last, direction_last)

let max_speeds2oracle max_speeds =
  let time_indices = Array.of_list (List.map (fun (_, ti, _) -> ti) max_speeds) in
  let vmaxes = Array.of_list (List.map (fun (_, _, vmax) -> vmax) max_speeds) in
  let prev_indice = ref 0 in 
  let find_indice t =
    try max (array_find_index (fun t' -> t < t') time_indices - 1) 0
    with Not_found -> Array.length time_indices - 1
  in
  fun ti ->
    if ti < time_indices.(!prev_indice) || ti >= time_indices.(!prev_indice + 1) then 
      (* the cached value is no good anymore *) 
      prev_indice := find_indice ti ;
    vmaxes.(!prev_indice)

let draw_spline points =
  let (times, _, _ as spline) = Spline.spline (Array.of_list points) in
  for i = 0 to Array.length times - 2 do
    let ti, ti' = times.(i), times.(i+1) in
    let nb_step = 100 in
    let ti_step = (ti' -. ti) /. (float_of_int nb_step) in

    let t = ref ti in
    for _i = 1 to nb_step do
      t := !t +. ti_step ;
      let point = compute_spline spline !t in
      Vizualiser.colored_point_at Graphics.green (point_from_float point)      
    done
  done

let draw_max_speeds points =
  let points = grep_with_previous (fun (p1, _, _) (p2, _, _) -> distance p1 p2 > 30.) points in
  List.iter (fun (point, _ti, max_speed) -> 
    Vizualiser.display_speed max_speed (point_from_float point)
  ) points

let draw_points map points trc = 
  let init_state = {Lib.d = i_to_fix 0; v = i_to_fix 0; pos = posmap_to_posx map.start } in
  Vizualiser.display_map map ;
  Vizualiser.display_trace init_state [trc] ;
  draw_spline points ;
  List.iter (fun p -> Vizualiser.colored_point_at_ Graphics.red (point_from_float p) 4) points

let save_points points name = 
  let out = open_out name in
  Marshal.to_channel out points [];
  close_out out

let read_points name =
  let f = open_in name in
  let points = Marshal.from_channel f in
  close_in f ;
  points

let doit map_name =
  let map = Parsers.read_map map_name in
  let trc = Parsers.read_run (chop map_name ^ "c") in
  let points = ref (try read_points (map_name ^ ".spline.fix.more") with _ -> prune  (trc2points trc map)) in

  let max_speeds = backstep !points in
(*
  let oracle = max_speeds2oracle max_speeds in

  let (times, _, _) = Spline.spline (Array.of_list !points) in
  for i = 0 to Array.length times - 2 do
    let _ = oracle times.(i) in ()
  done ;
*)
(*  Vizualiser.zoom_factor := 4;*)
  Vizualiser.init_display();
  draw_points map !points trc ;

  draw_max_speeds max_speeds ;

  while true do
    let event = Graphics.wait_next_event [Graphics.Button_down;Graphics.Key_pressed] in
    if event.Graphics.keypressed then (save_points !points (map_name ^ ".spline.fix.more") ; failwith "finished") else
    if event.Graphics.button then
      let clicked_point = point_to_float (Vizualiser.unapply_zoom (Graphics.mouse_pos())) in
      let p1, p2 = two_mins_with (distance clicked_point) !points in
      (if distance clicked_point p1 < 8. then
	(* removing it *)
	points := List.filter (fun p -> p != (* on purpose*) p1) !points
      else
	let first_min = List.find (fun p -> p == p1 || p == p2) !points in
	points := collect (fun p -> if p == first_min then [p ; clicked_point] else [p]) !points);
      draw_points map !points trc
  done
