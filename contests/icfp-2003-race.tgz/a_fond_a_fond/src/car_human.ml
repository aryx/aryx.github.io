open Lib

(* TODO: frequency parameter, 
   TODO: continue-with-same-action option with period,
*)

let (engine : map -> state -> action) = fun _map _state ->
  Accel

