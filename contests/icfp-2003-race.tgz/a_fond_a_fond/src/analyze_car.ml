open Common
open Lib

let posx_to_float posx = float_of_int (fix_to_i posx) /. 65536.

let dist2time_and_speed__straight__with_0_initial_speed() =
  let init_car = {d = i_to_fix 0; v = i_to_fix 0; pos = posmap_to_posx (0, 0) } in
  let car = ref init_car in
  let counter = ref 0 in
  for i = 1 to 1000 do
    let nb = 10 in
    car := List.fold_left (fun car _ -> next_state car Accel) !car (repeat () nb) ;
    counter := !counter + nb ;
    print_endline (Printf.sprintf "%6.1f %5d %5d" (posx_to_float !car.pos.x) !counter (fix_to_i !car.v))
  done

let dist2time__straight__with_0_initial_speed__0_final_speed() =
  
  let rec stop_car car counter =
    if fix_to_i car.v > 0 then
      stop_car (next_state car Brake) (counter + 1)
    else
      print_endline (Printf.sprintf "%6.1f %5d" (posx_to_float car.pos.x) counter)
  in
  let init_car = {d = i_to_fix 0; v = i_to_fix 0; pos = posmap_to_posx (0, 0) } in
  let car = ref init_car in
  let counter = ref 0 in
  for i = 1 to 1000 do
    let nb = 10 in
    car := List.fold_left (fun car _ -> next_state car Accel) !car (repeat () nb) ;
    counter := !counter + nb ;
    stop_car !car !counter
  done

let speed2time_and_dist__to_have_0_final_speed() =
  
  let rec stop_car car counter =
    if fix_to_i car.v > 0 then
      stop_car (next_state car Brake) (counter + 1)
    else
      counter, car.pos.x
  in
  let init_car v = {d = i_to_fix 0; v = i_to_fix v; pos = posmap_to_posx (0, 0) } in
  for i = 0 to 463 do
    let speed = i * 100 + 41 in
    let time, dist = stop_car (init_car speed) 0 in
    prerr_endline (Printf.sprintf "%5d %5d %6.1f" speed time (posx_to_float dist))
  done

let speed2dist__for_one_top() =
  let d_angle2angle d_angle = 
    let d_angle = if d_angle > 205887 then d_angle - 411775 else d_angle in
    float_of_int d_angle /. 205887. *. 3.14 in 

  let init_car v = {d = i_to_fix 0; v = i_to_fix v; pos = posmap_to_posx (100, 220) } in
  let _tt = Array.make 10000 0 in
  let doit speed =
    let i_car = init_car speed in
    let car = ref i_car in
    car := next_state { !car with v = i_to_fix speed } Brake ;
    for i = 1 to 10 do
      car := next_state { !car with v = i_to_fix speed } Right
    done ;
    let angle = d_angle2angle (fix_to_i !car.d) in
    let curve = angle /. Trajectory.distance (fix_to_float !car.pos.x, fix_to_float !car.pos.y) (fix_to_float i_car.pos.x, fix_to_float i_car.pos.y) in
    prerr_endline (Printf.sprintf " %5d %2.6f %2.6f" speed curve (Trajectory.speed2max_curve_mixed_brake speed))
  in
  for i = 0 to 1463 do doit i done ;
  for i = 0 to 463 do doit (i * 100) done

let radius2time_and_speed() =
  let init_car v = {d = i_to_fix 0; v = v; pos = posmap_to_posx (0, 0) } in
   
   let stabilize next =
     let rec get_max_speed car =
       let car' = List.fold_left (fun car _ -> fst (next car)) car (repeat () 10) in
       if fix_to_i car'.v = fix_to_i car.v then car.v
       else get_max_speed car'
     in
     let rec do_one_circle car counter max =
       let car', nb = next car in
       let counter = counter + nb in
       if car'.pos.x < car.pos.x then
	 let max = if max = None then Some car.pos.x else max in
	 do_one_circle car' counter max
       else match max with
       | None -> (* initial raising *) do_one_circle car' counter None
       | Some max -> 
          (* second raise, done! *) max, 2 * counter
     in
     let max_speed = get_max_speed (init_car (i_to_fix 0)) in
     let radius, counter = do_one_circle (init_car max_speed) 0 None in
     radius, counter, max_speed
  in	

  let try_with next =
    let radius, time, stabilized_v = stabilize next in
    prerr_endline (Printf.sprintf "%7.1f %5d %6d" (posx_to_float radius) time (fix_to_i stabilized_v))
  in
(*
  for i = 4 downto 1 do
    let next car =
      let car = List.fold_left (fun car _ -> next_state car Left) car (repeat () i) in
      next_state car AccelLeft, i + 1
    in
    try_with next
  done ;
  for i = 2 to 10 do
    let next car =
      let car = List.fold_left (fun car _ -> next_state car AccelLeft) car (repeat () i) in
      next_state car Left, i + 1
    in
    try_with next
  done ;
  try_with (fun car -> next_state car AccelLeft, 1) ;
*)
  for i = 20 to 20 do
    let next car =
      let car = List.fold_left (fun car _ -> next_state car Accel) car (repeat () i) in
      next_state car AccelLeft, i + 1
    in
    try_with next
  done

let doit() = speed2dist__for_one_top()
