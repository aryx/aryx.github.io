
open Common
open Parsers
open Lib

type trace_map = (int *Lib.posx*run) array array 

type is_better =(int * Lib.posx * Lib.action list ->
     int * Lib.posx * Lib.action list -> bool)

exception Error


let is_better_trivial (i1,s1,r1) (i2,s2,r2) =
  if i1 < i2 
  then true
  else 
    if List.tl r1 = r2 
    then
      true (* Probably the next step *)
    else false

let trace_trivial = [Accel; AccelRight; AccelLeft; Left; Right; Roll; Brake]

let heuristic_trivial () state = (trace_trivial,())


open Branchbound

let rec follow_path pos_list s =
  let {x=x;y=y} =  s.pos in
  match pos_list with
      [] -> (trace_trivial,[])
    | npos::l -> let {x=x1;y=y1} =npos in
	if x = x1 && y = y1 (*very improbable*)
	then follow_path l s 
	else (* Try to reach x1,y1 *)
	  let cmp (n1,a1) (n2,a2) = Pervasives.compare n1 n2 in
	  let n_actions = List.sort cmp (List.map (fun act -> (norm ((next_state s act).pos)  npos ,act)) trace_trivial) in
	  (List.map snd n_actions, l)


let rec follow_trace trace_list s =
  match trace_list with
      [] -> ([],[])
    | p::l -> 
	((match p with 
	    Roll -> [Roll ;Accel  ] 
	  | Left -> [Left ;AccelLeft ] 
	  | Right -> [Right ;AccelRight] 
	  | Brake -> [Brake ;Roll ] 
	  | Accel  -> [Accel]
	  | AccelRight -> [AccelRight; Accel ]
	  | AccelLeft ->  [AccelLeft ;Accel ]),l)


let abstr l =
  let rec _abstr l b =
    match l with 
	[] -> []
      | e::l -> if b then _abstr l false else e::(_abstr l true)
  in
  _abstr l true



let optimize trace_file map_file =
  let map = Parsers.read_map map_file in
  let trace =  read_run trace_file in
  let cell_list = List.fold_left 
    (fun (state,tr) e  -> 
      let nst = next_state state e in
      (nst,nst.pos::tr)) ((Simulator.start_state map),[]) trace  in
  Algo.brute_force map_file follow_path   (abstr (List.rev (snd cell_list))) map

let optimize_trace trace_file map_file =
  let map = Parsers.read_map map_file in
  let trace =  read_run trace_file in
  Algo.brute_force map_file follow_trace  trace map
