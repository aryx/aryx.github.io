open Common
open Lib


let _MaxFreinage = ref 100
let _UseBrake = ref true

(* PLUG every place where Lib.norm *)
let (assisted: state -> time -> trajectory -> oracle -> action) = fun state time trajectory oracle -> 
  (* let res =  (Accel, time) in *)
  let speed_closest_point1    = oracle time in
  let position_closest_point = trajectory time in
  let error_trajectory = (Lib.dist_escalier state.pos position_closest_point) in

(*  let _ = Printf.printf "error trajectory = %d\n" (fix_to_i error_trajectory) in *)

  let speed_orig = fix_to_i speed_closest_point1.vmax in
  let correction1 = fix_to_i error_trajectory in
  let correction = min correction1 500 in
  let speed_closest_point = {vmax = 
			      i_to_fix (max (speed_orig - correction) 500) (* INVARIANT *)
			    } in

  let speed_closest_point = speed_closest_point1 in

(*
  let _ = Printf.printf "curr = %d, max_closer = %d, max_corrected = %d,  error trajectoire = %d\n
      pos point (x = %d, y = %d), pos time = (x = %d, y = %d)\n"
      (fix_to_i state.v) 
      (fix_to_i speed_closest_point1.vmax) 
      (fix_to_i speed_closest_point.vmax) 
      (fix_to_i error_trajectory)
      (fix_to_i state.pos.x)
      (fix_to_i state.pos.y)
      (fix_to_i position_closest_point.x)
      (fix_to_i position_closest_point.y)
  in
  VVVV
*)

      
  let error_max = i_to_fix 3000 in
  if((infeqx state.v speed_closest_point.vmax)
(*      &&  (error_trajectory < error_max) *)
    )
  then

    let actions = 
      [Accel;  AccelRight; AccelLeft] +> List.map 
	(fun dir -> let next = (next_state state dir) in  
	(* NON
	*)
	let time_of_closest_point = time +. (Lib.norm state.pos next.pos) in (* PLUG *)
	let closest_point_here = trajectory time_of_closest_point in

	let distance_next_closest = Lib.dist_escalier position_closest_point next.pos in 
	let distance_next_closest_here = Lib.norm closest_point_here next.pos in
	
	(*  show that we are not in the precision domain => mean nothing *)
(*	let _ = Printf.printf " dir: %s, distance %d, next = (%d, %d)\n, closest (%d, %d) " 
	    (string_of_action dir) (fix_to_i distance_next_closest)
	    (fix_to_i next.pos.x)
	    (fix_to_i next.pos.y)
	    (fix_to_i position_closest_point.x)
	    (fix_to_i position_closest_point.y)
	in (* VVVV *)
*)

	(dir, distance_next_closest_here )(* distance_next_closest MOINS BON) *)
	)
	+> List.sort (fun (dir1, dist1) (dir2, dist2) ->dist1  <=> dist2)
    in
    List.hd actions +> fst
	
  else 
   (*  if ((infeqx state.v speed_closest_point.vmax) && (error_trajectory >= error_max)) *)

    (* try a roll *)
    let next_roll = next_state state Roll in
    let time_of_closest_point_roll = time +. (Lib.norm state.pos next_roll.pos) in (* PLUG *)
    let speed_at_closest_point_roll = oracle time_of_closest_point_roll in

   (*  if ((infeqx state.v speed_closest_point.vmax) && (error_trajectory >= error_max)) *)

    if false
(*
    if((supx next_roll.v (speed_at_closest_point_roll.vmax)) &&
       ( ((fix_to_i next_roll.v) - (fix_to_i speed_at_closest_point_roll.vmax)) > 4)
(*	 && (not ((fix_to_i next_roll.v) < 2000)) *)
      )
*)
	 


    then Brake
    else 
      let actions = 
	[Left; Right; Roll] +> List.map 
		
	  (fun dir -> let next = (next_state state dir) in  
	(* NON
	*)
	  let time_of_closest_point = time +. (Lib.norm state.pos next.pos) in (* PLUG *)
	  let closest_point_here = trajectory time_of_closest_point in
		(* KAN error de trajectoire (car a loupe de freiner) alors regarder plus loin *)
	  
		
	  let distance_next_closest = Lib.dist_escalier position_closest_point next.pos in 
	  let distance_next_closest_here = Lib.norm closest_point_here next.pos in
	  
	  let speed_closet_point = (oracle (time +. (Lib.norm state.pos next.pos))) in (* PLUG *)
	  let speed_next = next.d in
	
	(*  show that we are not in the precision domain => mean nothing *)
(*	let _ = Printf.printf " dir: %s, distance %d, next = (%d, %d)\n, closest (%d, %d) " 
	    (string_of_action dir) (fix_to_i distance_next_closest)
	    (fix_to_i next.pos.x)
	    (fix_to_i next.pos.y)
	    (fix_to_i position_closest_point.x)
	    (fix_to_i position_closest_point.y)
	in (* VVVV *)
*)

	  (dir, distance_next_closest_here, speed_closet_point )(* distance_next_closest MOINS BON *)
	  )
	  +> List.sort (fun (dir1, dist1, _) (dir2, dist2, _) ->dist1  <=> dist2)
	  +> List.filter (fun (dir, dist, speed) -> 
	    if !_UseBrake then 
	      let next = (next_state state dir) in
	      if (infeqx next.v speed.vmax) then true
	      else 
	    (* OPTIONPAD *)
		let diff = abs ((fix_to_i next.v) - (fix_to_i speed.vmax)) in	    	      	    (* TODO check not too much speed  with coeff *)
		if ( diff > (!_MaxFreinage)) then false else true
	    else true

	    (* true *)
			 )
      in 
      if (empty actions) then (let _ = pr2 "Braking" in Brake)
      else List.hd actions +> fst3


	


  
