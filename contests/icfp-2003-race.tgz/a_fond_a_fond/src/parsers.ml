open Common

open Lib

let (read_map: filename -> map) = fun file ->
    let xs = cat file in
    (match xs with
    | width_s :: height_s :: lines_s -> 
	let width  = int_of_string width_s in
	let height = int_of_string height_s in
	let start = ref None in
	let array = Array.make_matrix width height Space in
	let _ = 
	  lines_s +> iter_index (fun aline i -> 
	    for j = 0 to String.length aline - 1 do
	      let c = aline.[j] in
		array.(j).(i) <- 
		  (match c with
		  | 'g' -> Wall Green
		  | 'b' -> Wall Blue
		  | 'r' -> Wall Red
		  | 'w' -> Wall White
		  | '.' -> Space
		  | '*' -> (start := Some (j,i); Space)
		  | '!' -> Goal
		  | _ -> internal_error ("not good format ? (found " ^ String.make 1 c ^ ")")
		  )
	    done)
	    in
	
	{ width  = width;
	  height = height;
	  world  = array;
	  start  = just (!start);
	} 
	  
    | _ -> internal_error "wrong format ?"
    )
    
open Action

let rec get_all_actions lexbuf =
  try
    let x = actionLex lexbuf in
    x :: get_all_actions lexbuf
  with _ -> []
  

let (read_run: filename -> action list) = fun file -> 
  get_all_actions (Lexing.from_channel (open_in file))

let action2string = function
  | Brake -> "b."  
  | Left -> "l."   
  | Right -> "r."
  | Accel -> "a."   
  | AccelRight -> "ar."
  | AccelLeft -> "al."
  | Roll -> "." 

let read_trace map_name =
  let rec read_one f =
    try
      match input_line f with
      | "" -> read_one f
      | s -> get_all_actions (Lexing.from_string s) :: read_one f
    with _ -> []
  in
  try
    read_one (open_in (map_name ^ ".trace"))
  with Sys_error _ -> []

let prepare_save_trace map_name actions_already_done =
  let trace = open_out_gen [ Open_append ; Open_creat ] 438 (* 0666 *) (map_name ^ ".trace") in
  output_string trace "\n" ;
  List.iter (fun action -> output_string trace (action2string action)) actions_already_done ;
  fun action -> output_string trace (action2string action) ; flush trace
