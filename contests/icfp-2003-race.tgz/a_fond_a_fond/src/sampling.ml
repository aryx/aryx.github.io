
(* int -> cellcoord list -> pixelcoord list = fun samplerate positions -> *)

(* lourd, doit faire sorte de bezier aussi mais cette fois en grain plus fun,
   peut appeler gimp ??
*)


