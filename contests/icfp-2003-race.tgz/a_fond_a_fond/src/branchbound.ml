open Common
open Lib
open Parsers


type frame = { xmin:fixed_int; xmax:fixed_int;
               ymin:fixed_int; ymax:fixed_int;
               dmin:fixed_int; dmax:fixed_int;
               vmin:fixed_int; vmax:fixed_int }

let (verif_frame: state -> frame -> bool) = fun car fr ->
  (infeqx fr.xmin car.pos.x) && (infeqx car.pos.x fr.xmax) &&
  (infeqx fr.ymin car.pos.y) && (infeqx car.pos.y fr.ymax) &&
  (infeqx fr.dmin car.d) && (infeqx car.d fr.dmax) 

let (_delta_d:fixed_int) = i_to_fix 50000

exception NoRunInterresting
exception RunInterresting of run*state

let rec (find_best_callrec: action -> run -> int -> (action*(run*int)) list -> (run*int)) =
  fun action run max ->
  function [] -> (action::run,max)
    | ((a,(r,i))::q) -> 
	if i<max then (find_best_callrec a r i q)
      	else (find_best_callrec action run max q)

let (minx: fixed_int -> fixed_int -> fixed_int) = fun a b ->
  if (infx a b) then a else b
let (maxx: fixed_int -> fixed_int -> fixed_int) = fun a b ->
  if (infx a b) then b else a
(* let (xsqrt: fixed_int -> fixed_int) = fun x -> *)
(*   let u = ref (max x (i_to_fix 1)) in *)
(*   let l = ref (i_to_fix 0) in *)
(*     while not (!u = !l) do *)
(*       let g = (divx (plusx !l !u) (i_to_fix 2)) in *)
(* 	if (infx x (mulx g g)) then u:=g else l:=(plusx g (i_to_fix 1)) *)
(*     done; !u *)



let print_action = function
    Accel -> print_string "a."
  | AccelRight -> print_string  "ra."
  | AccelLeft -> print_string "la."
  | Left -> print_string "l."
  | Right -> print_string "r."
  | Roll -> print_string "."
  | Brake -> print_string "b."

let print_run = (List.iter print_action )

let plot p = Graphics.plot (fixed_int_to_posmap p.x) (768-(fixed_int_to_posmap p.y));;

type curve = CurvLine | CurvLeft | CurvRight

let actionCurv = fun c ->
 match c with
      CurvLine -> [Accel;Roll;Brake]
    | CurvLeft -> [Accel;AccelLeft;Left;Roll;Brake]
    | CurvRight -> [Accel;AccelRight;Right;Brake]




let (in_interval_d: fixed_int -> fixed_int -> fixed_int -> bool) =
  fun d1 d2 ->
    if (infeqx d1 d2) then 
      fun d -> (infeqx d1 d)&&(infeqx d d2)
    else  
      fun d -> (infeqx d d2)&&(infeqx d1 d)

let arg2pi x =
  let dmin = ref x in
    while (infeqx !dmin (negx pi_x)) do dmin := (plusx !dmin two_pi_x) done;
    while (supx !dmin pi_x)        do dmin := (minusx !dmin two_pi_x) done;
    !dmin


let compute_distMaxFrame = fun state frame ->
  (max (norm state.pos {x=frame.xmin; y=frame.ymin})
     (max (norm state.pos {x=frame.xmin; y=frame.ymax})
	(max (norm state.pos {x=frame.xmax; y=frame.ymin})
	   (norm state.pos {x=frame.xmax; y=frame.ymax}))))

    
let promize = fun curv map frame state ->
  let distMaxFrame = (compute_distMaxFrame state frame) in
  match curv with
    | CurvLine -> 
	(fun st ->
 	   not(is_crash_cell map st) &&
	   ((norm state.pos st.pos)<distMaxFrame) &&
  	   (infeqx frame.vmin st.v) && (infeqx st.v frame.vmax) )
    | CurvLeft ->
	(fun st ->
 	   not(is_crash_cell map st) &&
	   ((norm state.pos st.pos)< distMaxFrame) &&	
	   (in_interval_d frame.dmin state.d st.d) &&
  	   (infeqx frame.vmin st.v) && (infeqx st.v frame.vmax) )
    | CurvRight ->
	(fun st ->
 	   not(is_crash_cell map st) &&
	   ((norm state.pos st.pos)<distMaxFrame) &&	
	   (in_interval_d state.d frame.dmax st.d) &&
  	   (infeqx frame.vmin st.v) && (infeqx st.v frame.vmax) )
	

let print_state state =
  let xy = state.pos in
  let (x,y) = pair (compose string_of_int fixed_int_to_posmap) (xy.x, xy.y) in
  let (v,d) = pair (compose string_of_int  fix_to_i)  (state.v,state.d) in
  print_string ("cell ("^x^","^y^") v="^v^" d="^d)

 
  


let (best_run: map -> state -> frame -> curve -> run*state) = fun map state frame curv ->
  let stop = fun st -> (verif_frame st frame) in
  let prom = (promize curv map frame state) in
  let acList = (actionCurv curv) in 
  let rec (best_run_rec: state  -> (run*state)) = fun state  ->
    print_state state; 
    let rec it_rec = function
	[] -> raise NoRunInterresting
      | a::q -> 
	  let s=(next_state state a) in
	    if (prom s) then
	      if (stop s) then
		([a],s)
	      else
		(print_string " I try ";print_action a;print_newline ();
		 try
		   let (run,st)=(best_run_rec s) in
		     (a::run,st)
		 with
		   | NoRunInterresting -> (it_rec q))
	    else (print_string " I dont believe in ";print_action a;
		  print_string (" at "^(string_of_state s));print_newline ();
		  (it_rec q))
    in (it_rec acList)
  in (best_run_rec state)



