
open Common

open Lib

(* the idea: use your own editor :) pipe spirit, but use a know color to indicate the trace !!!!! 
UPDATE: sux; cos will have traj in big step => pb to make the go_forward
 => better to have done our own spline
*)

let (map_to_image: map -> filename -> unit) = fun map filename -> ()
(* cf ray tracer *)

(*
let (image_to_trajectory: filename -> trajectory) = fun filename -> []
*)


(* TODO script fu: given a list of checkpoint (computed by pixel), call gimp to compute
   the shape
*)
