open Spline
open Trajectory


(* 
F(x) =  (x0 - x(t))x'(t) + (y0 -y(t))y'(t) = 
   (x0 -a)*b (0)
   (x0 -a)*2c + b^2 (1)
   (x0-a)*3d + 3bc (2)
   4bd+2c^2 (3)
   5cd  (4)
   3d^2  (5)
*)

(* F'(x) =
   (x0 -a)*2c + b^2  (0)
   2 [(x0-a)*3d + 3bc] (1)
   3 [4bd+2c^2] (2)
   4 [5cd] (3)
   5 [3d^2] (4)
*)

let deriv p = 
  let rec _deriv  p exp =
    match p with 
	[] -> []
      | e::l -> (e*.(float_of_int exp)):: (_deriv l (exp + 1))
  in
  _deriv p 0;;

let _ = deriv [1.; 2.; 3.] =  [0.; 2.; 6.]


let rec eval p t = 
  match p with
      [] -> 0.
    | e:: l -> e +. (eval l t)*. t


let _  = eval [2.; 1. ; 3.] 2.  = 16.

let rec add p q = 
  match (p,q) with
      ([],[]) -> []
    | (l,[]) -> l
    | ([],l) -> l
    | (e1::l1,e2::l2) -> (e1 +. e2) ::(add l1 l2)


let newton phi t =
  let nb_it = 30 in
  let rec iter n approx = 
    if n = 0 
    then approx
    else 
      let app =(phi approx) in
      iter (n-1) app 
  in
  iter nb_it t





let (find_point: (float * float) -> float -> (splineCubique * splineCubique) -> (float*(float * float))) =
  fun (x0,y0) t (pX,pY) ->
  let {a=a;b=b;c=c;d=d} = pX
  and {a=a';b=b';c=c';d=d'} = pY in
  let f_ _x {a=a;b=b;c=c;d=d} = 
    [ 
      (_x -. a)*.b ; 
      ((_x -.a)*.c *.2.) -. (b *. b) ;
      3. *.((_x -. a)*. d) -. 3.*.(b*.c) ;
      -4.*.(b*.d)-.(2.*.(c*.c)) ;
      -5. *. (c *. d) ;
      -3. *. (d *. d)] in

  let pF = add (f_ x0 pX) (f_ y0 pY) in
  let pF' = deriv pF in
  let phi t = 
    let fx = (eval pF t) in
    let fx' = (eval pF' t) in
    t -. ( fx /. fx') in
  let tn = newton phi t in
  (tn,(eval [a;b;c;d] tn, eval [a';b';c';d'] tn));;
    


let find_time_on_spline  pos t0 i splines =
  let (times,pX,pY) = splines in
  let (t,pXt,pYt) = (times.(i), pX.(i), pY.(i)) in
  let (t1,(x1,y1)) = find_point pos t (pXt,pYt) in
  let (i_,t_,pXt_,pYt_) = try (i+1, times.(i+1),pX.(i+1),pY.(i+1)) with _ -> (i,t,pXt,pYt) in
  let (t2,(x2,y2)) = find_point pos t_ (pXt_,pYt_) in
  if (Spline.norm pos (x1,y1)) < (Spline.norm pos (x2,y2)) 
  then  (i,t1,(x1,y1))
  else  (i_,t2,(x2,y2)) 
  
(*
let evaluate state  i spline = 
  let {pos = {x= x;y=y} ; v= v ; d = d} = state in
  let pos = pair float_of_fix (x,y) in
  let (times,pX,pY) = splines in
  let t = times.(i) and pXt = pX.(i) and pYt = pY.(i) in
  let (i_,t_,pXt_,pYt_) = try (i+1, times.(i+1),pX.(i+1),pY.(i+1))  with _ -> (i,t,pXt,pYt) in
  let (t1,(x1,y1)) = find_time pos t (pXt,pYt) in
  let (t2,(x2,y2)) = find_time pos t_ (pXt_,pYt_) in
  if (Spline.norm pos (x1,y1)) < (Spline.norm pos (x2,y2)) 
  then  (i,t1,(x1,y1))
  else  (i_,t2,(x2,y2)) 

*)

open Vizualiser
open Trajectory
(*
let test points  (x,y)=
  let cell = (point_from_float (x,y)) in
  let (times,pX,pY) = Spline.spline (Array.of_list points) in
  let near = find_point (x,y) ((times.(0)+. times.(1))/. 2.0) (pX.(0),pY.(0)) in
  init_display (); draw_spline points ; 
  print_float (fst near); print_string " "; print_float  (snd near) ;
  Vizualiser.colored_point_at Graphics. black cell ;
  Vizualiser.colored_point_at Graphics. black (point_from_float near) ;
*)
  




