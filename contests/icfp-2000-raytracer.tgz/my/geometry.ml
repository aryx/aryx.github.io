open Common

type form = 
  | Plane  of vector * float (* normal * distance *)
  | Sphere of point * float  (* center * radius *)
type surface_fonction = (float * float * float) -> (color * (float * float * float))
(* (float * float * float) *) (* just a pixel color *) (* TODO apres first arg = int (face *)
type obj = (form * surface_fonction)

type ray = point * vector (* R0 * Rd, cant make only vector cos 
			     after the ray dont come only from the eye, ray from obj after *)

let (point_from_ray: ray -> float -> point) = 
  fun ((x,y,z), (dx, dy, dz)) dist -> (x +. (dist *. dx), y +. (dist *. dy), z +. (dist *. dz))

(* sphere and plane *)
(* we require that rd is a unit vector !! for plane (otherwise we have - Pn*Pn*d 
 and for sphere, otherwise tca is not the projection of loc on the ray 
 could do in this func the normalisation, but then t is function of this
 normalise vector => before return tintersection we should too do inverse
 transfo
*)
let (intersection: ray -> form -> float maybe) = fun r f ->
  match (r,f) with
  | ((r0, rd), Plane (pn, d)) -> 
      let divisor = (dotproduct (pn, rd)) in
      if divisor = 0.0 then None
      else (
	let tintersection = -. (dotproduct (pn, r0) -. d) /. divisor in
	if tintersection < 0.0 then None
	else Just tintersection
       )
  | ((r0, rd), Sphere (sc, r)) -> 
      let lloc = distance (sc, r0) in
      let tca  = dotproduct (minus_point (sc,r0), rd) in
      if tca < 0.0 then None
      else 
	(
	 let d2   = ((square lloc) -. (square tca)) in
	 let r2   = square r in
	 let thc2  = r2 -. d2 in
	 if d2 > r2 then None
	 else Just (tca -. (sqrt thc2))
	)
(* TODO *)
let (normal: point -> form -> ray -> vector) = fun p form (sc, rd) ->
  match form with
  | (Plane (pn, d)) -> mult_coeff pn (-1.0) (* TODO, check on which side we are *)
  | (Sphere (sc, r)) -> minus_point (p, sc)

let (oppose: vector -> vector) = fun v -> mult_coeff v (-1.0) 


type constructive_solid = 
  | Leaf of obj
  | Union of constructive_solid * constructive_solid
let rec (flatten_constructive_solid: constructive_solid -> obj list) = function
  | Leaf x -> [x]
  | Union (x1, x2) -> flatten_constructive_solid x1 @ flatten_constructive_solid x2
let rec map_constructive_solid = fun f -> function
  | Leaf x -> Leaf (f x)
  | Union (x1, x2) -> Union (map_constructive_solid f x1, map_constructive_solid f x2)



(* TODO, make all affine transfo my matrix multiplication, homogene coord ?? *)
let (translate: vector -> form -> form) = fun v -> function
  | Sphere (p, r) -> Sphere (add_vector p v, r)
  | Plane (pn, d) -> Plane (pn, d) (* TODO *)

(* TODO *)
let (opposite: vector -> vector -> vector) = fun normal incident -> normal

