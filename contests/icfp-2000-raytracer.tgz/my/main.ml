(* in interpreter, *)
(* in interactive: ocamllex lexer.mll; ocamlyacc parser.mly; 
 load common, geometry, format, raytrace, parser, lexer, program
load program then parser then lexer
   but must remove the open stuff in mll and mly
 *)

(* 
#use "parser.ml";;
#use "lexer.ml";;
#trace transit;;
#trace transit_etoile;;
#trace apply_op;;
#print_depth 15000;;
#print_length 15000;;

let v channel = 
   let lexbuf = Lexing.from_channel  channel in                                               
   main token lexbuf
let v2 channel = 
   let lexbuf = Lexing.from_channel  channel in                                               
   (eval (main token lexbuf, []))
let v3 channel = 
   let lexbuf = Lexing.from_channel  channel in                                               
   (transit_etoile ([], [], main token lexbuf))
let res = let file = open_in "tests/fact" in v2 file
let res = let file = open_in "tests/spheres.gml" in v3 file
let res = let file = open_in "tests/fib.gml" in v3 file
(* TODO pb apply, not in lexer, must detect it *)
(* TODO, why when subi inversed, dont work ? *)

*)


(**************************************************************************)


exception Pb of Interpreter.token_list
let _ =                                                                                     
  let result = 
    (try                                                                                       
      let lexbuf = Lexing.from_channel stdin in                                               
      Parser.main Lexer.token lexbuf
    with _ ->
      print_string "pb syntaxe\n"; exit 0
    ) in
  let result = (try Interpreter.eval (result, []) with _ -> print_string "pb eval\n"; exit 0) in
  print_string "cava\n"
(*    Program.print_result  *)
(*  raise (Pb result) *)

