type token =
    INT of (int)
  | REAL of (float)
  | STRING of (string)
  | BINDER of (string)
  | OPERATOR of (string)
  | IDENTIFIER of (string)
  | LBRACKET
  | RBRACKET
  | LBRACE
  | RBRACE
  | TRUE
  | FALSE
  | EOF

val main :
  (Lexing.lexbuf  -> token) -> Lexing.lexbuf -> Interpreter.token_list
