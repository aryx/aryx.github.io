%{
open Interpreter
%}
%token <int> INT
%token <float> REAL
%token <string> STRING BINDER OPERATOR IDENTIFIER
%token LBRACKET RBRACKET LBRACE RBRACE 
%token TRUE FALSE
%token EOF

%start main
%type <Interpreter.token_list> main
%%
main:
    token_list EOF		                { $1 }
token_list:
| /* empty */      {[] } 
| token token_list {$1::$2}
token:
| OPERATOR   { Operator $1 }
| IDENTIFIER { Identifier $1 }
| BINDER     { Binder $1 }
| TRUE       { NormalValue (Boolean true)}
| FALSE      { NormalValue (Boolean false)}
| INT        { NormalValue (Int $1)}
| REAL       { NormalValue (Real $1)}
| STRING     { NormalValue (String $1)}
| LBRACE   token_list RBRACE   { Function $2 }
| LBRACKET token_list RBRACKET { Array1 $2 }


