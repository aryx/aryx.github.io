open Geometry
open Raytracer
open Common

type token_list = expr list
and  expr = (* cant use token cos make clash with ocamlyacc token type *)
  | Function of token_list
  | Array1    of token_list
  | Operator of string
  | Identifier  of string
  | Binder      of string
  | NormalValue of base_value
and base_value = 
  | Boolean of bool
  | String  of string
  | Int     of int
  | Real    of float
(* can separate basevalue above too to simplify (cos value != code), but separate the entity
   make transit more complex, cos force to transform code_base_value in base_value
   can introduce a token_group too, but in transit force to PM on Token (BaseValue ...)
    TODO same ?
 *)

type state  = env * values * code
and  values = valu list
and  valu   = 
  | BaseValue of base_value
  | Closure of closure
  | Array of array
(* TODO *)
  | Point of point
  | Object of constructive_solid
  | Light  of light

and  closure = env * code
and  array   = values
and  env     = (string * valu) list
and  code    = token_list


exception Transit of state
exception ApplyOp of (string * values)
exception Eval    of state
let rec (transit: state -> state) = function
  | (e, s,          (NormalValue v)::c) -> (e,        (BaseValue v)::s, c)
  | (e, v::s,       (Binder x)::c)      -> ((x,v)::e, s, c)
  | (e, s,          (Identifier x)::c)  -> (e, (List.assoc x e)::s, c)
  | (e, s,          (Function c')::c)   -> (e, (Closure (e, c'))::s, c)
  | (e, (Closure (e',c'))::s, (Operator "apply")::c) ->
      let (e'', b, []) = transit_etoile (e', s, c') in
      (e, b, c)
  | (e, s,          (Array1 c')::c)      ->
      let (e', vs, []) = transit_etoile (e, [], c') in
      (e, (Array (List.rev vs))::s, c)
  | (e, (Closure (e2,c2))::(Closure (e1,c1))::(BaseValue (Boolean x))::s, (Operator "if")::c) ->
      let (e'', b, []) = (if x then transit_etoile (e1, s, c1) else transit_etoile (e2, s, c2)) in
      (e, b, c)
  | (e, s, (Operator op)::c) -> (e, apply_op op s, c)
  | x -> raise (Transit x)
and (transit_etoile: state -> state) = function 
  | (t, res, []) as x -> x
  | x -> transit_etoile (transit x)
(* (try let s2 = transit s in transit_etoile s2 with _ -> s ) *) 
and (apply_op: string -> values -> values) = fun op s ->
  (match(op, s) with
    (* TODO, x en y *)
  | ("addi", (BaseValue (Int x))::(BaseValue (Int y))::xs)   -> (BaseValue (Int (x+y)))::xs
  | ("addf", (BaseValue (Real x))::(BaseValue (Real y))::xs) -> (BaseValue (Real (x+.y)))::xs
  | ("lessi",(BaseValue (Int x))::(BaseValue (Int y))::xs)   -> (BaseValue (Boolean (y<x)))::xs 
  | ("subi", (BaseValue (Int x))::(BaseValue (Int y))::xs)   -> (BaseValue (Int (y-x)))::xs 
  | ("muli", (BaseValue (Int x))::(BaseValue (Int y))::xs)   -> (BaseValue (Int (x*y)))::xs 

  | ("divi", (BaseValue (Int y))::(BaseValue (Int x))::xs)   -> (BaseValue (Int (x / y)))::xs 
  | ("modi", (BaseValue (Int y))::(BaseValue (Int x))::xs)   -> (BaseValue (Int (x mod y)))::xs 
  | ("mulf", (BaseValue (Real x))::(BaseValue (Real y))::xs) -> (BaseValue (Real (x*.y)))::xs
  | ("real", (BaseValue (Int x))::xs)   -> (BaseValue (Real (float_of_int x)))::xs
  | ("eqi", (BaseValue (Int y))::(BaseValue (Int x))::xs)   -> (BaseValue (Boolean (x = y)))::xs 

  | ("length", (Array x)::xs)   -> (BaseValue (Int (List.length x)))::xs
  | ("get",    (BaseValue (Int i))::(Array x)::xs)   -> (List.nth x i)::xs


  | ("point", (BaseValue (Real z))::(BaseValue (Real y))::(BaseValue (Real x))::xs)   -> 
      (Point (x,y,z))::xs 

  | ("sphere", (Closure (e,c))::xs) -> (Object (Leaf (Sphere ((0.0, 0.0, 0.0),1.0), fun (x,y,z) -> 
      let [BaseValue (Real x2); BaseValue (Real y2); BaseValue (Real z2);Point color] = 
	eval2 (c, e, [BaseValue (Real x);BaseValue (Real y);BaseValue (Real z)]) in
      (color, (x2, y2, z2)))))::xs
  | ("plane", (Closure (e,c))::xs) -> (Object (Leaf (Plane ((0.0, -1.0, 0.0),3.0), fun (x,y,z) -> 
      let [BaseValue (Real x2); BaseValue (Real y2);BaseValue (Real z2);Point color] = 
	eval (c, [BaseValue (Real x);BaseValue (Real y);BaseValue (Real z)]) in
      (color, (x2, y2, z2)))))::xs

  | ("pointlight", (Point color)::(Point pos)::xs) -> (Light (Pointlight pos, color))::xs
  | ("light", (Point color)::(Point dir)::xs) -> (Light (DirectionLight dir, color))::xs

  | ("union", (Object x)::(Object y)::xs) -> 
      (Object (Union (x,y)))::xs

  | ("translate", (BaseValue (Real tz))::(BaseValue (Real ty))::(BaseValue (Real tx))::
     (Object x)::xs) -> 
       (Object (map_constructive_solid (fun (f,surf) -> (translate (tx, ty, tz) f, surf)) x))::xs

  | ("render", (BaseValue (String filename))::
     (BaseValue (Int ht))::(BaseValue (Int wid))::
     (BaseValue (Real fov))::
     (BaseValue (Int depth))::
     (Object obj)::
     (Array lights_values)::
     (Point ambient)::xs) -> 
       (render 
	  (flatten_constructive_solid obj)
	  (List.map (fun (Light x) -> x) lights_values) 
	  ambient 
	  wid ht 
	  (deg_to_rad fov) depth filename;
	xs
       )
  | x -> raise (ApplyOp x)
  )
and (eval: code * values -> values) = function
    (c, vs) -> let state = transit_etoile ([], vs, c) in (* do 2 things !! *)
      try 
	let (t, res, []) = state in
	res
      with _ -> raise (Eval (state))
and (eval2: code * env * values -> values) = function
    (c, e, vs) -> let state = transit_etoile (e, vs, c) in (* do 2 things !! *)
      try 
	let (t, res, []) = state in
	res
      with _ -> raise (Eval (state))


(**************************************************************************)
(* test *)
(**************************************************************************)
let (print_result: values -> unit) =
  List.iter (function 
    | BaseValue (Int x) -> print_int x; print_newline()
    | BaseValue (Real x) -> print_float x; print_newline()
   )

let p1 = [NormalValue (Int 1); 
	   Function ([Binder "x";Identifier "x";Identifier "x"]);
	   Operator "apply";
	   Operator "addi"
	 ] 
let res = eval (p1, []) = [BaseValue (Int 2)]

(* lexical scope !! *)
let p2 = [NormalValue (Int 1); Binder "x"; 
	   Function ([Identifier "x"]); Binder "f";
	   NormalValue (Int 2); Binder "x";  
	   Identifier "f"; Operator "apply"; Identifier "x"; Operator "addi"
	 ] 
let res2 = eval (p2, []) = [BaseValue (Int 3)]
	   
(* if *)
let p3 = [NormalValue (Boolean true); 
	   Function ([NormalValue (Int 1)]);
	   Function ([NormalValue (Int 2)]);
	   Operator "if"
	 ] 
let res3 = eval (p3, []) = [BaseValue (Int 1)]

let p4 = [NormalValue (Boolean false); 
	   Function ([NormalValue (Int 1)]);
	   Function ([NormalValue (Int 2)]);
	   Operator "if"
	 ] 
let res4 = eval (p4, []) = [BaseValue (Int 2)]

(* TODO
 list ex p7
 exs p8
*)


(* to test independantly from raytracer *)
(* and  point   = (float * float * float) (* for point, vectors, colors *) *)
(*
and  obj     = (primitive_solid * code * point)
and  primitive_solid =
  | Sphere
  | Cube
  | Cylinder
  | Cone
  | Plane
and  light   = unit
*)
