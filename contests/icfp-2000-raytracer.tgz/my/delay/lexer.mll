{
open Lexing
open Parser
}
let identifier = ['a'-'z''A'-'Z'] ['a'-'z''A'-'Z' '0'-'9' '-' '_']*

let sign = '-'
let dec_number = ['0'-'9']+
let integer = sign? dec_number
let exp = ['e''E'] sign? dec_number
let real = (sign? dec_number '.' dec_number exp?) | (sign? dec_number exp)

rule token = parse
  | [' ' '\t' '\n' '\r' '\011'] { token lexbuf }     (* skip blanks *)
  | '%' [^'\r''\n']*      { token lexbuf }
  | '['         { LBRACKET }
  | ']'         { RBRACKET }
  | '{'         { LBRACE }
  | '}'         { RBRACE }
  | "true"      { TRUE }
  | "false"     { FALSE }
  | '"' [^'"']* '"' 
      { let s = lexeme lexbuf in
        STRING (String.sub s 1 (String.length s - 2)) (* suppr the enclosing guill *)
      }	
 | '/' identifier { let s = lexeme lexbuf in
                    BINDER (String.sub s 1 (String.length s - 1))
		 }
  | integer     { INT  (int_of_string   (lexeme lexbuf)) }
  | real        { REAL (float_of_string (lexeme lexbuf)) }
  | identifier     { let s = lexeme lexbuf in
                     (*TODO BAD coupling, but solve pb forbiddent to redefine a primitive *)
    if List.mem s ["if";"apply";
		    "addi";"addf";"lessi";"subi";"muli";
		    "divi";"mulf";"real";
		    "point";"sphere";"pointlight";"plane";"translate";"union";"render";
		    "get";"length";
		    "eqi";

		    "acos";"asin";"clampf";"cos";"sin";"divf";"eqf";"floor";"frac";"lessf";
		    "modi";"negi";"negf";"sqrt";"subf";
		    "getx";"gety";"getz";
		    "light"; "spotlight";
		    "scale";"uscale";"rotatex";"rotatey";"rotatez";
		    "intersect";"difference"
		  ] 
		     then OPERATOR s 
                     else IDENTIFIER s
                   }  					 
  | eof            { EOF }

(* | _              { raise (Error "illegal character") } *)

