open Geometry
open Common
open Ppm

type light_type = 
  | Pointlight of point
  | DirectionLight of point (* dir *)
type light = light_type * color

let (ljv_from_light: light_type -> point -> vector) = fun l p ->
  match l with
  | (Pointlight x) -> minus_point (x, p)
  | (DirectionLight v) -> oppose v

let (distance_from_light: light_type -> point -> float) = fun l p ->
  match l with
  | (Pointlight x) -> length (minus_point (x, p))
  | (DirectionLight v) -> 10000000000.0

let (render: (obj list) -> (light list) -> color -> int -> int -> float -> int -> string -> unit) =
  fun objs lights amb width height fov depth filename ->
    let width_world = 2.0 *. (tan (0.5 *. fov)) in
    let delta = width_world /. (float_of_int width) in
    let ratio = (float_of_int height) /. (float_of_int width) in
    let (x,y) = (-. (width_world /. 2.0), (width_world /. 2.0) *. ratio) in
    let eye   = (0.0, 0.0, -. 1.0) in
    let forms       = List.map fst objs in
    let ia          = amb in

    let launch_ray ray = 
      let distances    = List.map (intersection ray) forms in
      let dist_and_obj = zip distances objs in
      let intersected = List.filter (function (None,_)   -> false | _ -> true) dist_and_obj in
      let intersected = List.map    (function (Just x,o) -> (x,o)) intersected in
      intersected in

    let rec recursive ray depth = 
      if depth = 0 then (0.0,0.0,0.0)
      else 
	(
	 let intersected = launch_ray ray in
	 (if intersected = [] then (0.0,0.0,0.0)
	 else 
	   (
	(* let color = color_pixel ray form in *)
	    let mini = minimum (List.map fst intersected) in
	    let ((form, surf_func) as obj) = List.assoc mini intersected in
	    let point_intersect = point_from_ray ray mini in 
	    let (color, (kd, phong, ks)) = surf_func point_intersect in  
(*	    let (color, (kd, phong, ks)) = ((0.3, 0.3, 0.3), (1.0, 1.0, 1.0)) in  *)
	    
	    let ambient          = mult_coeff ia kd  in
	    
	    let n_vector         = normalise (normal point_intersect form ray) in 
	    let lights_contrib1  = 
	     (mult_coeff 
		(sum_vector
		   (List.map (fun (light) -> 
		     let lj_v      = ljv_from_light (fst light) point_intersect in
		     let lj_vector = normalise lj_v in
		     let ij = snd light in
		     let shadow_ray = (point_intersect, lj_vector) in
		     let shadow_ray2= (point_from_ray shadow_ray 0.001, lj_vector) in (* acne pb *)
		     let intersected = launch_ray shadow_ray2 in
		     if (intersected != []) && (minimum (List.map fst intersected) < 
						(distance_from_light (fst light) point_intersect))
		     then (0.0, 0.0, 0.0)
		     else 
		       let dotp = dotproduct (n_vector, lj_vector) in
		       mult_coeff ij dotp
			     ) lights))
		kd) in
	    mult_vector color 
	      (sum_vector [ambient  
			      ;lights_contrib1 
(*			      ;lights_contrib2 
			      ;obj_contribution *)
			  ])
	     )
	   )
	) in
    let rec aux i j res = (* i = line, j = column, make it tail recursive for efficiency *)
      if i = height then res
      else 
	(let ray = (eye, normalise 
		      (x +. (((float_of_int j) +. 0.5) *. delta),
		       y -. (((float_of_int i) +. 0.5) *. delta),
		       1.0)) in

	let illumunation = recursive ray depth in
	let newj = (if (j+1) = width then 0 else j+1) in
	let newi = (if newj = 0 then i+1 else i) in
	aux newi newj (illumunation::res)
	)
    in
    let pixels = aux 0 0 [] in
    
    let conversion i = (int_of_float ((clampf i) *. 255.0)) in
    let newpix = (map_eff_rev (fun (r,g,b) -> (conversion r, conversion g, conversion b)) pixels) in
    write_ppm width height newpix filename
    

(*
need a conversion fonction from intensity to rgb
*)

let white = (1.0, 1.0, 1.0)
let black = (0.0, 0.0, 0.0)
let red   = (1.0, 0.0, 0.0)
let green = (0.0, 1.0, 0.0)
let green2 = (0.3, 1.0, 0.3)
let blue  = (0.0, 0.0, 1.0)
let grey  = (0.2,0.2,0.2)
let sf color   = fun p -> (color, (1.0, 1.0, 1.0))
let mate color = fun p -> (mult_coeff color 0.5, (1.0, 1.0, 1.0))

let test1 () = render [
  (* (Plane ((0.0, -1.0, 0.0), 1.0), mate blue)
	       ;(Plane ((-1.0, 0.0, 0.0), 1.0), mate green)

	       ; *) (Sphere ((1.0, 1.0, 2.0), 1.0), mate red)

	       ] 
    [(* (Pointlight (1.0, 1.0, -1.0)), white *)
      ((DirectionLight (1.0, 1.0, -1.0)), white)
	(* ;(Pointlight (1.0, 1.0, 0.0)), green *)
    ]
    white 
    200 200 (pi2) 1 "img.ppm"

let test2 () = render [(Plane ((0.0, -1.0, 0.0), 1.0), mate blue)
	       ;(Sphere ((0.0, 0.0, 2.0), 1.0), mate red)

	       ] 
    [(Pointlight (0.0, 5.0, 1.0)), white
	(* ;(Pointlight (1.0, 1.0, 0.0)), green *)
    ]
    white 
    200 200 (pi2) 1 "img.ppm"
(*
let _ = render [(Plane ((0.0, -1.0, 0.0), 1.0), blue)
		    ; (Sphere ((-0.5, -0.0, 0.0), 0.6), red) 
		    ; (Sphere ((0.5, -0.0, 0.0), 0.6), green) 
	       ] 
    [((Pointlight (0.0, 1.0, 10.0)), white)
	; ((Pointlight (-1.0, 1.0, -13.0)), green)
    ] 
    0 100 100 (pi2)

let _ = render [ (Plane ((0.0, -1.0, 0.0), 1.0), (2,30,1));
		 (Plane ((-1.0, 0.0, 0.0), 10.0), (2,30,100))] [] 0 100 100 (pi2)
let _ = render [(Sphere ((0.0, 0.0, 0.0), 0.1), red)] [] 0 100 100 (pi2)
let _ = render [ (Plane ((0.0, -1.0, 0.0), 1.0), (0.1,0.3,0.1));
		 (* (Plane ((-1.0, 0.0, 0.0), 10.0), (2,30,100)); *)
		 (Sphere ((0.0, -0.6, 0.0), 0.3), (0.1,0.6,0.1));
		 (Sphere ((0.0, -0.6, 1.0), 0.3), (0.3,0.1,0.1))

	       ] [] 0 100 100 (pi2)

let inter = intersection  
    (((0.0, 0.0, -. 1.0), (-1.0, 1.0, 1.0)),
     (Plane ((0.0, -1.0, 0.0), 1.0))
    )

let inter = intersection  ((0.0, 0.0, -1.0), (-1.0, 1.0, 1.0))
    (Sphere ((0.0, 0.0, 0.0), 0.1))
*)    
(*

	    let lights_contrib2 = 
	      (mult_coeff 
		 (sum_vector
		    (List.map (fun (light) -> 
		      let lj_vector = normalise (minus_point (point_from_light (fst light), 
							      point_intersect)) in
		      let hj_vector = n_vector in
		      let ij = snd light in (* TODO shadow ray *)
		      mult_coeff ij ((dotproduct (n_vector, hj_vector))** phong)
			      ) lights))
		 ks) in
	    let obj_contribution = 
	      (let s_vector = opposite n_vector (snd ray) in
	      mult_coeff (recursive (point_intersect,s_vector) (depth - 1)) ks
	      ) in  
*)
