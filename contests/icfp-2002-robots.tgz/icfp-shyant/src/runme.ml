
match Sys.argv with
| [| _ ; localhost ; port |] ->
    Talk_to_server.wrapper (Client_impl.make_ralone false) localhost port
| _ ->
    print_endline "bad usage\n"

