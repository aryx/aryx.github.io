open Common
open Lib

let direction_of_string = function
  | "N" -> N
  | "S" -> S
  | "E" -> E
  | "W" -> W
  | _ -> failwith "direction_of_string"

let parse_actions s =
  let rec parse_reply_ robot_id = function
    | [] -> []
    | e::l -> 
	try
	if e.[0] = '#' then
	  let ss = (String.sub e 1 (String.length e - 1)) in
	  parse_reply_ (int_of_string ss) l
	else
	  match e, l with
	  | "X", x :: "Y" :: y :: l ->
	      (robot_id, A_Appear (int_of_string x, int_of_string y)) :: parse_reply_ robot_id l
	  | "N", _
	  | "S", _
	  | "E", _
	  | "W", _ -> 
	      (robot_id, A_Move (direction_of_string e)) :: parse_reply_ robot_id l
	  | "P", package :: l ->
	      (robot_id, A_Pick (int_of_string package)) :: parse_reply_ robot_id l
	  | "D", package :: l ->
	      (robot_id, A_Drop (int_of_string package)) :: parse_reply_ robot_id l
	  | _ -> failwith ("parse error on " ^ e ^ ": " ^ s)
	with _ -> failwith ("failed on " ^ e ^ ": " ^ s)
  in
(*  print_endline ("actions> " ^ s) ;*)
  parse_reply_ 0 (split_on_char ' ' s)

let parse_packages_available s =
  let rec parse_packages_available_ = function
    | [] -> []
    | id :: dest_x :: dest_y :: weight :: l ->
	(id, { weight = weight ; destination = (dest_x, dest_y); package_id = id }) :: parse_packages_available_ l
    | _ -> failwith "parse_packages_available_"
  in
(*  print_endline ("packages available> " ^ s) ;*)
  if s = "" then [] else 
  parse_packages_available_ (List.map int_of_string (split_on_char ' ' s))


let string_of_command = function
  | Move direction -> "Move " ^ string_of_direction direction
  | Pick l -> "Pick " ^ String.concat " " (List.map string_of_int l)
  | Drop l -> "Drop " ^ String.concat " " (List.map string_of_int l)


let connect_to_server hostname port =
  let host = (Unix.gethostbyname hostname).Unix.h_addr_list.(0) in
  let sockaddr = Unix.ADDR_INET(host, port) in
  let (in_, out) = Unix.open_connection sockaddr in
(*  print_endline "Connected\n"; flush stdout ;*)
  output_string out "Player\n" ; flush out ;

  let space = get_map in_ in

  let l = List.map int_of_string (split_on_char ' ' (input_line in_)) in
  match l with
  | [ id ; maximum_capacity ; money ] ->
      in_, out, space, id, maximum_capacity, money
  | _ -> failwith "bad robot"


let talk_to_server in_ out do_command =
  let actions = parse_actions (input_line in_) in
  let packages_available = parse_packages_available (input_line in_) in
  let cmd = do_command actions packages_available in

  Printf.printf "%d %s\n" cmd.bid (string_of_command cmd.command) ; flush stdout ;
  Printf.fprintf out "%d %s\n" cmd.bid (string_of_command cmd.command) ; flush out
  

let wrapper bot hostname port =
  let in_, out, space, id, maximum_capacity, money = connect_to_server hostname (int_of_string port) in

  bot.init (space, { uniq_id = id ; initial_money = money ; max_capacity = maximum_capacity }) ;

  let do_command actions packages_available =
    bot.end_turn actions ;
    bot.engine packages_available
  in

  while true do
    if has_env "STEP" then ignore (input_line stdin) ;
    talk_to_server in_ out do_command
  done

