(*pp camlp4o *)
open List
open Printf

(******************************************************************************************)
(* we use *)
(******************************************************************************************)
(* List.rev, List.mem, List.partition, List.fold*, ... max min
*)

let rec split_on_char c s =
  try
    let sp = String.index s c in
    String.sub s 0 sp :: split_on_char c (String.sub s (sp+1) (String.length s - sp - 1))
  with Not_found -> [s]

let get_mem() =
  let _ = Sys.command("grep VmData /proc/" ^ string_of_int (Unix.getpid()) ^ "/status") in
  ()

let iter_index f l =
  let rec iter_ n = function
    | [] -> ()
    | e::l -> f e n ; iter_ (n+1) l
  in iter_ 0 l


let map_index f l =
  let rec map_ n = function
    | [] -> []
    | e::l -> f e n :: map_ (n+1) l
  in map_ 0 l


let do_withenv doit f env l =
  let r_env = ref env in
  let l' = doit (fun e -> 
    let e', env' = f !r_env e in
    r_env := env' ; e'
  ) l in
  l', !r_env
  
let map_withenv      f env e = do_withenv map f env e


let rec collect_accu f accu = function
  | [] -> accu
  | e::l -> collect_accu f (rev_append (f e) accu) l

let collect f l = rev (collect_accu f [] l)

let rec fpartition p l =
  let rec part yes no = function
  | [] -> (rev yes, rev no)
  | x :: l -> 
      (match p x with
      |	None -> part yes (x :: no) l
      |	Some v -> part (v :: yes) no l) in
  part [] [] l

(*******************************************************************************)
(* tuples *)
(*******************************************************************************)
let fst3 (x,_,_) = x
let snd3 (_,y,_) = y
let thd3 (_,_,z) = z


(*******************************************************************************)
(* numeric/overloading *)
(*******************************************************************************)

(* TODO *)

type 'a numdict = 
    NumDict of (('a-> 'a -> 'a) * 
		('a-> 'a -> 'a) * 
		('a-> 'a -> 'a) * 
		('a -> 'a));;

let add (NumDict(a, m, d, n)) = a;;
let mul (NumDict(a, m, d, n)) = m;;
let div (NumDict(a, m, d, n)) = d;;
let neg (NumDict(a, m, d, n)) = n;;

let numd_int   = NumDict(( + ),( * ),( / ),( ~- ));;
let numd_float = NumDict(( +. ),( *. ), ( /. ),( ~-. ));;
let testd dict n = 
  let ( * ) x y = mul dict x y in 
  let ( / ) x y = div dict x y in 
  let ( + ) x y = add dict x y in 
  (* Now you can define all sorts of things in terms of *, /, + *) 
  let f num = (num * num) / (num + num) in 
  f n;;

(*******************************************************************************)
(* composition *)
(*******************************************************************************)
let ($)     f g x = g (f x)

(* dont work :( let ( � ) f g x = f(g(x)) *)

let compose f g x = f (g x)

(* i like the list@func notation, object reminescence *)
(*let ((@): 'a -> ('a -> 'b) -> 'b) = fun a b -> b a*)
let (+>) o f = f o (* same *)
(* let o f g x = f (g x) *)


let flip f = fun x y -> f y x
let rec applyn n f o = if n = 0 then o else applyn (n-1) f (f o)

let curry f x y = f (x,y)
let uncurry f (a,b) = f a b

(*******************************************************************************)
(* misc *)
(*******************************************************************************)

(* pix *)
let has_env var = 
  try 
    let _ = Sys.getenv var in true
  with Not_found -> false

(* want or of merd, but cant cos cant put die ... in b (strict call) *)
let (|||) a b = try a with _ -> b

(* pix *)
let uncons l = hd l, tl l

(* pix *)
let safe_tl l = try tl l with _ -> []


(* on lisp: graham   
complement 
!
fif?

*)

let fmap f = function
  | None -> None
  | Some x -> Some (f x)

let id x = x
let double a = a,a
let swap (x,y) = (y,x)


(* Y, memo *)

(******************************************************************************************)
(* types *)
(******************************************************************************************)
(* type 'a      maybe  = Just of 'a | None *)
type ('a,'b) either = Left of 'a | Right of 'b

let just = function
  | (Some x) -> x
  | _ -> failwith "just: pb"
let some = just


let optionise f a= 
  try Some (f a) with _ -> None

let optionise2 f a b = optionise (fun (a,b) -> f a b) (a,b)

type ('a, 'b, 'c) either3 = Left3 of 'a | Middle3 of 'b | Right3 of 'c

(* pix *)
let some_or = function
  | None -> id
  | Some e -> fun _ -> e


let partition_either f l =
  let rec part_either left right = function
  | [] -> (rev left, rev right)
  | x :: l -> 
      (match f x with
      |	Left  e -> part_either (e :: left) right l
      |	Right e -> part_either left (e :: right) l) in
  part_either [] [] l


type uint = int

(******************************************************************************************)
(* simple test *)
(******************************************************************************************)
let _list_bool = ref []

(* introduce a fun () ??, otherwise the calculus is made at compile time and this can be long *)
(* let (example: string -> (unit -> bool) -> unit) = fun s func -> 
  _list_bool := (s,func):: (!_list_bool)
  would like to do as a func that take 2 terms, and make an = over it
  avoid to add this ugly fun (), but pb of type, cant do that :(
*)
let (example: string -> bool -> unit) = fun s b -> 
  _list_bool := (s,b)::(!_list_bool)

let (test_all: unit -> unit) = fun () -> 
  List.iter (fun (s, b) -> Printf.printf "%s: %s\n" s (if b then "passed" else "failed")
	    ) !_list_bool

let (test: string -> unit) = fun s -> 
  Printf.printf "%s: %s\n" s (if (List.assoc s (!_list_bool)) then "passed" else "failed")
(* ex: let _ = example "++" ([1;2]++[3;4;5] = [1;2;3;4;5]) *)



(*******************************************************************************)
(* list *)
(*******************************************************************************)

let rec removelast = function
  | [] -> failwith "removelast"
  | [_] -> []
  | e::l -> e :: removelast l

(*
 pix
let rec take_until p = function
  | [] -> []
  | x::xs -> if p x then [] else x::(take_until p xs)

let rec drop_while p = function
  | [] -> []
  | x::xs -> if p x then drop_while p xs else x::xs	

let rec skipfirst e = function
  | [] -> []
  | e'::l when e = e' -> skipfirst e l
  | l -> l

let rec removelast = function
  | [] -> failwith "removelast"
  | [_] -> []
  | e::l -> e :: removelast l

let rec inits = function
  | [] -> [[]]
  | e::l -> [] :: map (fun l -> e::l) (inits l)
let rec tails = function
  | [] -> [[]]
  | (_::xs) as xxs -> xxs :: tails xs


let take_while p = take_until (p $ not)
let span p xs = (take_while p xs, drop_while p xs)
*)

let rec (span: ('a -> bool) -> 'a list -> 'a list * 'a list) = fun p -> function
  | []    -> ([], [])
  | x::xs -> 
      if p x then 
	let (l1, l2) = span p xs in
	(x::l1, l2)
      else ([], x::xs)
let () = example "span1" 
    (span (fun x -> x <= 3) [1;2;3;4;1;2] = ([1;2;3],[4;1;2]))

(* generate exception (Failure "tl") if there is no element satisfying p *)
let rec (skip_until: ('a list -> bool) -> 'a list -> 'a list) = fun p xs ->
  if p xs then xs else skip_until p (List.tl xs)
let () = example "skip_until1" 
    (skip_until (function 1::2::xs -> true | _ -> false) [1;3;4;1;2;4;5] = [1;2;4;5])

(* conversion *)

let (string_of_list: char list -> string) = 
  List.fold_left (fun acc x -> acc^(Char.escaped x)) ""

let rec splitAt n xs = 
  if n = 0 then ([],xs)
  else 
    (match xs with
    | []      -> ([],[])
    | (x::xs) -> let (a,b) = splitAt (n-1) xs in (x::a, b)
    )

let sum xs = List.fold_left (+) 0 xs
let product = List.fold_left ( * ) 1

let rec take n xs = 
  match (n,xs) with
  | (0,_) -> []
  | (_,[]) -> failwith "not enough"
  | (n,x::xs) -> x::take (n-1) xs

let rec take_2 n xs =
  match (n,xs) with
  | (0,_) -> []
  | (_,[]) -> []
  | (n,x::xs) -> x::take_2 (n-1) xs


let rec drop n xs = 
  match (n,xs) with
  | (0,_) -> xs
  | (_,[]) -> failwith "not enough"
  | (n,x::xs) -> x::drop (n-1) xs


let rec (return_when: ('a -> 'b option) -> 'a list -> 'b) = fun p -> function
  | [] -> raise Not_found
  | x::xs -> (match p x with None -> return_when p xs | Some b -> b)
  

let rec zip xs ys = 
  match (xs,ys) with
  | ([],_) -> []
  | (_,[]) -> []
  | (x::xs,y::ys) -> (x,y)::zip xs ys

(* could call it for *)
let fold_left_with_index f acc =
  let rec aux acc n = function
    | [] -> acc
    | x::xs -> aux (f acc x n) (n+1) xs 
  in aux acc 0

(* let (++) = (@), could do that, but if load many times the common, then pb *)
let (++) l1 l2 = List.fold_right (fun x acc -> x::acc) l1 l2

let rotate list = List.tl list ++ [(List.hd list)]

let or_list  = List.fold_left (||) false
let and_list = List.fold_left (&&) true

let reverse = List.rev

let rec (generate: int -> 'a -> 'a list) = fun i el ->
  if i = 0 then []
  else el::(generate (i-1) el)

let foldl1 p = function x::xs -> List.fold_left p x xs | _ -> failwith "foldl1"

let rec uniq = function
  | [] -> []
  | e::l -> if mem e l then uniq l else e :: uniq l

let rec all_assoc e = function
  | [] -> []
  | (e',v) :: l when e=e' -> v :: all_assoc e l
  | _ :: l -> all_assoc e l

let prepare_want_all_assoc l =
  map (fun n -> n, uniq (all_assoc n l)) (uniq (map fst l))

(* pix *)
let rec fold_right1 f = function
  | [] -> failwith "fold_right1"
  | [e] -> e
  | e::l -> f e (fold_right1 f l)


let maximum l = foldl1 max l
let minimum l = foldl1 min l

let rec zip l1 l2 = 
  match (l1,l2) with
  | ([],_) -> []
  | (_,[]) -> []
  | (x::xs, y::ys) -> (x,y)::(zip xs ys)


(* do a map tail recursive, and result is reversed, it is a tail recursive map => efficient *)
let map_eff_rev = fun f l ->
  let rec aux acc = 
    function 
      |	[]    -> acc
      |	x::xs -> aux ((f x)::acc) xs
  in
  aux [] l

let pack n xs = 
  let rec aux l i = function
    | [] -> failwith "not on a boundary"
    | [x] -> if i = n then [l++[x]] else failwith "not on a boundary"
    | x::xs -> if i = n then (l++[x])::(aux [] 1 xs) else aux (l++[x]) (i+1) xs in
  aux [] 1 xs


let rec enum x n = if x = n then [n] else x::enum (x+1)  n
let () = example "enum" 
    (enum 1 4 = [1;2;3;4])

(* kind of cartesian product of x*x  *)
let rec (get_pair: ('a list) -> (('a * 'a) list)) = function
  | [] -> []
  | x::xs -> (List.map (fun y -> (x,y)) xs) ++ (get_pair xs)


let remove x = List.filter (fun y -> y != x)
let empty list = list = []

let rec list_init = function
  | []       -> raise Not_found
  | [x]      -> []
  | x::y::xs -> x::(list_init (y::xs))

let rec list_last = function
  | [] -> raise Not_found
  | [x] -> x
  | x::y::xs -> list_last (y::xs)

(* pix *)
let last_n n l = rev (take n (rev l))
let last l = hd (last_n 1 l)


(* retourne le rang dans une liste d'un element                               *)
let rang elem liste =
  let rec rang_rec elem accu = function
    | []   -> raise Not_found
    | a::l -> if a = elem then accu
    else rang_rec elem (accu+1) l in

  rang_rec elem 1 liste


(* retourne vrai si une liste contient des doubles                            *)
let rec doublon = function
  | []   -> false
  | a::l -> if List.mem a l then true
  else doublon l


let rec (inseredans: 'a -> 'a list -> 'a list list) = fun x -> function
  | []    -> [[x]]
  | y::ys -> (x::y::ys)  :: (List.map (fun xs -> y::xs) (inseredans x ys))
(* [1;2;3] -> 3   [2;3] [3;2] *)

let rec (permutation: 'a list -> 'a list list) = function
  | [] -> []
  | [x] -> [[x]]
  | x::xs -> List.flatten (List.map (inseredans x) (permutation xs))


(* pix *)
let rec map_flatten f l =
  let rec aux accu = function    
    | [] -> accu
    | e :: l -> aux (List.rev (f e) ++ accu) l
  in List.rev (aux [] l)



let rec repeat e n = 
    let rec aux acc = function
      | 0 -> acc
      | n when n < 0 -> failwith "repeat"
      | n -> aux (e::acc) (n-1) in
    aux [] n

let rec map2 f = function 
  | [] -> []
  | x::xs -> let r = f x in r::map2 f xs

let rec map3 f l = 
  let rec aux acc = function
    | [] -> acc 
    | x::xs -> aux (f x::acc) xs in
  aux [] l

(*
let tails2 xs = map rev (inits (rev xs))
let res = tails2 [1;2;3;4]
let res = tails [1;2;3;4]
let id x = x 
*)

let pack_sorted same xs = 
    let rec aux acc xs = 
      match (acc,xs) with
      |	((cur,rest),[]) -> cur::rest
      |	((cur,rest), y::ys) -> 
	  if same (List.hd cur) y then aux (y::cur, rest) ys
	  else aux ([y], cur::rest) ys
    in aux ([List.hd xs],[]) (List.tl xs) +> List.rev
let test = pack_sorted (=) [1;1;1;2;2;3;4]


(******************************************************************************)
(* set as normal list *)
(******************************************************************************)

let (union: 'a list -> 'a list -> 'a list) = fun l1 l2 -> 
  List.fold_left (fun acc x -> if List.mem x l1 then acc else x::acc) l1 l2

let insert_normal x xs = union xs [x]


(* retourne lis1 - lis2 *)
let minus l1 l2 = List.filter    (fun x -> not (List.mem x l2)) l1

let inter l1 l2 = List.fold_left (fun acc x -> if List.mem x l2 then x::acc else acc) [] l1


let uniq lis = 
  List.fold_left (function acc -> function el -> union [el] acc) [] lis


(* pix *)
let rec non_uniq = function
  | [] -> []
  | e::l -> if mem e l then e :: non_uniq l else non_uniq l


let rec inclu lis1 lis2 =
  List.for_all (function el -> List.mem el lis2) lis1

let equivalent lis1 lis2 = 
  (inclu lis1 lis2) && (inclu lis2 lis1)


(******************************************************************************)
(* set as sorted list *)
(******************************************************************************)
(* liste trie, cos we need to do intersection, and insertien (it is a set
   cos when introduce has, if we create a new has => must do a recurse_rep
   and another categ can have to this has => must do an union
 *)
let rec insert x = function
  | [] -> [x]
  | y::ys -> 
      if x = y then y::ys
      else (if x < y then x::y::ys else y::(insert x ys))

(* same, suppose sorted list *)
let rec intersect x y =
  match(x,y) with
  | [], y -> []
  | x,  [] -> []
  | x::xs, y::ys -> 
      if x = y then x::(intersect xs ys)
      else 
	(if x < y then intersect xs (y::ys)
	else intersect (x::xs) ys
	)
(* intersect [1;3;7] [2;3;4;7;8];;   *)

(******************************************************************************)
(* sur surEnsemble [p1;p2] [[p1;p2;p3] [p1;p2] ....] -> [[p1;p2;p3] ...       *)
(* mais pas p2;p3                                                             *)
(* (aop) *)
(******************************************************************************)
let surEnsemble  liste_el liste_liste_el = 
  List.filter
    (function liste_elbis ->
      List.for_all (function el -> List.mem el liste_elbis) liste_el
    ) liste_liste_el;;

(*******************************************************************************)
(* le point fixe (aop) *)
(******************************************************************************)
let rec ptFix trans elem =
  let image = trans elem in
  if (image = elem) 
  then elem (* point fixe *)
  else ptFix trans image

(* le point fixe  pour les objets *)
let rec ptFixForObjetct trans elem =
  let image = trans elem in
  if (image#equal elem) then elem (* point fixe *)
  else ptFixForObjetct trans image

(*******************************************************************************)
(* combinaison/product/.... (aop) *)
(*******************************************************************************)
(* 123 -> 123 12 13 23 1 2 3 *)
let rec realCombinaison = function
  | []  -> []
  | [a] -> [[a]]
  | a::l as res3 -> 
      let res  = realCombinaison l in
      let res2 = List.map (function x -> a::x) res in
      res2 ++ res ++ [[a]]

(* genere toutes les combinaisons possible de paire      *)
(* par exemple combinaison [1;2;4] -> [1, 2; 1, 4; 2, 4] *)
let rec combinaison = function
  | [] -> []
  | [a] -> []
  | [a;b] -> [(a, b)]
  | a::b::l -> (List.map (function elem -> (a, elem)) (b::l)) ++
     (combinaison (b::l))

(******************************************************************************)
(* list of list(aop) *)
(******************************************************************************)
(* insere elem dans la liste de liste (si elem est deja present dans une de   *)
(* ces listes, on ne fait rien                                                *)
let rec insere elem = function
  | []   -> [[elem]]
  | a::l -> 
      if (List.mem elem a) then a::l
      else a::(insere elem l)

let rec insereListeContenant lis el = function
  | []   -> [el::lis]
  | a::l -> 
      if List.mem el a then 
	(List.append lis a)::l
      else a::(insereListeContenant lis el l)

(* fusionne les listes contenant et1 et et2  dans la liste de liste*)
let rec fusionneListeContenant (et1, et2) = function
  | []   -> [[et1; et2]]
  | a::l -> 
      (* si les deux sont deja dedans alors rien faire *)
      if List.mem et1 a then
	if List.mem et2 a then a::l
	else 
	  insereListeContenant a et2 l
      else if List.mem et2 a then
	insereListeContenant a et1 l
      else a::(fusionneListeContenant (et1, et2) l)

(******************************************************************************)
(* fonctions pour les parsers (aop)                                                 *)
(******************************************************************************)

let parserCommon lexbuf parserer lexer =
  try 
    let result = parserer lexer lexbuf in
    result
  with Parsing.Parse_error ->
    print_string "buf: "; print_string lexbuf.Lexing.lex_buffer;
    print_string "\n";
    print_string "current: "; print_int lexbuf.Lexing.lex_curr_pos;
    print_string "\n";
    raise Parsing.Parse_error


(* marche pas ca neuneu *)
(*
let getDoubleParser parserer lexer string = 
  let lexbuf1 = Lexing.from_string string in
  let chan = open_in string in
  let lexbuf2 = Lexing.from_channel chan in
  (parserCommon lexbuf1 parserer lexer  , parserCommon lexbuf2 parserer lexer )
*)

let getDoubleParser parserer lexer = 
  (
   (function string ->
     let lexbuf1 = Lexing.from_string string in
     parserCommon lexbuf1 parserer lexer
   ),
   (function string ->
     let chan = open_in string in
     let lexbuf2 = Lexing.from_channel chan in
     parserCommon lexbuf2 parserer lexer
   ))


(*******************************************************************************)
(* char *)
(*******************************************************************************)
let is_single  = String.contains ",;()[]{}_`"
let is_symbol  = String.contains "!@#$%&*+./<=>?\\^|:-~"
let is_space   = String.contains "\n\t "
let cbetween min max c = (int_of_char c) <= (int_of_char max) && (int_of_char c) >= (int_of_char min)
let is_upper = cbetween 'A' 'Z'
let is_lower = cbetween 'a' 'z'
let is_alpha c = is_upper c || is_lower c
let is_digit = cbetween '0' '9'

(******************************************************************************************)
(* Num *)
(******************************************************************************************)
let rec (do_n: int -> (unit -> unit) -> unit) = fun i f ->
  if i = 0 then () else (f(); do_n (i-1) f)

let rec (foldn: ('a -> int -> 'a) -> 'a -> int -> 'a) = fun f acc i ->
  if i = 0 then acc else foldn f (f acc i) (i-1)

let sum_float = List.fold_left (+.) 0.0
let sum_int   = List.fold_left (+) 0

let pi  = 3.14159265358979323846
let pi2 = pi /. 2.0
let pi4 = pi /. 4.0

(* 180 = pi *)
let (deg_to_rad: float -> float) = fun deg ->
  (deg *. pi) /. 180.0

let clampf = function
  | n when n < 0.0 -> 0.0
  | n when n > 1.0 -> 1.0
  | n -> n

let square x = x *. x

let rec power x n = if n = 0 then 1 else x * power x (n-1)

let between i min max = i > min && i < max

let bitrange x p = let v = power 2 p in between x (-v) v

(* descendant *)
let (prime1: int -> int option)  = fun x -> 
  let rec aux n = 
    if n = 1 then None
    else 
      if (x / n) * n = x then Some n else aux (n-1)
  in if x = 1 then None else if x < 0 then failwith "negative" else aux (x-1)

(* montant, better *)
let (prime: int -> int option)  = fun x -> 
  let rec aux n = 
    if n = x then None
    else 
      if (x / n) * n = x then Some n else aux (n+1)
  in if x = 1 then None else if x < 0 then failwith "negative" else aux 2


let decompose x = 
  let rec decompose x = 
  if x = 1 then []
  else 
    (match prime x with
    | None -> [x]
    | Some n -> n::decompose (x / n)
    ) 
  in assert (product (decompose x) = x); decompose x


(******************************************************************************************)
(* binary tree *)
(******************************************************************************************)
type 'a bintree = Leaf of 'a | Branch of ('a bintree * 'a bintree)


(*******************************************************************************)
(* assoc *)
(*******************************************************************************)
type ('a,'b) assoc  = ('a * 'b) list

let lookup = assoc


let rec (lookup_list: 'a -> ('a , 'b) assoc list -> 'b) = fun el -> function
  | [] -> raise Not_found
  | (xs::xxs) -> try List.assoc el xs with Not_found -> lookup_list el xxs


let (lookup_list2: 'a -> ('a , 'b) assoc list -> ('b * int)) = fun el xxs -> 
  let rec aux i = function
  | [] -> raise Not_found
  | (xs::xxs) -> try let res = List.assoc el xs in (res,i) with Not_found -> aux (i+1) xxs
  in aux 0 xxs

let () = example "lookup_list" 
    (lookup_list2 "c" [["a",1;"b",2];["a",1;"b",3];["a",1;"c",7]] = (7,2))


let (assoc_reverse: (('a * 'b) list) -> (('b * 'a) list)) = fun l -> List.map (fun(x,y) -> (y,x)) l
let (assoc_map: (('a * 'b) list) -> (('a * 'b) list) -> (('a * 'a) list)) = fun l1 l2 ->
  let (l1bis, l2bis) = (assoc_reverse l1, assoc_reverse l2) in
  List.map (fun (x,y) -> (y, List.assoc x l2bis )) l1bis
	
(*******************************************************************************)
(* debug *)
(*******************************************************************************)
let _debug = ref true
let debugon  () = _debug := true
let debugoff () = _debug := false
let debug f = if !_debug then f () else ()

let warning s v = (print_string s; v)
let myassert cond = if cond then () else failwith "assert error"


let internal_error s = failwith ("internal error: "^s)

let toDO () = failwith "TODO"
(******************************************************************************************)
(* Bool *)
(******************************************************************************************)
let (==>) b1 b2 = if b1 then b2 else true (* could use too => *)

let (<=>) a b = if a = b then 0 else if a < b then -1 else 1

let xor a b = not (a = b)


(******************************************************************************)
(* string *)
(******************************************************************************)

(* join = String.concat ? *)
let rec join str = function
  | [] -> ""
  | [x] -> x
  | x::xs -> x ^ str ^ (join str xs)
(* join "/" ["toto"; "titi"; "tata"] *)

let concat s1 s2 = 
  String.concat "" [s1;s2]

let concat2 = fun x y -> x ^ y (* je savais pas que y'avait un operateur ^    *)

let (<!!>) s (i,j) = String.sub s i (if j < 0 then String.length s - i + j + 1 else j - i)
let () = example "!!" ("tototati"<!!>(3,-2) = "otat" )

let (<!>) s i = String.get s i

(******************************************************************************)
(* IO *)
(******************************************************************************)

let print_string_ln str =
  print_string str;
  print_string "\n";;

(*******************************************************************************)

let (+=) ref v = ref := !ref + v

(* let gsubst = global_replace *)



(*******************************************************************************)

(* TODO, do with coarbitrary ?? idea is that given a 'a, generate a 'b
   depending of 'a and gen 'b, that is modify gen 'b, what is important is
   that each time given the same 'a, we must get the same 'b !!!
let (fg: ('a gen) -> ('b gen) -> ('a -> 'b) gen) = fun gen1 gen2 () ->
let b = laws "funs" (fun (f,g,h) -> x <= y ==> (max x y  = y)                       )(pg ig ig)
 *)

let filter_index f l =
  let rec filt i = function
    | [] -> []
    | e::l -> if f i e then e :: filt (i+1) l else filt (i+1) l
  in
  filt 0 l

let rec filter_some = function
  | [] -> []
  | None :: l -> filter_some l
  | Some e :: l -> e :: filter_some l

let one_of xs = List.nth xs (Random.int (List.length xs)) 
let take_one xs =
  if empty xs then failwith "Take_one: empty list"
  else 
    let i = Random.int (List.length xs) in
    List.nth xs i, filter_index (fun j _ -> i <> j) xs
      



(* 
let b = oneof [always true; always false] ()
let b = frequency [3, always true; 2, always false] ()

cant do this:
 let rec (lg: ('a gen) -> ('a list) gen) = fun gen -> oneofl [[]; lg gen ()] 
 nor
 let rec (lg: ('a gen) -> ('a list) gen) = fun gen -> oneof [always []; lg gen] 
 cos caml is not as lazy as haskell :(
 fix the pb by introducing a size limit
 take the bounds/size as parameter
 morover this is needed for more complex type, how make a bintreeg ??
  we need recursion 
*)

(*
let b = laws "unit" (fun x       -> reverse [x]          = [x]                   )ig
let b = laws "app " (fun (xs,ys) -> reverse (xs++ys)     = reverse ys++reverse xs)(pg (lg ig)(lg ig))
let b = laws "rev " (fun xs      -> reverse (reverse xs) = xs                    )(lg ig)
let b = laws "appb" (fun (xs,ys) -> reverse (xs++ys)     = reverse xs++reverse ys)(pg (lg ig)(lg ig))
let b = laws "max"  (fun (x,y)   -> x <= y ==> (max x y  = y)                       )(pg ig ig)
*)

(* with monitoring, TODO as in haskell, laws = laws2, no need for 2 func, but hard i found *)
(* TODO classify, collect,forall *)

(* let b = laws2 "max"  (fun (x,y)   -> ((x <= y ==> (max x y  = y)), x <= y))(pg ig ig) *)




(******************************************************************************)

(******************************************************************************)

(*
let random_insert i l = 
    let p = Random.int (length l +1)
    in let rec insert i p l = 
      if (p = 0) then i::l else (hd l)::insert i (p-1) (tl l)
    in insert i p l

let rec randomize_list = function 
  []  -> []
  | a::l -> random_insert a (randomize_list l)
*)
let random_list xs = 
  List.nth xs (Random.int (length xs))                                           

let randomize_list xs = 
  let permut = permutation xs in
  random_list permut


(******************************************************************************)
(* counter *)
(******************************************************************************)

let _compteur = ref 0
let compteur () = 
  _compteur := !_compteur + 1;
  !_compteur


(******************************************************************************)
(* persistence (sfl) *)
(******************************************************************************)
let get_value filename = 
  let chan = open_in filename in
  let x = input_value chan in
  close_in chan; x

let write_value value filename = 
  let chan = open_out filename in
  (output_value chan value; close_out chan)

let write_back func filename = 
  write_value (func (get_value filename)) filename
(******************************************************************************)
(* geometry (raytracer) *)
(******************************************************************************)

type vector = (float * float * float)
type point = vector
type color = vector (* color(0-1) *)

(* TODO factorise *)
let (dotproduct: vector * vector -> float) = 
  fun ((x1,y1,z1),(x2,y2,z2)) -> (x1*.x2 +. y1*.y2 +. z1*.z2)
let (length: vector -> float) = fun (x,y,z) -> sqrt (square x +. square y +. square z)
let (minus_point: point * point -> vector) = 
  fun ((x1,y1,z1),(x2,y2,z2)) -> ((x1 -. x2),(y1 -. y2),(z1 -. z2))
let (distance: point * point -> float) = 
  fun (x1, x2) -> length (minus_point (x2,x1))
let (normalise: vector -> vector) = 
  fun (x,y,z) -> let len = length (x,y,z) in (x /. len, y /. len, z /. len)
let (mult_coeff: vector -> float -> vector) = 
  fun (x,y,z) c -> (x *. c, y *. c, z *. c)
let (add_vector: vector -> vector -> vector) = 
  fun v1 v2 -> let ((x1,y1,z1),(x2,y2,z2)) = (v1,v2) in
  (x1+.x2, y1+.y2, z1+.z2)
let (mult_vector: vector -> vector -> vector) = 
  fun v1 v2 -> let ((x1,y1,z1),(x2,y2,z2)) = (v1,v2) in
  (x1*.x2, y1*.y2, z1*.z2)
let sum_vector = List.fold_left add_vector (0.0,0.0,0.0)

(******************************************************************************)
(* pics (raytracer) *)
(******************************************************************************)

type pixel = (int * int * int) (* RGB *)

(* required pixel list in row major order, line after line *)
let (write_ppm: int -> int -> (pixel list) -> string -> unit) = fun
  width height xs filename ->
    let chan = open_out filename in
    (
     output_string chan "P6\n";
     output_string chan ((string_of_int width)  ^ "\n");
     output_string chan ((string_of_int height) ^ "\n");
     output_string chan "255\n";
     List.iter (fun (r,g,b) -> 
       List.iter (fun byt -> output_byte chan byt) [r;g;b]
	       ) xs;
     close_out chan
    )
    
let test1 () = write_ppm 100 100 
    ((generate (50*100) (1,45,100)) ++ (generate (50*100) (1,1,100)))
    "img.ppm"


(******************************************************************************)
(* pics (icfp2) *)
(******************************************************************************)

let cat file = 
  let chan = open_in file in
  let rec aux ()  = 
    try 
(* cant do input_line chan::aux() cos ocaml eval from right to left ! *)
      let l = input_line chan in
      l::aux ()
    with End_of_file -> [] in
  aux ()

let interpolate str = 
  begin
    ignore(Unix.system ("printf \"%s\\n\" " ^ str ^ ">/tmp/caml"));
    cat "/tmp/caml"
  end
(* could do a print_string but printf dont like print_string *)
let echo s = printf "%s" s; flush stdout; s 



let push l v =
  l := v :: !l
