open Common
open Lib


module B_Array = Bigarray.Array2


let wall = 0xffff
let unreachable = 0xfffe
let max_dist = 0xfffd

type dist_space = {
    nb_slots : int ;
    time : float ;
    x_nb : int ;
    y_nb : int ;
    pos2distances : (position * (int, Bigarray.int16_unsigned_elt, Bigarray.c_layout) B_Array.t) list ;
  }


(*******************************************************************************)

(* TODO can have more robot on same place !!!! *)
type homebase_id = int
type square = 
  | OpenSpace2 of open_space
  | Wall2
  | Water2
and open_space = { 
    mutable homebase_id: homebase_id option;
    mutable seen: bool; (* true mean packages can be bigger
			   inv: seen = true => homebase = None
			*)
    (* nb_dropped: nb_picked: *)
    mutable robot: robot_id option;
    mutable packages: (package_id list); (* None on ne sait pas, Some on sait avec borne max *)
  } 

type homebase = {
    mutable picked: int;
    poshome: position;
  } 

type pack_state = Dropped (* by robot *) | Known (* dude was pushed/let by us *)
type package_info = {
    mutable pack: package option;
    mutable pospack: position; (* R avec la position du robot *) 
    mutable pack_state: pack_state;
    mutable in_robot: robot_id option;  (* R in_robot *)
  }

type objectif =
  | Home of int (* picked *)
  | PackPick of package_info
  | PackDrop of package
type plan = (position * objectif) list


type new_info =
  | NewPack of package_id
  | PackMoreInfo of package_id
  | NewRobot of robot_id
  | DeadRobot of robot_id
  | DeadPackage of package_id
  | NewDropped of package_id
  | NewPicked of package_id
(* RobotMoved *)

type world = {
    mutable wrobots: robot array;
    mutable nb_robots_alives: int;
    mutable wpackages: package_info option array;(* can disappear: drop by us, man with a package in water without pushed *)
    whomebase: homebase option array; (* R avec space *)
    space: square array array;
    maximum_capacity: int;
    money_default: int;
    me: robot_id;
    mutable many_robots_here: bool;

    mutable dist_space: dist_space;
    mutable nb_tour: int;

    (* plan *)
    mutable current_plan: plan;
    mutable update_plan: new_info list;

    (* TODO degrade info *)
    mutable degrade: int; (* when 1 and 6 -> random *)
    mutable evolution_distance: int list;
    (* mutable new_temporary_objectif *)
    

    mutable we_tried_to_kill: int;
  } 


(* invariant avec les R *)


let my_pos w  = w.wrobots.(w.me).posr
let pos w i   = w.wrobots.(i).posr



type state_us = {
    posus: position;
    moneyus: int;
    scoreus: int;
    package_us: package list;
    available_weight: int;
  }     


let string_of_objectif = function
  | Home i -> "Home " ^ (string_of_int i)
  | PackPick _ -> "PackPick"
  | PackDrop p -> "PackDrop" ^ (string_of_int p.package_id)

let string_of_plan plans = 
  (plans 
    +> List.map (fun ((x,y),obj) -> (Printf.sprintf "Obj: (%d, %d) :" x y) ^ (string_of_objectif obj))
    +> String.concat "") ^ "\n"
    
    
  
