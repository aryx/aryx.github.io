
(*******************************************************************************)
(* client *)
(* 
   why dont kill robot ?

   BUG package tjs vue ? server le fait ?

*****************************


  archi deadlock
  DONE

   archi plan
     start_turn: say what change
     engine: reset what change, make new plan if need to
     end_turn: say what change, tl the plan
   DONE

   pass jaune: reste jaune (portee truc modifie)
   DONE

   opti space
   DONE

   archi socket_string
   DONE
 
   arch take_possible
   DONE

   

  test avec maps avec knap
  gere poids possible
    + plan for dropp 

     plan for go on the road, pick some package
     time_cpu2

   archi cost_cpu front
   cas_special_debut
     front_onde d'ou on est
   apres dans limit en fonction du temps

   pb robot array zarb


   archi mem (avec front)

   archi time
     autour de choose
     mettre a zero donnee modifiers: fronts + plan
   DONE
     alarm time


   kan plus d obj, 
    ou cercher robot
     => le pusher, et pour savoir si package => robotKnow, robotunknown)

   1 contre 1

   nb_passage

*)


open Array
open Common
open Lib

open Client
open Knackpack

let get_space  w (x,y) = w.space.(x).(y)
let get_space2 w (x,y) = 
  match get_space w (x,y) with
  | OpenSpace2 e -> e
  | c -> failwith ("get_space2: " ^ (if c = Water2 then "Water2" else "Wall")
		   ^ " x:" ^ (string_of_int x)
		   ^ " y:" ^ (string_of_int y)
		  )

let set_space w (x,y) c = w.space.(x).(y) <- c

let robot_default w = 
  let money = w.money_default in
  {id = -1; money = money; score = 0; packages_in = []; is_alive = false; posr = (-1,-1)}

(* i can get called even if robot was not here,  ???? *)
let (erase_robot: world -> robot_id -> position -> unit) = fun w id (x,y) -> 
  let square = get_space2 w (x,y) in
  match square.robot with
  | Some id2 when id2 = id -> set_space w (x,y) (OpenSpace2 ({square with robot = None}))
  | _ -> ()
	

let add_update_plan w e = w.update_plan <- e::w.update_plan

let (kill_package: world -> package_id -> unit) = fun w id -> 
  (add_update_plan w (DeadPackage id);
  w.wpackages.(id) <- None
  )

(*   destroy homebase when seen => not anymore in objectives  *)
let (kill_homebase: world -> homebase_id -> unit) = fun w id -> 
  w.whomebase.(id) <- None

let modif_robot_life w id alive = 
  if w.wrobots.(id).is_alive <> alive then (
    w.wrobots.(id).is_alive <- alive;
    w.nb_robots_alives <- w.nb_robots_alives + (if alive then 1 else - 1)
  )
     

let (kill_robot: world -> robot_id -> unit) = fun w id -> 
  let rob = w.wrobots.(id) in
  let (x,y) = rob.posr in
  (if get_space w (x,y) <> Water2 then erase_robot w id (x,y);
   w.wrobots.(id).packages_in +> List.iter (fun id ->  kill_package w id);
   modif_robot_life w id false;
   add_update_plan w (DeadRobot id);
  )

let suppr_package_pos w pos id =
  let square = get_space2 w pos in
  set_space w pos (OpenSpace2 ({square with packages = square.packages +> 
				 List.filter (fun e -> e <> id)}))
    



let (update_package: world -> package_id -> (package option) -> position -> unit) = fun w id pack (x,y) -> 
  ((if id >= Array.length w.wpackages
  then 
      let newarray = Array.make (id + 1) None in
      (newarray +> Array.iteri (fun i e -> 
	try newarray.(i) <- w.wpackages.(i)
	with _ -> ()
			       );
       w.wpackages <- newarray;
      )
  );
  w.wpackages.(id) <- Some 
    (match w.wpackages.(id) with
    | None -> (
	add_update_plan w (NewPack id);
	{pack = pack; pospack = (x,y); pack_state = Dropped; in_robot = None}
       )
    | Some ({pack = p; pack_state = pack_state; in_robot = inr}) -> 
	{pack = 
	  (match (p, pack) with
	  | ((Some x,None) | (None,Some x)) -> (add_update_plan w (PackMoreInfo id); Some x)
	  | (Some _, Some x) -> Some x
	  | _ -> None
	  );
	  pack_state = pack_state; in_robot = inr; pospack = (x,y)
	} 
    )
  )
 
let (put_robot: world -> robot_id -> position -> unit) = fun w id (x,y) -> 
  if get_space w (x,y) == Water2 then
    (w.wrobots.(id).posr <- (x,y);
    kill_robot w id;
    )
  else
    let square = get_space2 w (x,y) in
    (set_space w (x,y) (OpenSpace2 ({square with robot = Some id}));
    w.wrobots.(id).packages_in +> List.iter (fun id -> update_package w id None (x,y));
    w.wrobots.(id).posr <- (x,y);
    )
   

let (new_robot: world -> robot_id -> position -> unit) = fun w id pos -> 
  ((if id >= Array.length w.wrobots
  then 
    let newarray = Array.init (id + 1) (fun _ -> robot_default w) in
    (newarray +> Array.iteri (fun i e -> 
      try newarray.(i) <- w.wrobots.(i)
      with _ -> ()
			     );
     w.wrobots <- newarray;
    )
  );
   add_update_plan w (NewRobot id);
   modif_robot_life w id true;
   w.wrobots.(id).id <- id;
   put_robot w id pos;
  )



(* cf type objectif
     I drop
     I move on Home (next_turn on verra ce qu'il y'a => si new package => need updatera, si rien, tl)
     I pick_known
*)
let one_step_plan_done w = 
  ((try (w.current_plan <- List.tl w.current_plan;
       w.evolution_distance <- [])
  with _ -> ()(*Printf.printf "Was not in plan\n"*)
  );
  (*Printf.printf "one_step done => %d\n" (List.length w.current_plan);*)
  )


(* modify update_plan, and plan (when on home) *)
let (update_world_package: world -> server_startturn -> unit) = fun w xs ->

  let _ = w.nb_tour <- w.nb_tour + 1 in
  let square = get_space2 w (my_pos w) in
  let pack_not_here = minus square.packages (xs +> List.map fst) in
  
  (
   pack_not_here +> List.iter (fun pack_id -> 	
     (*Printf.printf "%d: Note here anymore\n" w.me; flush stdout ;*)
     suppr_package_pos w (my_pos w) pack_id; kill_package w pack_id);
   (* TODO robot_bougeai plus => si on est la veut dire que mort *)
   let square = get_space2 w (my_pos w) in
   set_space w (my_pos w) (OpenSpace2 {square with seen = true});
   let square = get_space2 w (my_pos w) in
   let is_homebase2 = 
     (match square.homebase_id with
     | Some id -> (kill_homebase w id;
		   set_space w (my_pos w) (OpenSpace2 {square with homebase_id = None});
		   one_step_plan_done w;
		   None)
     | x -> x
     ) in
   let square = get_space2 w (my_pos w) in
   xs +> List.iter (fun (id, pack) -> 
     (update_package w id (Some pack) (my_pos w);
     (just w.wpackages.(id)).pack_state <- Known;
    set_space w (my_pos w) (OpenSpace2 ({square with packages = insert_normal id square.packages;
					  homebase_id = is_homebase2
					}));
    )
		  ))

  


(* modify update_plan 
   tl the plan!!
*)
let (update_world: world -> server_endturn list -> unit) = fun w xs -> 

  let alive_here = xs +> List.map (fun (i,op) -> i) in
  let alive = (Array.to_list (w.wrobots)) +> List.filter (fun e -> e.is_alive) +> List.map (fun e -> e.id) in
  let pushed = 
    let dropped = xs 
	+> List.filter (fun (i, op) -> 
	  match op with
	  |  A_Drop _ -> true
	  |   _ -> false)
	+> List.map fst +> uniq in
    dropped +> List.filter (fun i -> 
      let ops_i = xs +> List.filter (fun (j,_) -> i = j) in
      List.length ops_i >= 2
			   ) (* TODO it can be 1 if it behind a wall *)
  in

  (* kill dead robots *)
  uniq (minus alive (w.me :: alive_here)) +> List.iter (fun id -> kill_robot w id);

  (* note money decrease, (my money is already half done) *)
  alive +> List.iter (fun id -> w.wrobots.(id).money <- w.wrobots.(id).money -1);

  xs +> List.iter (function

  | (i, A_Nop) -> ()

  | (i, A_Appear (x,y)) -> 
      (* beware A_Appear can occur more than once *)
      new_robot w i (x,y)

  | (i, A_Move dir) -> 
	let { posr = (x',y') } = w.wrobots.(i) in 
	let (x,y) = Lib.move (x',y') dir in
	erase_robot w i (x',y');
	put_robot w i (x,y);
      
  | (i, A_Pick id) -> 
      let square = get_space2 w (pos w i) in
	(update_package w id None (pos w i);
	 (just w.wpackages.(id)).pack_state <- Known;
	suppr_package_pos w (pos w i) id;
	 (if (i <> w.me) then add_update_plan w (NewPicked id)
	 else one_step_plan_done w);
	 w.wrobots.(i).packages_in <- id::(w.wrobots.(i).packages_in);

	(just (w.wpackages.(id))).in_robot <- Some i;
	(match square.homebase_id with
	| Some i -> (just w.whomebase.(i)).picked <- (just w.whomebase.(i)).picked + 1;
	| None -> ()
	))
  | (i, A_Drop id) -> 
      (update_package w id None (pos w i);
       (just w.wpackages.(id)).pack_state <-
       if (i = w.me) || (List.mem i pushed) then Known else Dropped;

	 (*	etait pas forcemend dans le robot !! (car on arrive en cours) *)
       let square = get_space2 w (pos w i) in
       set_space w (pos w i) (OpenSpace2 ({square with packages = insert_normal id square.packages}));
	
       w.wrobots.(i).packages_in <- w.wrobots.(i).packages_in +> List.filter (fun e -> e <> id);
       (just (w.wpackages.(id))).in_robot <- None; (* etait pas forcement dedans *)
	
	(match ((just (w.wpackages.(id))).pack, pos w i) with
	| (Some ({weight = wei; destination = (x,y)}), (x',y')) when (x,y) = (x',y') -> 
	    w.wrobots.(i).score <- w.wrobots.(i).score + wei;

	    suppr_package_pos w (pos w i) id;
	    
	    if (i <> w.me) then add_update_plan w (NewPicked id);
	    kill_package w id;
	    if (i = w.me) then 
	      (* part of our plan => this is not a update plan *)
	      (one_step_plan_done w;
	      )
	    
	    
	| _ -> add_update_plan w (NewDropped id)
	)
      )
  ) ;

  let mypos = my_pos w in
  w.many_robots_here <- xs +> List.exists (function (i, A_Appear pos) -> i <> w.me && pos = mypos | _ -> false)
    

    
(*******************************************************************************)

let create_bot engine visual  = 
  let world = ref { wrobots   = [| |];
		    wpackages = [| |];
		    whomebase = [| |];
		    space     = [| |];
		    maximum_capacity = 1;
		    money_default = 1;
		    me = 1;
		    nb_robots_alives = 0;
		    update_plan = [];
		    current_plan = [];
		    we_tried_to_kill = 0;
		    many_robots_here = false;
		    degrade = 0;
		    evolution_distance = [];
		    nb_tour = 0;
		    
		    dist_space = (Wave.empty_dist_space 1 1)
		  } in

  {
    init =  (fun 
      (space, {uniq_id = myid; max_capacity = capa; initial_money = init}) -> 
	let counter = ref 0 in
	let homebases = ref [] in
	
	
	let newspace = space +> 
	  Array.mapi (fun i c -> 
	  c +> Array.mapi (fun j e -> 
	    match e with
	    | OpenSpace -> OpenSpace2 ({robot = None; packages = [];
					 homebase_id = None;
					 seen = false;
				       }
				      )
	    | Wall -> Wall2 | Water -> Water2
	    | HomeBase -> 
		(homebases := (i,j)::!homebases;
		 counter := !counter + 1;
		 OpenSpace2 ({robot = None; packages = [];
			       homebase_id = Some (!counter - 1);
			       seen = false;
			     })
		)
			  )) in
	let homes = (List.rev !homebases) +> List.map (fun (i,j) -> Some {picked = 0; poshome = (i,j)}) +> of_list in
	
	( 
	 world := { 
	  wrobots = [| |];
	  wpackages = [| |];
	  whomebase = homes;
	  space = newspace;
	  maximum_capacity = capa;
	  money_default = init;
	  nb_robots_alives = 0;
	  we_tried_to_kill = 0;
	   many_robots_here = false;
	  me = myid;
	   update_plan = [];
	   current_plan = [];
	   degrade = 0;
	   evolution_distance = [];
	   nb_tour = 0;
	  dist_space = Wave.empty_dist_space (Array.length newspace) (Array.length newspace.(0));
	})
	  
	    );
    engine =  (fun xs -> 
      (
       update_world_package (!world) xs;
       if visual then
	 (); (*
	 Client_dump.display_world (!world) (if !world.me >= 6 then 0 else (Array.length !world.space + 2) * (!world.me + 1));
		*)
       engine (!world);
      ));
    end_turn = (fun e -> update_world (!world) e)
  } 


(*******************************************************************************)
(* interface algo *)

let (distance: position -> position -> int) = fun (x,y) (x',y') -> 
  (* bird fly *)
  abs (x' - x) + abs (y' - y)


(* exact_one: si on est sur point connu, alors pas faire *)
(* TODO if unreach => BIG (money) *)
let (distance2: world -> position -> position -> int) = fun w will_be_added pos -> 
  try
    Wave.get_distance w.dist_space will_be_added pos
  with Not_found -> 
    try
      Wave.get_distance w.dist_space pos will_be_added
    with
      Not_found -> 
	let dist_space = Wave.add_distance w.dist_space w.space will_be_added in
	(w.dist_space <- dist_space;
	 Wave.get_distance w.dist_space will_be_added pos
	)

(* distance3 (interval/soft) *)   
(* distance4 recursif (mais arrete des que trouve, maintient pas list deja fait, juste point
   de choix (pile d'appel caml
*)
  
 

let arounds: world -> position -> (direction * position * open_space) list = fun w pos -> 
  [N;E;W;S] 
    +> List.map (fun dir -> (dir, move pos dir, get_space w (move pos dir)))
    +> List.map (fun (dir, pos, sp) -> match sp with OpenSpace2 x -> Some (dir, pos, x) | _ -> None)
    +> filter_some


let (next_moves_possible: world -> position -> position -> (direction list)) = 
  fun w pos_wanted pos_here -> 
    let arr = arounds w pos_here in
    if empty arr then []
    else arr
	+> List.map (fun (dir, pos, h) -> (dir, distance2 w pos_wanted pos))
	+> List.sort (fun (dir, dis) (dir', dis') -> dis <=> dis')
	+> pack_sorted (fun (dir, dis) (dir', dis') -> dis = dis')
	+> List.hd
	+> List.map fst

let next_moves_possible2 w pos_wanted pos_here = 
  let moves_possibles = next_moves_possible w pos_wanted pos_here in
  if empty moves_possibles then [Pick [2]]
  else moves_possibles +> List.map (fun dir -> Move dir)



(* pack together ? (list list) ou list array array 
   drop, home, pick
*)
let (objectifs: world -> (((position * objectif) list) * 
			    ((position * objectif) list) *
			    ((position * objectif) list)))
			    = fun w -> 
  (
   (w.wrobots.(w.me).packages_in +> 
    List.map (fun pack_id -> 
      let pack = just ((just (w.wpackages.(pack_id))).pack) in
      (pack.destination, PackDrop pack))),
   (w.whomebase +> Array.to_list +> filter_some +> List.map (fun home -> (home.poshome, Home home.picked))),
   (w.wpackages +> Array.to_list +> filter_some 
      +> List.filter (fun pack -> match pack.in_robot with 
      | Some id when id = w.me -> false
      | _ -> true)
      +> List.map (fun pack -> (pack.pospack, PackPick pack))
   )
   )
  


let (my_robot: world -> state_us) = fun w -> 
  let me = w.wrobots.(w.me) in
  let package = me.packages_in +> List.map (fun id -> ((just w.wpackages.(id)).pack) +> just) in
  { posus = me.posr;
    moneyus = me.money;
    scoreus = me.score;
    package_us = package;
    available_weight = (w.maximum_capacity - 
			  (package +> List.map (fun {weight = wei} -> wei) +> sum));
  } 

(* let alives *)

    
(*******************************************************************************)
     
let make_rdumb1 = create_bot
    (fun w -> {bid = 1; command = Move N})

let make_rdumb2 = create_bot
    (fun w -> {bid = 1; command = Move W})

(*******************************************************************************)

let make_rrandom  = create_bot
    (fun w -> {bid=1; command = 
		[Move N; Move W; Move E; Move S;
		  Drop [Random.int 10];
		  Pick [Random.int 10];
		]  +> random_list})

(*******************************************************************************)

let make_rrandom_safe  = create_bot 
    (fun w -> {bid=1; command = 
		([ Drop [Random.int 10];
		   Pick [Random.int 10];
		 ]  ++
		   (arounds w (my_pos w) +> List.map (fun (a,b,c) -> Move a)
		   ))		
		  +> random_list}
    )

(*******************************************************************************)

(* patterns (command list) -> full_command 
   patterns (local)
   survivor, plein de scenarios
   -> [liste coups avec dangerosit�, gains]
*)
let pattern_dumb w commands = {bid = 1; command =  random_list commands}

let deadlock_dumb w commands = commands

(* modify_plan 
   TODO: longer than 6 ?
    assign new objectif
*)
let deadlock_naive w fcommands = 
  match w.degrade with
  | d when (d >= 1) && (d < 6) -> 
      (w.degrade <- w.degrade + 1;
       [Move N; Move W; Move E; Move S]
      )
  | d when d >= 6 -> 
      (w.degrade <- 0; 
       w.evolution_distance <- [];
       w.update_plan <- []; (* safer otherwise need to call fcommands to update the plan when ned stuff *)
       [Move N; Move W; Move E; Move S]
      )
  | d -> 
      let commands = fcommands () in
      let when_start_degrade = 4 in
      let _ =
	if (List.length w.evolution_distance > when_start_degrade)
	then
	  (w.evolution_distance <- w.evolution_distance +> take when_start_degrade;
	   let evo = w.evolution_distance in
	   let evo_dist =
	     evo 
	       +> List.tl 
	       +> List.fold_left  (fun (before, cost) here -> (here, cost + (here - before))) (List.hd evo, 0)
	       +> snd in
	   if evo_dist <= 0 then
	     ((*Printf.printf "entering degraded mode\n";*)
	      w.degrade <- 1;
	     )
	  ) in
      commands

    
  

(* reset update_plan
   
*)
let make_gen pattern deadlock choose_what_to_do  = create_bot
    (fun w -> 
      try (
	let changed = w.update_plan in
	let _ = w.update_plan <- [] in (* reset the info *)
	
	let us  = my_robot w in
	
	(*let _ = Printf.printf "robot: id = %d, x = %d, y = %d, score = %d, time = %0.2f\n" w.me (fst us.posus) (snd us.posus) us.scoreus (Sys.time() /. float_of_int w.nb_tour) in*)
	
	let here_deliver = us.package_us +> List.filter (fun { destination = pos } -> pos = us.posus) in
	
	let command = pattern w ( deadlock w (fun () -> (
	
	
      (* survivor_time/fault:
	 
	 scenario_not_faisable_avec_pattern:
	 if here, next someone that can kill us, and on a dest, and not many live anymore
	 DROP (prend le risque)
      *)
	  if not (empty here_deliver) then
	    [Drop (here_deliver +> List.map (fun { package_id = id} -> id))]
	  else
	    if not ((List.length changed > 0) || (w.current_plan = []))
	    then (* apply plan  *)
	    (*let _ = (
	      Printf.printf "apply plan :)\n";
	      Printf.printf "%s" (string_of_plan w.current_plan)
	     ) in*)
	    
	    let (dest, op) = w.current_plan +> List.hd in
	    let _ = w.evolution_distance <- (distance2 w dest (my_pos w))::w.evolution_distance in
	    if dest <> (my_pos w) then
	      next_moves_possible2 w dest (my_pos w)
	    else 
	      [
		match op with
		| PackPick _ -> Pick (w.current_plan +> List.map
					(function (dest, PackPick {pack = Some {package_id = id}}) when dest = my_pos w 
					    -> Some id | _ -> None)
					+> filter_some)
		| PackDrop _ -> Drop (w.current_plan +> List.map
					(function (dest, PackDrop {package_id = id}) when dest = my_pos w 
					    -> Some id | _ -> None)
					+> filter_some)
		| Home _ -> failwith "if on home, then home not exist any more"
	      ] 
	  else 
	      let obj = objectifs w in
	      let (objc_dropped, objc_home, objc_pick)  = obj in
	      (*let _ =
		try Printf.printf "Pack info %d\n"  ((just (just w.wpackages.(0)).pack).package_id)
		with _ -> Printf.printf "PackInfo disappeared\n"
	      in *)
	      let obj_here = objc_pick
		  +> List.map (function (p, (PackPick x)) -> Some (p,x) | _ -> None) 
		  +> filter_some 
		  +> List.filter (fun (pos,_) -> pos = us.posus)
		  +> List.map snd
	      in
	      (choose_what_to_do w obj_here obj changed)
	 ))) in
       
	w.wrobots.(w.me).money <- w.wrobots.(w.me).money - (abs command.bid - 1) ;

	command

       ) with x -> 
	 (w.current_plan <- [];
	  w.update_plan <- [];
	  w.dist_space <- { w.dist_space with pos2distances = [] };
	  w.degrade <- 0;
	  w.evolution_distance <- [];
	  {bid = 1; command = Pick [2]})
	   (* raise x
	      failwith "Pb in bot" 
	      andom
	   *)
								   )
	  

(*******************************************************************************)

(* we have maximum_global on drop
   minimum local on visiting
*)




let take_pack_dumb w obj_here = 
  Some (Pick (obj_here +> List.map 
	  (fun packinfo -> (just packinfo.pack).package_id ))  (* here => know the pack *)	  
       )

(* does not drop 
   can return None !!!!!
*)
let take_pack_possible w obj_here = 
  let us = my_robot w in
  let obj_here'         = obj_here +> List.map (fun packinfo -> (just packinfo.pack)) in
  let obj_plus_rentable = 
    obj_here' +> List.sort (fun packa packb -> 
      ((packa.weight / (distance packa.destination us.posus )) <=> 
       (packb.weight / (distance packb.destination us.posus )) )
			   )
	+> List.rev 
  in
  let ids = 
    obj_plus_rentable +> 
    List.fold_left (fun (avai, taken) pack ->  
      let new_avai = avai - (pack.weight) in
      if new_avai > 0 then (new_avai, insert pack.package_id taken)
      else (avai, taken)) (us.available_weight, []) 
      +> snd in
  if empty ids then None else Some (Pick ids)


(* LLLLLL:
    je lui passe ceux que j'ai, ceux qui sont la
    m donne un objectif pack drop (=> gere pas les pick, 

    filter avant de l'appeler, car il va faire des distance2 !!!
    TODOsi plus place alors an moins faudrait essayer des les picker

   resultat = plan;
     real_plan = Drop ceux plus present, pick new, drop a leur dest

   manage overload, mean that with this algo, plan will be either one element,
    or list of drop, list pick
*)


(* TODO
   knapsbag big

      filter_obj:
   look if compatible with objectif (ameliore objectif)
   update_plan
   get_new_plan
   (allow drop to be able to take)
*)

let take_pack_knapstack w obj_here = 
  let obj_here' = obj_here +> List.map (fun packinfo -> (just packinfo.pack)) in
  let res = greedy_pick w obj_here' (my_robot w) distance2 in
  (*  (List.iter (Printf.printf "KNAP = %d;") res; Printf.printf "\n";*)
   (w.current_plan <- 
     (res 
	+> List.map (fun id -> 
	  let packinfo = just (w.wpackages.(id)) in
	  let pack = just packinfo.pack in
	  (((my_pos w), PackPick packinfo),
	     (pack.destination, PackDrop pack)
	  )
		    )
	+> (fun xs -> 
	  let (picked, futur_dropped) = (xs +> List.map fst, xs +> List.map snd) in
	  let drop_i_have = [] in
	  drop_i_have ++ picked ++ futur_dropped
	   )
	);
   w.evolution_distance <- [];
   Some (Pick res)
  )


let filter_dumb = 
  (fun w obj -> 
    let (objc_dropped, objc_home, objc_pick)  = obj in
    objc_dropped ++ objc_home ++ objc_pick
  )
  
(* 

  trier pour size raisonnable: des que hard_limit => stop, when choice => sort
    tri distance => vol d'oiseau si deja trop fait

   first deliver
     trier per dist/poids

   package_sur ou homebase ou package_pas_sur
     trier sur distance/qqun d'autre pret

   1 - (cost_un per not in cache)

*)

(* look at available slot in wave module 
   
*)
(* front from ici

   take X de 
     take package on him + proche
     take homebase + proche
     take pick + proche
   
   
*)
let sort_obj_per_dist = 
  List.sort (fun (a,b,c) (a',b',c') -> a <=> a') (* look if moi = + pret *)

let filter_better = 
  (fun w obj -> 
    let (objc_dropped, objc_home, objc_pick)  = obj in
    let my_pos   = my_pos w in
    let us = my_robot w in 
    
    let sort_obj objs = 
      objs 
	+> List.map (function (pos, obj) -> (distance2 w my_pos pos , pos, obj)) (* !!!! FRONT from here *)
	+> sort_obj_per_dist in

    let objc_pick_sorted = (sort_obj objc_pick) in
    let objc_pick_sorted' = objc_pick_sorted +> 
      List.filter (function 
	| (dis, pos, PackPick {pack =  Some {weight = wei}}) -> wei < us.available_weight
	| _ -> true) in


    let objc_pick_free = objc_pick_sorted' +> 
      List.filter (function
	| (dis, pos, PackPick {in_robot = Some id}) -> false
	| _ -> true) in
    let objc_pick_in = minus objc_pick_sorted' objc_pick_free in
    
    let obj_alls = 
      (sort_obj objc_dropped)  (* filtrer sur packet/home inateignables *)
	++ (sort_obj objc_home) 
	++ (objc_pick_free) in
    let obj_alls' =  if empty obj_alls then objc_pick_in else obj_alls in
    let _tassed = obj_alls +> List.iter
	(fun (dist, pos, obj) -> 
	  match Wave.put_front w.dist_space pos with
	  | Some dist_space -> w.dist_space <- dist_space
	  | None -> ()) in
    let dones = ref [] in
    let rest  = ref obj_alls in
    let objs_where_dist_not_costly = 
      try 
	(while (Sys.time () /. (float_of_int w.nb_tour)) < 0.8 do
	  let hed = List.hd (!rest) in
	  let (dist, pos, obj) = hed in
	  let _ = distance2 w pos my_pos in
	  (dones := (hed::(!dones));
	   rest  := List.tl (!rest))
	done;
	 (*Printf.printf "TIMEOUT\n";*)
	 List.rev (!dones))
      with _ -> List.rev (!dones) in
    objs_where_dist_not_costly +> List.map (fun (dist, pos, obj) -> (pos, obj))
  )


(*
  package_sur 
    heuri (capa, plan)  -> int 

  Drop: f1 (score, distance) = score / distance * c1
  PickKnow: f2 (distance,score) = score / distance * c2
  PickUnknow: f3(distance) = distnace * c3
  Home: f4(distance) = distance * c4
  
*)


(* TODO: intersect calculus with what changed *)
let need_new_plan_dumb w changed = 
  ((w.current_plan +> List.length) = 0) ||
  (not (empty changed))

let need_new_plan_better w changed = 
  let changed' = changed
      +> List.filter 
      (function
	| NewDropped _ -> false
	| NewPicked id -> 
	    (try 
	      (let pos_pack = (just w.wpackages.(id)).pospack in
	      w.current_plan +> 
	        List.exists (fun (pos,_) -> pos = pos_pack)
	      ) with _ -> true)
	| _ -> true
      ) 
  in
  ((w.current_plan +> List.length) = 0) ||
  (not (empty changed'))
      

(* minimum local, dont manage overload (=> loop) *)
let best_plan_dumb = (fun w objs -> 
  try 
    objs 
      +> List.map (function (pos, obj) -> (distance2 w pos (my_pos w), pos, obj))
      +> sort_obj_per_dist 
      +> List.hd
      +> (fun (dir, pos, obj) -> [pos, obj])
  with _ -> [])

(* commerce *)
(* permut + coup (when dim < 4) *)

let (cout_voyage: world -> position list -> int) = fun w xs ->
  xs +> List.tl +> 
  List.fold_left  (fun (before, cost) here -> (here, cost + (distance2 w here before))) (List.hd xs, 0)
    +> snd

let borne_naive = 8
let best_plan_commerce_naive = (fun w objs -> 
  let us = my_robot w in
  try
    (let raisonnable = 
      objs
	+> List.map (function (pos, obj) -> (distance2 w pos (my_pos w), pos, obj))
	+> sort_obj_per_dist 
	+> take_2 borne_naive
	in
    let permuts = permutation raisonnable in
    permuts 
      +> List.map (fun xs -> (xs,
			      cout_voyage w (us.posus::(xs +> List.map (fun (dist_a_moi, pos, obj) -> pos)))))
      +> List.sort (fun (per1, cost1) (per2, cost2) -> cost1 <=> cost2) 
      +> List.hd
      +> fst
      +> List.map (fun (d, pos, obj) -> (pos, obj))
    )
  with _ -> []
			       )

      
    


(* jarod *)

(* 
   deadlock plan (savoir perdre)

   look if need update plan
   can make new plan
     if a pas eu le tps de faire calcul objectiv precis (some distance were not exact)

*)	

let choose_what_to_do take_or_drop_pack filter_obj get_new_plan need_new_plan  = fun w obj_here obj changed -> 
  let us  = my_robot w in
  let if_nopick_nodrop () = 
    let _ = 
      (if need_new_plan w changed then
	let obj' = filter_obj w obj in
	let plan = obj' +> get_new_plan w in
	(w.current_plan <- plan;
	 w.evolution_distance <- [];
	 (*Printf.printf "New plan = %s\n" (string_of_plan plan);*)
	)
      ) in
    
    if not (empty w.current_plan)
    then
      (*let _ = (Printf.printf "apply plan :)\n";
	      Printf.printf "%s" (string_of_plan w.current_plan)) in*)
      let dest = w.current_plan +> List.hd +> fst in

      next_moves_possible2 w dest us.posus
    else
      (* first reachable !!! *)
      
      (* put in plan first cell not seen (pas optimal ms bon)
	 ratisser 
      *)


	    (* no more objectif => either in robot or on map *)
	    (* TODO: ratisser ou chasser le robot, ratisser pas deja vu *)
      ((arounds w (my_pos w) +> List.map (fun (a,b,c) -> Move a)))
  in

  if not (empty obj_here) then
    match take_or_drop_pack w obj_here with 
    | None -> if_nopick_nodrop ()
    | Some c -> [c] (* take_or_drop have certainly updated the plan *)
	  
  else if_nopick_nodrop ()


let make_ralone = make_gen 
    (* pattern_dumb *)
    Pattern.choose_using_advices
    deadlock_naive
      (choose_what_to_do
	 take_pack_possible (* dump/knapstack_can_drop *)
	 filter_better
	 best_plan_commerce_naive (* dumb/commerce_heuri *)
	 need_new_plan_better (* dumb *)
	 (*
	 take_pack_knapstack
	 filter_better
	 best_plan_dumb
	 need_new_plan_dumb
	 *)
      )

			      
  

(*******************************************************************************)

      
(*

gestion temps:
 path_finding,se limiter dans calcul distance objectif


commerce:
 fourmi: 
   gere plusieurs packets
   gere plusieurs packets + ceux que on a + 
   gere package a prendre (/homebase)

 obj: d'abord les sures

  essaye 1 obj = valeur
  essaye 2 obj ....


scenario:
  interet d'aller sur zone ? peut en prendre 10, 
    pas grave si pushed, on en garde 9

  


per robot:
 what they know
 (when drop, they are not sure
  when new arrive => we know what they know
   => package disseminer, on peut y aller et etre sur que meme si plus pret, il ira pas :)
   
*)
      
      
      
let nv = false

let robots_arena = [ 
  make_ralone true;
  make_ralone nv;
  make_rdumb1 nv; make_rrandom nv; make_rrandom_safe nv; 
  make_ralone nv;
  make_ralone nv;
  make_ralone nv
		   ]
