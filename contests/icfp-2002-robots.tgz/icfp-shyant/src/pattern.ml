open Common
open Lib
open Client

type bid = Minimal_bid | Small_bid | Neg_small_bid | Big_bid

type advice = 
  | Force of direction list 
  | Forbid of direction option
  | Kill of direction 
  | Suggest of (bid * direction)

let int_of_bid = function
  | Minimal_bid -> 1
  | Small_bid -> 2
  | Big_bid -> 5
  | Neg_small_bid -> -2

let is_water = function
  | Water2 -> true
  | _ -> false

let is_concrete = function
  | Water2 | Wall2 -> true
  | _ -> false

let may_have_many_packages = function
  | OpenSpace2 o ->
      if o.seen then List.length o.packages > 1 else o.homebase_id <> None
  | _ -> false

let has_robot = function
  | OpenSpace2 { robot = Some _ } -> true
  | _ -> false

let escape_water snapshot =
  if is_water snapshot.(2-1).(2+0) then
    if has_robot snapshot.(2+1).(2+0) then [ Force [ N ; S ] ]
    else if has_robot snapshot.(2+1).(2+1) ||
            has_robot snapshot.(2+1).(2-1) ||
            has_robot snapshot.(2+2).(2+0) then
      Forbid None :: List.map (fun dir -> Suggest(Neg_small_bid, dir)) [N;S;E]
    else []
  else []

let prevent_dangerous_situation snapshot =
  let advice1 = 
    if is_water snapshot.(2-1).(2+1) && (
         has_robot snapshot.(2+1).(2+0) ||
         has_robot snapshot.(2+1).(2+1) ||
         has_robot snapshot.(2+1).(2+2) ||
         has_robot snapshot.(2+2).(2+1)
    ) then
      [ Forbid (Some N) ]
    else [] in
  let advice2 = 
    if is_water snapshot.(2-1).(2-1) && (
         has_robot snapshot.(2+1).(2+0) ||
         has_robot snapshot.(2+1).(2-1) ||
         has_robot snapshot.(2+1).(2-2) ||
         has_robot snapshot.(2+2).(2-1)
    ) then
      [ Forbid (Some S) ]
    else [] in
  advice1 @ advice2

let someone_near_water world snapshot =
  if is_water snapshot.(2-2).(2+0) then
    if has_robot snapshot.(2+1).(2+0) then
      Forbid (Some W) :: Forbid None :: List.map (fun dir -> Suggest(Small_bid, dir)) [N;S;E]
    else if has_robot snapshot.(2+0).(2-1) || has_robot snapshot.(2+0).(2+1) || world.many_robots_here then
      [ Forbid (Some W) ]
    else if has_robot snapshot.(2-1).(2+0) then
      [ Kill W ]
    else []
  else []

let near_homebase snapshot =
  if may_have_many_packages snapshot.(2-1).(2+0) && (
    has_robot snapshot.(2-2).(2+0) ||
    has_robot snapshot.(2-1).(2-1) ||
    has_robot snapshot.(2-1).(2+1)
  ) then
    [ Suggest(Neg_small_bid, W) ]
  else []

let suggest_bid_against_opponents carrying_something snapshot = 
  if carrying_something then
    if has_robot snapshot.(2-2).(2+0) ||
       has_robot snapshot.(2-1).(2-1) ||
       has_robot snapshot.(2-1).(2+1) 
    then
      [ Suggest(Neg_small_bid, W) ; Suggest(Minimal_bid, E) ]
    else if has_robot snapshot.(2-1).(2+0) then	    
      [ Suggest(Small_bid, S) ; Suggest(Small_bid, N) ]
    else []
  else if has_robot snapshot.(2-1).(2+0) && may_have_many_packages snapshot.(2-1).(2+0) then
    [ Suggest(Small_bid, W) ]
  else []

(*
open Graphics

let scale = 10;;

let cempty = white
let cwall  = black
let cwater = blue
let chomeb = green
let cme = magenta
let cother = red
let cpack = yellow
let cseen = rgb 84 84 84

let draw_square cst sq x y  = 
  let f = match sq with
      Wall2 -> set_color cwall ; fill_rect 
    | Water2 -> set_color cwater ; fill_rect
    | OpenSpace2({robot=r; packages = p; homebase_id = homeb;
		   seen = seen;
		 }) -> 
		   (match (r, homeb, p, seen) with
		   | (Some id,_,_,_) -> set_color (if id = 0 then cme else cother); fill_rect
		   | (_, Some _,_,_) -> set_color chomeb; fill_rect
		   | (_,_, a::ass,_) -> set_color cpack; fill_rect
		   | (_,_,_,true) -> set_color cseen; fill_rect
		   | _ -> (set_color cempty; fill_rect ((x+cst) *scale) (y*scale) scale scale;
			   set_color cwall ; draw_rect)
	      )
  in f ((x+cst)*scale) (y*scale) scale scale;;

let test_draw space cst =
  space +> Array.iteri (fun x row -> 
    row +> Array.iteri (fun y sq -> 
      draw_square cst sq x y 
		       ))
*)

let string_of_bid = function
  | Minimal_bid -> "Minimal_bid"
  | Small_bid -> "Small_bid" 
  | Neg_small_bid -> "Neg_small_bid"
  | Big_bid -> "Big_bid"

let string_of_advice = function
  | Force directions -> "Force " ^ String.concat " " (List.map string_of_direction directions)
  | Forbid None -> "Forbid staying here"
  | Forbid (Some dir) -> "Forbid " ^ string_of_direction dir
  | Kill dir -> "Kill " ^ string_of_direction dir
  | Suggest(bid,dir) -> "Suggest " ^ string_of_bid bid ^ " " ^ string_of_direction dir

let advice_funcs (world, carrying_something) = [
  escape_water ; 
  prevent_dangerous_situation ; 
  someone_near_water world ; 
  near_homebase ;
  suggest_bid_against_opponents carrying_something ;
]

let local_get_advices info snapshot = 
  collect (fun f -> f snapshot) (advice_funcs info)


let create_snapshot space (c_x,c_y) =
  let snapshot = Array.create_matrix 5 5 Wall2 in
  for x = -2 to 2 do
    if 0 < c_x+x && c_x+x < Array.length space - 1 then
      for y = -2 to 2 do
	if 0 < c_y+y && c_y+y < Array.length space.(0) - 1 then
	  snapshot.(x+2).(y+2) <- space.(c_x+x).(c_y+y)
      done
  done ;
  snapshot

let get_set a i v =
  let old_v = a.(i) in
  a.(i) <- v ;
  old_v

let array_rev a =
  let la = Array.length a in
  for i = 0 to la / 2 do
    a.(la - i - 1) <- get_set a i a.(la - i - 1)
  done

let rotation_90 snapshot = 
  for x = 0 to 1 do
    for y = 0 to 2 do
      let v1 = snapshot.(x).(y) in
      let v2 = get_set snapshot.(4-y) (x) v1 in
      let v3 = get_set snapshot.(4-x) (4-y) v2 in
      let v4 = get_set snapshot.(y) (4-x) v3 in
      snapshot.(x).(y) <- v4
    done
  done

let vert_symmetry snapshot = array_rev snapshot
let horiz_symmetry snapshot = Array.iter (array_rev) snapshot

let gen_adapt adapt = function
  | Force directions -> Force (List.map adapt directions)
  | Forbid None -> Forbid None
  | Forbid (Some dir) -> Forbid (Some (adapt dir))
  | Kill dir -> Kill (adapt dir)
  | Suggest(bid, dir) -> Suggest(bid, adapt dir)

let adapt2 = function N -> N | S -> S | E -> W | W -> E
let adapt3 = function N -> W | S -> E | E -> S | W -> N
let adapt4 = function N -> W | S -> E | E -> N | W -> S

let get_advices ((world, _) as info) pos =
  let snapshot = create_snapshot world.space pos in
  let bad_directions = filter_some [
    if is_concrete snapshot.(2+0).(2-1) then Some S else None ;
    if is_concrete snapshot.(2+0).(2+1) then Some N else None ;
    if is_concrete snapshot.(2-1).(2+0) then Some W else None ;
    if is_concrete snapshot.(2+1).(2+0) then Some E else None ;
  ] in
  let adv1 = local_get_advices info snapshot in vert_symmetry snapshot ;
  let adv2 = local_get_advices info snapshot in rotation_90 snapshot ;
  let adv3 = local_get_advices info snapshot in vert_symmetry snapshot ;
  let adv4 = local_get_advices info snapshot in
  (*
  print_endline "adv1" ; List.iter (fun adv -> print_endline (string_of_advice adv)) adv1 ;
  print_endline "adv2" ; List.iter (fun adv -> print_endline (string_of_advice adv)) adv2 ;
  print_endline "adv3" ; List.iter (fun adv -> print_endline (string_of_advice adv)) adv3 ;
  print_endline "adv4" ; List.iter (fun adv -> print_endline (string_of_advice adv)) adv4 ;
  *)
  let adv = adv1 @ 
    List.map (gen_adapt adapt2) adv2 @
    List.map (gen_adapt adapt3) adv3 @
    List.map (gen_adapt adapt4) adv4 in
  bad_directions, adv

let random_command = function
  | [] -> 
      Printf.eprintf "random_command called with empty list, this should not happen!!\n" ; flush stderr ;
      Pick []
  | l -> random_list l

let choose_using_advices world commands_choices =
  if world.nb_robots_alives = 1 then
    { bid = 1 ; command = random_command commands_choices }
  else

  (*let _ = Printf.printf "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX %d \n" world.nb_robots_alives in*)
  let be_agressive = world.nb_robots_alives <= 3 in
  let carrying_something = world.wrobots.(world.me).packages_in <> [] in

  let proposed_moves commands =
    filter_some ((List.map (function Move dir -> Some dir | _ -> None)) commands)
  in

  let my_pos = my_pos world in
  let bad_directions, raw_adv = get_advices (world, carrying_something) my_pos in
  (*if raw_adv <> [] then
    Printf.printf "#%d (%2d,%2d): %s (proposed %s)\n" world.me (fst my_pos) (snd my_pos) (String.concat ", " (List.map string_of_advice raw_adv)) (String.concat ", " (List.map string_of_command commands_choices)) ;
*)
  let forbidden, adv = fpartition (function Forbid may_dir -> Some may_dir | _ -> None) raw_adv in
  let forbidden_directions, forbid_no_move = fpartition id forbidden in

  let commands_choices = 
    if forbid_no_move = [] then commands_choices 
    else List.filter (function Drop _ | Pick _ -> false | _ -> true) commands_choices
  in

  match fpartition (function Force directions -> Some directions | _ -> None) adv with
   | [], vs -> 
       (let bad_directions = forbidden_directions @ bad_directions in (* since we're not *forced* to move, do not use forbidden_directions *)
       match List.partition (function Kill _ -> true | _ -> false) vs with
       | Kill dir :: _, _ when be_agressive && world.we_tried_to_kill < 5 && not (List.mem dir bad_directions) ->
	   world.we_tried_to_kill <- world.we_tried_to_kill + 1 ;
	   { bid = int_of_bid Big_bid ; command = Move dir }
       | _, vs ->
	   let commands_choices_ = List.filter (function
	     | Pick _ | Drop _ -> true
	     | Move dir -> not (List.mem dir bad_directions)
	   ) commands_choices in

	   let suggestions = List.map (function Suggest(bid, dir) -> dir, bid | _ -> failwith "bad in choose_using_advices") vs in
	   let suggestions = if suggestions = [] then List.map (fun dir -> dir, Minimal_bid) (minus [N;S;E;W] bad_directions) else suggestions in

	   if commands_choices_ = [] then
	     if suggestions = [] then { bid = 1; command = Pick [2]} (* PAD *)
	     else  
	       let dir, bid = random_list suggestions in
	       { bid = int_of_bid bid ; command = Move dir }
	   else

	   let l2 = inter (List.map fst suggestions) (proposed_moves commands_choices_) in
	   if l2 = [] then
	     { bid = 1 ; command = random_command commands_choices_ }
	   else
	     let dir = random_list l2 in
	     { bid = int_of_bid (List.assoc dir suggestions) ; command = Move dir })

   | force :: forces, _ -> 
       let l1 = List.fold_left inter force forces in
       let l1 = minus l1 bad_directions in
       if l1 = [] then (* oh my, what can i do?? *) { bid = 1 ; command = random_command commands_choices } else
       let l2 = minus l1 forbidden_directions in
       let l2 = if l2 = [] then l1 else l2 in (* override Forbid'den directions *)

       let l3 = inter l2 (proposed_moves commands_choices) in
       let l3 = if l3 = [] then l2 else l3 in (* don't care about proposed move, it's dangerous here! *)
       { bid = int_of_bid Big_bid ; command = random_command (List.map (fun dir -> Move dir) l3) }
          


(*
let test_space =
[|
  [| 0;0;0;0;0;0 |] ;
  [| 0;0;0;0;0;0 |] ;
  [| 0;0;4;0;0;0 |] ;
  [| 0;4;9;0;9;0 |] ;
  [| 0;2;1;0;0;0 |] ;
  [| 0;9;4;9;0;0 |] ;
  [| 0;0;0;0;0;0 |] ;
|]

let empty_open_space =
  {robot = None; packages = [];
   homebase_id = None;
   seen = false;
 }

let test() =
  let pos = ref (0,0) in
  let test_space = Array.mapi (fun x a -> 
    Array.mapi (fun y -> function
      | 4 -> Water2
      | 0 -> OpenSpace2 empty_open_space
      | 2 -> OpenSpace2 { empty_open_space with homebase_id = Some 0 }
      | 1 -> 
	  pos := (x,y) ;
	  OpenSpace2 { empty_open_space with robot = Some 0 }
      | 9 -> OpenSpace2 { empty_open_space with robot = Some 1 }
      | _ -> failwith "bad test"
    ) a) test_space in
  let adv = get_advices test_space !pos in

  print_endline "";
  List.iter (fun adv -> print_endline (string_of_advice adv)) adv ;
  flush stdout ;
  test_draw (create_snapshot test_space !pos) 5 ;
  input_line stdin ;

  adv
*)
