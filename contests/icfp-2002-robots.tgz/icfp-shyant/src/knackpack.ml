open Lib
open Client

let get_package_from w pack_id =     
  match w.wpackages.(pack_id) with
      Some({pack=Some(p)}) -> p
    |  _     -> failwith "nopackage";;


let group_by_dest package_l = 
  let rec insert pack l = 
    match l with
	[] -> [(pack.destination,[pack])]
      | (d,ld)::l1 -> if d = pack.destination 
	            then
		      (d, pack::ld)::l1
	            else
		      (d,ld)::(insert pack l1)
  in
  let rec group acc l =
    match l with
	[] -> acc
      | a::l1 -> group (insert a acc) l1
  in
  group [] package_l

(* Compare packages with same destination *)

let compare_package (dist:position -> position ->int) (pos:position)  p1l p2l =
  let eval_package  (d,ld) = 
    let d = float_of_int(dist pos d)
    in
      if ( d = 0.0 ) 
      then -1.0
      else float_of_int(List.fold_left (fun x y -> x+ y.weight) 0 ld ) /. d
  in
  let sc1 = eval_package p1l
  and sc2 = eval_package p2l
  in
  compare sc1 sc2;;

(* extract first n items *)
let get_first n l = 
  let rec f n acc l = 
    match l with
	[] -> acc
      | a::l1 -> if n> 0 then f (n-1) (a::acc) l1
	           else acc
  in
  f  n [] l;;


(* Compute an heuristics order in which packages could be dropped *) 

let greedy_knackpack  dist money  capa pos drop_package_list  =
  let rec gr pos  acc_package money capa p_list =
    match p_list with
	[] -> acc_package
      | a:: l -> let ll = List.sort (compare_package dist pos) p_list
	         in let (d,ld) =List.hd ll 
	         in let dst = dist pos d
		    and wei = (List.hd ld).weight
	            and len = List.length ld
                 in 
		 let nb = min (capa / wei) len
		 in
		 if (dst < money) 
		 then gr d ((get_first nb ld)@acc_package) (money - dst) 
                                                 (capa - nb*wei) (List.tl ll)
		 else acc_package
  in
  List.rev (gr pos [] money capa (group_by_dest drop_package_list))


let  greedy_pick world pack state distance =
  List.map (fun x -> x.package_id) 
    (greedy_knackpack (distance world) state.moneyus world.maximum_capacity state.posus pack)



let eval_package_list dist pos pkg_list =
  let score_of_packages = List.fold_left (fun x y -> x+ y.weight) 0 
  in let rec dist_of_packages p  pkg_list =
    match pkg_list with
	[] -> 0
      | a::l -> dist p (a.destination)  +
	  (dist_of_packages (a.destination) l)
  in
  let d = dist_of_packages  pos pkg_list
  and s = score_of_packages pkg_list
  in
  (float_of_int s) /. (if d = 0  then 1.0 else (float_of_int d  ))






(* 
   drop_list : ever ordered
   money : minimum required  to drop 
   
   Try to insert picks in the path
*)

(*let insert_pick_in_travel dist pos (drop_list,money)  money_left   pick_package_list*)
  
