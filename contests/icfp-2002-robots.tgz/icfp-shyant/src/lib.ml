open Common

type package_id = int
type robot_id = int
type position = int * int

type direction = N | E | W | S


type raw_square =
  | OpenSpace
  | HomeBase
  | Wall
  | Water


type action = 
  | A_Move of direction
  | A_Pick of package_id
  | A_Drop of package_id
  | A_Appear of position
  | A_Nop

type robot = {
    mutable id: robot_id; (* mutable for faineantise *)
    mutable money: int; (* estimation pour les autres *)
    mutable score: int; (* estimation pour les autres *)
    mutable packages_in: package_id list;
    mutable is_alive: bool; 
    mutable posr: position; (* R avec space *)
    (* poids_libre 
    *)
  }

type package = {
    package_id: package_id;
    weight: int;
    destination: position;
  } 

type command = 
  | Move of direction
  | Pick of package_id list
  | Drop of package_id list

type full_command = {
    bid: int;
    command: command;
  }


type board = raw_square array array
      
type config_player = { 
    uniq_id: int;
    max_capacity: int;
    initial_money: int;
  } 

type server_startturn = (package_id * package) list
type server_endturn   = robot_id * action


type bot = {
    init: (board * config_player) -> unit;
    engine: server_startturn -> full_command;
    end_turn: (server_endturn list) -> unit;
  } 


let string_of_direction = function
  | N -> "N"
  | S -> "S"
  | E -> "E"
  | W -> "W"


let string_of_command = function
  | Move direction -> "Move " ^ string_of_direction direction
  | Pick package_id -> "Pick " ^ String.concat " " (List.map string_of_int package_id)
  | Drop package_id -> "Drop " ^ String.concat " " (List.map string_of_int package_id)

let string_of_action = function
  | A_Move direction -> "Move " ^ string_of_direction direction
  | A_Pick package_id -> "Pick " ^ string_of_int package_id
  | A_Drop package_id -> "Drop " ^ string_of_int package_id
  | A_Appear (x,y) -> Printf.sprintf "Appear %d %d" x y
  | A_Nop -> "Nop"

let move (x,y) = function
  | N -> x, y+1
  | S -> x, y-1
  | E -> x+1, y
  | W -> x-1, y


let get_map in_channel =
  let size_x, size_y =
    let s = input_line in_channel in
    let l = List.map int_of_string (split_on_char ' ' s) in
    List.nth l 0, List.nth l 1
  in
  let arr = Array.make_matrix (size_x+2) (size_y+2) Wall in
  for y = 1 to size_y do
    let s = input_line in_channel in
    for x = 1 to size_x do
      let v = 
	match s.[x-1] with
	| '.' -> OpenSpace
	| '~' -> Water
	| '@' -> HomeBase
	| '#' -> Wall
	| _ -> failwith ("invalid string " ^ s)
      in
      arr.(x).(y) <- v
    done
  done ;
  arr
