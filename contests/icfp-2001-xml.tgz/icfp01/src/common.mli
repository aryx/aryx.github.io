exception Found
exception GraphSort_circular_deps of int * int
val bpos : string * int * int
val norm : int * int -> int
val unipos : string * int * int -> string * int * int -> string * int * int
val uniposl : (string * int * int) list -> string * int * int
val ( => ) : bool -> bool -> bool
val xor : 'a -> 'a -> bool
val id : 'a -> 'a
val double : 'a -> 'a * 'a
val sum : int list -> int
val swap : 'a * 'b -> 'b * 'a
val uncons : 'a list -> 'a * 'a list
val safe_tl : 'a list -> 'a list
val drop : int -> 'a list -> 'a list
val o : ('a -> 'b) -> ('c -> 'a) -> 'c -> 'b
val curry : ('a * 'b -> 'c) -> 'a -> 'b -> 'c
val uncurry : ('a -> 'b -> 'c) -> 'a * 'b -> 'c
val is_int : float -> bool
val fst3 : 'a * 'b * 'c -> 'a
val snd3 : 'a * 'b * 'c -> 'b
val thr3 : 'a * 'b * 'c -> 'c
val has_env : string -> bool
val some : 'a option -> 'a
val some_or : 'a option -> 'a -> 'a
val merge_some : ('a -> 'a -> 'a) -> 'a option -> 'a option -> 'a option
val uniq : 'a list -> 'a list
val uniq_ : ('a -> 'a -> bool) -> 'a list -> 'a list
val non_uniq : 'a list -> 'a list
val find_some : ('a -> 'b option) -> 'a list -> 'b
val fpartition : ('a -> 'b option) -> 'a list -> 'b list * 'a list
val keep_best : ('a * 'a -> 'a option) -> 'a list -> 'a list
val sorted_keep_best : ('a -> 'a -> 'a option) -> 'a list -> 'a list
val sorted_insert : ('a -> 'a -> int) -> 'a -> 'a list -> 'a list
val map : ('a -> 'b) -> 'a list -> 'b list
val fold_right1 : ('a -> 'a -> 'a) -> 'a list -> 'a
val fold_left1 : ('a -> 'a -> 'a) -> 'a list -> 'a
val insertin : 'a -> 'a list -> 'a list list
val map_flatten : ('a -> 'b list) -> 'a list -> 'b list
val permutations : 'a list -> 'a list list
val maxl : 'a list -> 'a
val stack2list : 'a Stack.t -> 'a list
val fix_point : ('a -> 'a) -> 'a -> 'a
val fix_point_ : int -> ('a -> 'a) -> 'a -> 'a * int
val do_withenv :
  (('a -> 'b) -> 'c -> 'd) -> ('e -> 'a -> 'b * 'e) -> 'e -> 'c -> 'd * 'e
val do2_withenv :
  (('a -> 'b -> 'c) -> 'd -> 'e -> 'f) ->
  ('g -> 'a -> 'b -> 'c * 'g) -> 'g -> 'd -> 'e -> 'f * 'g
val map_withitself : ('a list -> 'a -> 'a) -> 'a list -> 'a list
val map_t2 : ('a -> 'b) -> 'a * 'a -> 'b * 'b
val map_t3 : ('a -> 'b) -> 'a * 'a * 'a -> 'b * 'b * 'b
val map_index : ('a -> int -> 'b) -> 'a list -> 'b list
val filter_index : ('a -> int -> bool) -> 'a list -> 'a list
val iter_index : ('a -> int -> 'b) -> 'a list -> unit
val map_fst : ('a -> 'b) -> 'a * 'c -> 'b * 'c
val map_snd : ('a -> 'b) -> 'c * 'a -> 'c * 'b
val map_withenv : ('a -> 'b -> 'c * 'a) -> 'a -> 'b list -> 'c list * 'a
val exists_withenv : ('a -> 'b -> bool * 'a) -> 'a -> 'b list -> bool * 'a
val map_t2_withenv : ('a -> 'b -> 'c * 'a) -> 'a -> 'b * 'b -> ('c * 'c) * 'a
val for_all_withenv : ('a -> 'b -> bool * 'a) -> 'a -> 'b list -> bool * 'a
val for_all2_withenv :
  ('a -> 'b -> 'c -> bool * 'a) -> 'a -> 'b list -> 'c list -> bool * 'a
val take : int -> 'a list -> 'a list
val last_n : int -> 'a list -> 'a list
val last : 'a list -> 'a
val take_until : ('a -> bool) -> 'a list -> 'a list
val drop_while : ('a -> bool) -> 'a list -> 'a list
val splitAtIndice : int -> 'a list -> 'a list * 'a list
val skipfirst : 'a -> 'a list -> 'a list
val removelast : 'a list -> 'a list
val assoc_by : ('a -> 'b -> bool) -> 'a -> ('b * 'c) list -> 'c
val rassoc : 'a -> ('b * 'a) list -> 'b
val all_assoc : 'a -> ('a * 'b) list -> 'b list
val all_assoc_by : ('a -> 'b -> bool) -> 'a -> ('b * 'c) list -> 'c list
val prepare_want_all_assoc : ('a * 'b) list -> ('a * 'b list) list
val prepare_want_all_assoc_by :
  ('a -> 'a -> bool) -> ('a * 'a) list -> ('a * 'a list) list
val repeat : 'a -> int -> 'a list
val repeat_eff : 'a -> int -> 'a list
val repeat_f_eff : (unit -> 'a) -> int -> 'a list
val inits : 'a list -> 'a list list
val tails : 'a list -> 'a list list
val apply : ('a -> 'b) -> 'a -> 'b
val map3 : ('a -> 'b -> 'c -> 'd) -> 'a list -> 'b list -> 'c list -> 'd list
val break : 'a -> 'a list -> 'a list * 'a list
val rev_nth : 'a -> 'a list -> int
val getset_nth : 'a list -> int -> ('a -> 'a) -> 'a list
val set_nth : 'a list -> int -> 'a -> 'a list
val adjustModDown : int -> int -> int
val adjustModUp : int -> int -> int
val hashtbl_set : ('a, 'b) Hashtbl.t -> 'a -> 'b -> unit
val hashtbl_find : ('a -> 'b -> bool) -> ('a, 'b) Hashtbl.t -> 'a
val hashtbl_filter : ('a -> 'b -> 'b) -> ('a, 'b) Hashtbl.t -> unit
val hashtbl_values : ('a, 'b) Hashtbl.t -> 'b list
val array_shift : 'a array -> 'a array
val array_last_n : int -> 'a array -> 'a array
val lvector_product : 'a list list -> 'a list list
val vector_product2 : 'a list -> 'a list -> ('a * 'a) list
val transpose : 'a list list -> 'a list list
val bool2int : bool -> int
val range : int -> int -> int list
val filter_some : 'a option list -> 'a list
val difference : 'a list -> 'a list -> 'a list
val triangularize : 'a list -> ('a * 'a list) list
val diagonalize : 'a list -> ('a * 'a list) list
val graph_sort : (int * int list) list -> (int * int list) list
val int_sort : int list -> int list
val str_begins_with : string -> string -> bool
val str_ends_with : string -> string -> bool
val chop : string -> string
val explode_string : string -> char list
