open Types
open List

open Common

let default_env = { 
  u = 0 ; b = false ; em = false ; i = false ;
  s = false ; tt = false ; size = None ; color = None ;
}

let convert_simple_tag env = function
  | B  -> { env with b  = true }
  | I  -> { env with i  = true }
  | TT -> { env with tt = true }

let increment_underline = function
  | 3 -> 3
  | i -> i + 1

let tag2cost = function
  | Sim TT | EM | PL -> 2
  | _ -> 1

let add_tag_to_env env = function
  | Sim t -> convert_simple_tag env t
  | Col color -> { env with color = Some color }
  | Siz size -> { env with size = Some size }
  | EM -> if env.s then env else { env with em = not env.em }
  | S -> { env with s = true ; em = false }
  | U -> { env with u = increment_underline env.u }
  | PL -> { env with u = 0 ; s = false ; em = false ; i = false ; b = false ; tt = false }

let tags2env tags = fold_left add_tag_to_env default_env (rev tags)

let compact_meaning_doc doc =
  let rec aux accu = function
  | [] -> rev accu
  | (env,is_sp1,s1) :: (env',is_sp2,s2) :: l when env = env' ->
      let s = if s1 = " " && s2 = " " && not env.tt then " " else s1 ^ s2 in
      aux accu ((env, is_sp1 && is_sp2, s) :: l)
  | e :: l -> aux (e :: accu) l
  in aux [] doc

let agglomerate_spaces l =
  let uncolorify_tt_spaces (env,is_sp,s) =
    (if is_sp && env.u = 0 then { env with color = None } else env), is_sp, s
  in
  let rec agglo accu = function
    | [] -> rev accu
    | [e] -> rev (e :: accu)
    | (env1,is_sp1,s1) :: (env2,is_sp2,s2) :: l ->
	let (env, env') = 
	  if is_sp2 then env2, env1 else env1, env2 in
      if (is_sp1 || is_sp2) && env.tt = env'.tt && env.u = env'.u && env.size = env'.size && (env.u = 0 || env.color = env'.color) then
	agglo accu ((env', is_sp1 && is_sp2, s1 ^ s2) :: l)
      else
	agglo ((env1, is_sp1, s1) :: accu) ((env2,is_sp2,s2) :: l)
  in
  let l' = compact_meaning_doc (agglo [] l) in
  map (fun (e,_,s) -> (e,s)) (map uncolorify_tt_spaces l')

let rec (convert : tree -> meaning_doc) = fun tree ->
  let doc = map_flatten (convert_elem default_env) tree in
  compact_meaning_doc doc

and convert_elem env = function
  | Space s -> 
      let env' = { env with s = false ; em = false ; i = false ; b = false ; 
		   color = if env.u = 0 then Some White else env.color } in
      if env.tt then [ env', true, s] else [ env', true, " " ] 
  | Data s -> [env, false, s]
  | Tag(tag, tree) ->
      let env' = add_tag_to_env env tag in
      map_flatten (convert_elem env') tree

let (is_equivalent : tree -> tree -> bool) = fun tree1 tree2 ->
  convert tree1 = convert tree2

let rec (tree_size : tree -> int) = fun tree ->
  let rec ff = function
    | Space s -> String.length s
    | Data s -> String.length s
    | Tag(tag, tree) -> 2 + tag2cost tag + tree_size tree + 3 + tag2cost tag
  in sum (map ff tree)
