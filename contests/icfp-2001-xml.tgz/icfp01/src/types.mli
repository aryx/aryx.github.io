type size  = int
type color = Red | Green | Blue | Cyan | Magenta | Yellow | Black | White

type env = { 
    b : bool ; 
    i : bool ;
    tt : bool ;
    s : bool ;
    em : bool ; 
    u : int ;
    size : size option ;
    color : color option ;
}

type meaning_doc = (env * bool * string) list
type meaning_doc_simple = (env * string) list

type simple_tag = B | I | TT

type tag =
  | Sim of simple_tag
  | Col of color
  | Siz of size
  | EM 
  | S
  | PL
  | U

type tree = tree_elem list

and tree_elem = 
  | Tag of tag * tree
  | Data of string
  | Space of string

    
type for_reparse = 
  | Open of tag
  | End of tag
  | Str of string
