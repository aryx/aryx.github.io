val u2s : int -> string
val color2s : Types.color -> string
val msize2s : int option -> string
val mcolor2s : Types.color option -> string
val tag2s : Types.tag -> string
val env2s : Types.env -> string
val meaning_doc2s : (Types.env * 'a * string) list -> string
val meaning_doc_simple2s : (Types.env * string) list -> string
val for_reparse2s : Types.for_reparse -> string
val tree_elem2s : Types.tree_elem -> string
val tree2s : Types.tree -> string
