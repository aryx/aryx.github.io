%{
open Types
  %}

  %token <string> OPEN END
  %token <string> SPACE STR

  %token EOF

  %start main
  %type <Types.tree> main
  %%

main:
  document_list EOF		                { $1 }

  document_list:
| /* empty */            { [] } 
| document document_list {$1::$2}

    document:
| STR        { Data $1 }
| SPACE      { Space $1  }
| OPEN document_list END 
    { if $1 = $3 then
      Tag ((
	   match $1 with
	   |	"B" -> Sim B
	   |	"I" -> Sim I
	   |	"TT"-> Sim TT
	   |	"EM" -> EM
	   |	"S"  -> S
	   |	"PL" -> PL
	   |	"U"  -> U
	   |	"0" | "1"| "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9"  -> Siz (int_of_string $1)
	   |	"r"  -> Col Red
	   |	"g"  -> Col Green
	   |	"b"  -> Col Blue
	   |	"c"  -> Col Cyan
	   |	"m"  -> Col Magenta
	   |	"y"  -> Col Yellow
	   |	"k"  -> Col Black
	   |	"w"  -> Col White
	   | tag  -> failwith ("bad tag " ^ tag)
	  ), $2)
	else failwith ("not same tag " ^ $1 ^ " and " ^ $3)
(* TODO make check  $2 = $3 ? *)
    }
