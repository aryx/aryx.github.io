#!/usr/bin/ruby


$chars = ["A".."Z","a".."z","0".."9"].collect { |r| r.to_a }.join + %q(!@$%^&*/# ) + "\t\n\r"

$tags = [ "B", "EM", "I", "PL", "S", "TT", "U", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "r", "g", "b", "c", "m", "y", "k", "w", ]


def document(doc, rec)
#    ch = (1..rand(15)).collect{ $chars[rand($chars.size)] }.pack("C*")
  ch = "X"

    if doc.length > 2 || rec > 5
        return ch
    end

    k = rand
    if k < 0.1
        return doc + document(doc, rec+1)
    elsif k < 0.8 && (doc.length > 0 || rand < 0.2)
        t = $tags[rand($tags.size)]
        return "<#{t}>#{document(doc, rec+1)}</#{t}>"
    else
	return document(ch, rec+1) + document(doc, rec+1)
    end
end

size = 0
while size < 4 do
  s = document("", 0)
  print s
  size += s.length
end

print s
