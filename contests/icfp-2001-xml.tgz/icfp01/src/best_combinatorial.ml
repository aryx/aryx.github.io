open Printf
open Print
open Types
open Parser
open Common
open List
open Tree2meaning
open Simpledoc2tree

open Common

(* tag list: <B><I>  => [ I ; B ] *)
                (* current wanted  next_next  currently opened tag *)
type choice_maker = env -> env -> env -> (tag list * tag list) -> (tag list * tag list) list

let remove_permut_counter = ref 0
let cut = ref None

let for_reparse2cost = function
  | Open tag -> 2 + tag2cost tag + 3 + tag2cost tag
  | End tag -> 0
  | _ -> 0

let reparse_end2cost ends = 
  sum (map (fun t -> 3 + tag2cost t) ends)

let two_tags2openclose in_ out =
  let rec remove_common = function
    | e1::l1, e2::l2 when e1 = e2 -> remove_common (l1, l2)
    | l1, l2 -> l1, l2
  in
  let in_', out' = remove_common(rev in_, rev out) in
  map (fun s -> Open s) (rev out') @ map (fun s -> End s) in_'

let rec recreate_local (choice_maker : choice_maker) cur_env (to_close_tags, open_tags) for_reparse cost (env,s) next_env =
  let l = choice_maker cur_env env next_env (to_close_tags, open_tags) in
  let possibilities = uniq l in
  map (fun (new_to_close_tags, new_tags) ->
    let beg = two_tags2openclose open_tags new_tags in
    let cost' = cost + sum (map for_reparse2cost beg) in (* warning: it doesn't into account the number of opened tags, aka the number of ending tags that are needed to have a well formed XML tree *)
    cost', (env, new_to_close_tags, new_tags), Str s :: beg @ for_reparse
  ) possibilities

let rec recreate (choice_maker : choice_maker) bests = function
  | [] -> 
      map (fun (cost, (_, _, open_tags), for_reparse) -> 
	two_tags2openclose open_tags [] @ for_reparse
      ) bests
  | e :: l ->
      let bests' = 
	map_flatten (fun (cost, (cur_env, to_close_tags, open_tags), for_reparse) ->
	  recreate_local choice_maker cur_env (to_close_tags, open_tags) for_reparse cost e (if l = [] then default_env else fst (hd l))
	) bests in

      let bests_pre = 
	sort (fun (chksm1,_) (chksm2,_) -> chksm1 - chksm2)
	(map (fun (_, (_, _, open_tags), _ as e) -> Hashtbl.hash open_tags, e) bests') in
      let bests_pre2 = sorted_keep_best
	  (fun (chksm1, (cost1, (_, _, open_tags1), _) as e1) (chksm2, (cost2, (_, _, open_tags2), _) as e2) ->
	    if chksm1 = chksm2 && open_tags1 = open_tags2 then
	      Some (if cost1 < cost2 then e1 else e2)
	    else
	      None
	  ) bests_pre in

      (*printf "before %d after %d\n" (length bests') (length bests_pre2) ; flush stdout;*)

      let bests2 = map snd bests_pre2 in

      let bests4 = 
	if !cut = None then sort (fun (c1,_,_) (c2,_,_) -> c1 - c2) bests2
	else (* sorted + take optimised*)
	  if true then
	    take (some !cut) (sort (fun (c1,_,_) (c2,_,_) -> c1 - c2) bests2) 
	  else 
	    snd
	      (fold_left (fun (len, sorted) (c,a,b)  -> 
		let sorted' = sorted_insert (fun (c1,_,_) (c2,_,_) -> c2 - c1) (c,a,b) sorted in
		if len = (some !cut) then (len, tl sorted')
		else (len+1, sorted')
			 ) 
		 (0, []) bests2 
	      ) 
      in

      if Flags.display_mean_open_tags then 
	begin
	  let l = map (fun (_,(_,_,tags),_) -> length tags) bests2 in
	  printf "mean open_tags: %3.1f\n" (float (sum l) /. float (length l)) ; flush stdout
	end ;
      if Flags.display_nb_choices_removed then
	begin
	  printf "choices found %d -> %d\n" (length bests2) (length bests4) ; flush stdout
	end ;
      if Flags.display_choices then
	begin
	  iter (fun (cost,(_,_,tags),for_reparse) ->
	    printf "% 8d %s %s\n" cost (String.concat "" (map for_reparse2s (rev for_reparse))) (String.concat "" (map tag2s tags))
	  ) (sort (fun (c1,_,_) (c2,_,_) -> c1 - c2) bests2);
	  printf "--------------------------------------------------------------------------------\n";
	end ;

      recreate choice_maker bests4 l

let (para_recreate_tree : choice_maker -> meaning_doc_simple -> tree) = fun choice_maker doc ->
  remove_permut_counter := 0 ;
  let possibilities = recreate (choice_maker : choice_maker) [0, (default_env, [], []), []] doc in
(*  iter (fun for_reparse -> 
    let tree = reparse for_reparse in
    let doc' = agglomerate_spaces (convert tree) in
    (*printf "%s\n" (tree2s tree) ;*)
    if not (doc = doc') then (
      printf "%s\n" (meaning_doc_simple2s doc) ;
      printf "%s\n" (meaning_doc_simple2s doc') ; flush stdout ;
      failwith "bad tree"
    ) 
  ) possibilities ; *)
  reparse (hd possibilities)


let is_pl_needed old_env new_env = 
  not new_env.b  && old_env.b  ||
  not new_env.i  && old_env.i  ||
  not new_env.tt && old_env.tt ||
  not new_env.s  && old_env.s  ||
  new_env.u < old_env.u

let is_pl_useful useful_tags_length old_env new_env = 
  useful_tags_length > 1 && xor new_env.em old_env.em

let diff_env old_env new_env = 
  let lsize = if old_env.size  <> new_env.size  then convert_size  new_env.size  else [] in
  let lcolor = if old_env.color <> new_env.color then convert_color new_env.color else [] in

  let lsimple = 
	convert_underline (new_env.u - old_env.u) @
	map snd (filter fst [
		 new_env.s && not old_env.s, S ;
		 not new_env.s && xor new_env.em old_env.em, EM ;
		 new_env.b && not old_env.b, Sim B ;
		 new_env.i && not old_env.i, Sim I ;
		 new_env.tt && not old_env.tt, Sim TT ;
	       ]) in
  lsize @ lcolor @ lsimple

let rec is_pl_before_stags pl_found = function
  | [] -> true (* no PL => ok *)
  | Siz _ :: l -> is_pl_before_stags pl_found l 
  | Col _ :: l -> is_pl_before_stags pl_found l
  | PL :: l -> is_pl_before_stags true l
  | _ :: l -> not pl_found && is_pl_before_stags false l

let intersect_env_openonly enva envb =
  sum (map bool2int [ enva.s && envb.s ; enva.b && envb.b ; enva.i && envb.i ; enva.tt && envb.tt ])

let difference_env_openonly envb enva =
  sum (map bool2int [ envb.s && not enva.s ; envb.b && not enva.b ; envb.i && not enva.i ; envb.tt && not enva.tt ])

let includes_env_openonly enva envb =
  (enva.s  => envb.s) &&
  (enva.b  => envb.b) &&
  (enva.i  => envb.i) &&
  (enva.tt => envb.tt) &&
  enva.em = envb.em &&
  enva.u > envb.u &&
  enva.size = envb.size &&
  enva.color = envb.color

let is_pl_not_useful prev_env next_env new_env = 
  let m = difference_env_openonly new_env next_env in
  let k = intersect_env_openonly new_env next_env in
  includes_env_openonly prev_env next_env && m < 2 * k + 1

let is_possible_without_close old_env new_env =
      (new_env.size  = None) => (old_env.size  = None) &&
      (new_env.color = None) => (old_env.color = None)

let (combinatorial_choice_maker : choice_maker) = fun prev_env new_env next_env (to_close_tags,open_tags_) ->
  let possibilities_from open_tags prev_env new_env =
    let useful_tags_length = 
      let useful_tags = take_until (fun x -> x = PL) open_tags in
      let useful_tags' = drop_while (function Col _ | Siz _ -> true | _ -> false) (rev useful_tags) in
      length useful_tags'
    in
    let is_possible_and_useful = is_possible_without_close prev_env new_env &&
      (useful_tags_length <> 1 ||
      (* useful_tags_length = 1 *)
      not ((* closing EM, B, I, TT *)
        prev_env.em && not new_env.em && not new_env.s ||
        prev_env.b  && not new_env.b  ||
        prev_env.i  && not new_env.i  ||
        prev_env.tt && not new_env.tt
      ))

    in
    if is_possible_and_useful then
      let pl_needed = is_pl_needed prev_env new_env in
      if pl_needed && useful_tags_length = 1
      then [] (* useless pl, a simple close will do the job *)
      else 
	let pl_useful = is_pl_useful useful_tags_length prev_env new_env in
	
	let l1, prev_env' = 
	  if pl_needed || pl_useful then 
	    let env' = { prev_env with u = 0 ; s = false ; em = false ; i = false ; b = false ; tt = false } in
	    PL :: diff_env env' new_env, env'
	  else 
	    diff_env prev_env new_env, prev_env in

	let permut l =
	  match !cut with
	  | None -> map (fun x -> [], x) (permutations l)
	  | Some n ->  (* if fact (length l) < !n then permutations  *)
	      take n 
		(
	          (* force to close some stuff *)
		 let will_be_force_to_close = 
		   if !Flags.remove_permut then
		     if is_pl_not_useful prev_env next_env new_env then
		       difference (env2tags_openonly new_env next_env) (env2tags next_env)
		     else if not (is_possible_without_close new_env next_env) then
		       difference (env2tags_colorsize new_env next_env) (env2tags next_env)
		     else []
		   else []
		 in 
	         if will_be_force_to_close = [] then
		   map (fun x -> [], x) (permutations l)
		 else
		   let same = difference l will_be_force_to_close in
		   let useless_to_permut = difference l same in

		   (*(printf "remove_permut %s in %s (%s)\n" (String.concat " " (map tag2s useless_to_permut)) (String.concat " " (map tag2s same)) (env2s prev_env); flush stdout);*)
		   incr remove_permut_counter ;
		   if same = [] then 
		     [ useless_to_permut, useless_to_permut ]
		   else
		     map (fun x -> useless_to_permut, useless_to_permut @ x) (permutations same)
                )
	in
	let ls =
	  if l1 = [] then [[],[]] 
	  else
	    let perms = 
	      if pl_useful && (not pl_needed) then
		permut l1 @ permut (diff_env prev_env new_env)
	      else if pl_needed then 
		permut l1
	      else permut (diff_env prev_env new_env)
	    in 
	    filter (fun (_,open_tags) -> is_pl_before_stags false open_tags) perms in 
	ls
	  
    else []
   
  in
  if prev_env = new_env then
    [ [], open_tags_ ]
  else 
    let open_tags_' = drop (length to_close_tags) open_tags_ in

    map_flatten (fun tags -> 
      let ps = possibilities_from tags (tags2env tags) new_env in
      map (fun (new_to_close_tags, open_tags) -> new_to_close_tags, open_tags @ tags) ps
    ) (tails open_tags_')


let recreate_tree doc = para_recreate_tree combinatorial_choice_maker doc
