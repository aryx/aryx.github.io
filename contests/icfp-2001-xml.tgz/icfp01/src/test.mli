exception Timeout
val randbool : unit -> bool
val random_env : unit -> Types.env
val random_meaning : int -> (Types.env * string) list
val random_tree : int -> Types.tree
val p : string -> unit
