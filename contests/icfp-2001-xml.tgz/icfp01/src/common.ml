open Stack
open List

exception Found
exception GraphSort_circular_deps of int * int

let bpos = "",-1,-1

let norm (a,b) = if a = -1 then b else a
let unipos (s,a,b) (s2,c,d) = 
  if s <> s2 then bpos else s, min (norm(a,c)) (norm(c,a)), max (norm(b,d)) (norm(d,b))
let uniposl l = match l with
  | [] -> bpos
  | e::l -> fold_left unipos e l

(**********************************************************************************)

let (=>) a b = not a || b
let xor a b = not (a = b)
let id x = x
let double a = a,a
let sum l = fold_left (+) 0 l
let swap (x,y) = (y,x)
let uncons l = hd l, tl l
let safe_tl l = try tl l with _ -> []

let rec drop n l =
  match n, l with
  | 0, l -> l
  | n, [] -> []
  | n, _ :: l -> drop (n-1) l

let o f g x = f (g x)
let curry f x y = f (x,y)
let uncurry f (x, y) = f x y

let is_int n = ceil n = n

let fst3 (a,_,_) = a
let snd3 (_,a,_) = a
let thr3 (_,_,a) = a

let has_env var = 
  try 
    let _ = Sys.getenv var in true
  with Not_found -> false

let some = function Some e -> e | None -> failwith "some"

let some_or = function
  | None -> id
  | Some e -> fun _ -> e

let merge_some merge a b = 
  match a,b with
  | None, None -> None
  | _, None -> a
  | None, _ -> b
  | Some(a), Some(b) -> Some(merge a b)

let rec uniq = function
  | [] -> []
  | e::l -> if mem e l then uniq l else e :: uniq l

let rec uniq_ eq = function
  | [] -> []
  | e::l -> 
      try 
	let _ = find (eq e) l in
	uniq_ eq l
      with Not_found -> e :: uniq_ eq l

let rec non_uniq = function
  | [] -> []
  | e::l -> if mem e l then e :: non_uniq l else non_uniq l

let rec find_some p = function
  | [] -> raise Not_found
  | x :: l -> 
      match p x with
      |	Some v -> v
      |	None -> find_some p l

let rec fpartition p l =
  let rec part yes no = function
  | [] -> (rev yes, rev no)
  | x :: l -> 
      (match p x with
      |	None -> part yes (x :: no) l
      |	Some v -> part (v :: yes) no l) in
  part [] [] l

let rec keep_best f = 
  let rec partition e = function
    | [] -> e, []
    | e' :: l ->
	match f(e,e') with
	| None -> let (e'', l') = partition e l in e'', e' :: l'
	| Some e'' -> partition e'' l
  in function
  | [] -> []
  | e::l -> 
      let (e', l') = partition e l in
      e' :: keep_best f l'

let rec sorted_keep_best f = function
  | [] -> []
  | [a] -> [a]
  | a :: b :: l -> 
      match f a b with
      |	None -> a :: sorted_keep_best f (b :: l)
      |	Some e -> sorted_keep_best f (e :: l)

let rec sorted_insert f e = function
  | [] -> [e]
  | x::xs as l -> if f e x < 0 then e::l else x::sorted_insert f e xs

let rec map f l = 
  let rec aux acc = function
    | [] -> rev acc 
    | x::xs -> aux (f x::acc) xs in
  aux [] l


let rec fold_right1 f = function
  | [] -> failwith "fold_right1"
  | [e] -> e
  | e::l -> f e (fold_right1 f l)

let rec fold_left1 f = function
  | [] -> failwith "fold_left1"
  | e::l -> fold_left f e l

let rec (insertin: 'a -> 'a list -> 'a list list) = fun x -> function
  | []    -> [[x]]
  | y::ys -> (x::y::ys)  :: (List.map (fun xs -> y::xs) (insertin x ys))

let rec map_flatten f l =
  let rec aux accu = function    
    | [] -> accu
    | e :: l -> aux (rev (f e) @ accu) l
  in rev (aux [] l)

let rec (permutations: 'a list -> 'a list list) = function
  | [] -> []
  | [x] -> [[x]]
  | x::xs -> map_flatten (insertin x) (permutations xs)

let maxl l = fold_right1 max l
  
let rec stack2list s =
  let l = ref [] in
  Stack.iter (fun e -> l := e :: !l) s ;
  !l

let rec fix_point f p =
  let p' = f p in
  if p = p' then p else fix_point f p'

let rec fix_point_ nb f p =
  let p' = f p in
  if p = p' then p, nb else fix_point_ (nb+1) f p'

(*
let rec lfix_point f e =
  let e' = f(e) in
  if e = e' then e :: lfix_point f e' else [e]
*)


let do_withenv doit f env l =
  let r_env = ref env in
  let l' = doit (fun e -> 
    let e', env' = f !r_env e in
    r_env := env' ; e'
  ) l in
  l', !r_env

let do2_withenv doit f env l1 l2 =
  let r_env = ref env in
  let l' = doit (fun e1 e2 -> 
    let e', env' = f !r_env e1 e2 in
    r_env := env' ; e'
  ) l1 l2 in
  l', !r_env

let map_withitself f l =
  let rec map_withitself_ done_ = function
    | [] -> done_
    | e :: l -> 
	let e' = f (done_ @ e :: l) e in
	map_withitself_ (done_ @ [ e' ]) l
  in map_withitself_ [] l

let map_t2 f (x,y) = f x, f y
let map_t3 f (x,y,z) = f x, f y, f z

let map_index f l =
  let rec map_ n = function
    | [] -> []
    | e::l -> f e n :: map_ (n+1) l
  in map_ 0 l

let filter_index f l =
  let rec filter_ n = function
    | [] -> []
    | e::l -> 
	let l' = filter_ (n+1) l in
	if f e n then e :: l' else l'
  in filter_ 0 l

let iter_index f l =
  let rec iter_ n = function
    | [] -> ()
    | e::l -> f e n ; iter_ (n+1) l
  in iter_ 0 l

let map_fst f (x, y) = f x, y
let map_snd f (x, y) = x, f y

let map_withenv      f env e = do_withenv map f env e
let exists_withenv   f env e = do_withenv exists f env e
let map_t2_withenv   f env e = do_withenv map_t2 f env e
let for_all_withenv  f env e = do_withenv for_all f env e

let for_all2_withenv f env l1 l2 = do2_withenv for_all2 f env l1 l2

let rec take n l =
  if n = 0 then []
  else match l with
  | [] -> []
  | e::l -> e :: take (n-1) l
let last_n n l = rev (take n (rev l))
let last l = hd (last_n 1 l)

let rec take_until p = function
  | [] -> []
  | x::xs -> if p x then [] else x::(take_until p xs)

let rec drop_while p = function
  | [] -> []
  | x::xs -> if p x then drop_while p xs else x::xs	

let splitAtIndice n l =
  let rec ff accu n l =
    match n, l with
    | 0, _ 
    | _, [] -> rev accu, l
    | _, e::l -> ff (e :: accu) (n-1) l
  in ff [] n l

let rec skipfirst e = function
  | [] -> []
  | e'::l when e = e' -> skipfirst e l
  | l -> l

let rec removelast = function
  | [] -> failwith "removelast"
  | [_] -> []
  | e::l -> e :: removelast l

let assoc_by is_same e l = 
  find_some (fun (a,b) -> if is_same e a then Some b else None) l

let rec rassoc e = function
  | [] -> raise Not_found
  | (k,v) :: l -> if e = v then k else rassoc e l

let rec all_assoc e = function
  | [] -> []
  | (e',v) :: l when e=e' -> v :: all_assoc e l
  | _ :: l -> all_assoc e l

let rec all_assoc_by is_same e = function
  | [] -> []
  | (e',v) :: l when is_same e e' -> v :: all_assoc_by is_same e l
  | _ :: l -> all_assoc_by is_same e l

let prepare_want_all_assoc l =
  map (fun n -> n, uniq (all_assoc n l)) (uniq (map fst l))

let prepare_want_all_assoc_by is_same l =
  map (fun n -> n, uniq_ is_same (all_assoc_by is_same n l)) (uniq_ is_same (map fst l))

let rec repeat e = function
  | 0 -> []
  | n when n < 0 -> failwith "repeat"
  | n -> e :: repeat e (n-1)

let rec repeat_eff e n = 
    let rec aux acc = function
      | 0 -> acc
      | n when n < 0 -> failwith "repeat"
      | n -> aux (e::acc) (n-1) in
    aux [] n

let rec repeat_f_eff f n =
  let rec aux acc = function
    | 0 -> acc
    | n when n < 0 -> failwith "repeat"
    | n -> aux (f ()::acc) (n-1) in
    aux [] n

let rec inits = function
  | [] -> [[]]
  | e::l -> [] :: map (fun l -> e::l) (inits l)
let rec tails = function
  | [] -> [[]]
  | (_::xs) as xxs -> xxs :: tails xs

let apply f x = f x;;


let rec map3 f l1 l2 l3 =
  match (l1, l2, l3) with
    ([], [], []) -> []
  | (a1::l1, a2::l2, a3::l3) -> let r = f a1 a2 a3 in r :: map3 f l1 l2 l3
  | (_, _, _) -> invalid_arg "map3"


let break v l =
  let rec b l1 = function
  | [] -> raise Not_found
  | e::l2 when e=v -> (l1, l2)
  | e::l2 -> b (l1 @ [e]) l2
  in b [] l

let rev_nth e l =
  let rec rev_nth' i = function
  | [] -> raise Not_found
  | e'::_ when e'=e -> i
  | _::l -> rev_nth' (i+1) l
  in  rev_nth' 0 l

let rec getset_nth l i f =
  match l, i with
  | e::l', 0 -> f e :: l'
  | [], _ -> failwith "getset_nth"
  | e::l', _ -> e :: getset_nth l' (i - 1) f

let set_nth l i v = getset_nth l i (fun _ -> v)
    
let adjustModDown m n = n - (n mod m)
let adjustModUp m n = adjustModDown m (n + m - 1)


let hashtbl_set h k v =
  Hashtbl.remove h k;
  Hashtbl.add h k v

let hashtbl_find f h =
  let r = ref None in
  Hashtbl.iter (fun v c -> if f v c then r := Some v) h ;
  match !r with
  | Some v -> v
  | None -> raise Not_found

let hashtbl_filter f h =
  Hashtbl.iter (fun v c -> hashtbl_set h v (f v c)) h

let hashtbl_values h =
  let l = ref [] in
  Hashtbl.iter (fun _ v -> l := v :: !l) h ;
  !l

let array_shift a = Array.sub a 1 (Array.length a - 1)
let array_last_n n a = 
  let len = Array.length a in
  Array.sub a (len - n) n

let rec lvector_product = 
  let rec vector_product a b = match a with
  | [] -> []
  | e::l -> map (fun e' -> e :: e') b :: vector_product l b
  in function
  | [] -> []
  | [e] -> map (fun e -> [e]) e
  | e::l -> flatten (vector_product e (lvector_product l))

let vector_product2 a b =
  map (function
  | [a;b] -> a,b
  | _ -> failwith "vector_product2"
  ) (lvector_product [ a ; b ])

let rec transpose = function
  | [] :: _ -> []
  | ll -> 
      let l, ll' = split (map (function e::l -> e,l | _ -> raise Not_found) ll) in
      l :: transpose ll'

let bool2int b = if b then 1 else 0

let rec range min max =
  if min >= max then [] else min :: range (min + 1) max

let rec filter_some = function
  | [] -> []
  | Some e :: l -> e :: filter_some l
  | None :: l -> filter_some l

let rec difference l = function
  | [] -> l
  | e::l' -> difference (filter ((<>) e) l) l'

let rec triangularize = function
  | [] -> []
  | e::l -> (e,l) :: triangularize l

let diagonalize l =
  map_index (fun a i ->
    a, filter_index (fun _ j -> i <> j) l
  ) l

let graph_sort l =
  let cmp (a, deps_a) (b, deps_b) =
    if not (mem a deps_b) then 1
    else if not (mem b deps_a) then -1 
    else raise (GraphSort_circular_deps(a,b))
  in

  (* ensure there is no circular_deps, sorting doesn't raise every occurence
     since the ordering relation is partial *)
  iter (fun (a,l) -> iter (fun b -> ignore (cmp a b)) l) (triangularize l) ;

  sort cmp l

let int_sort l = sort (fun a b -> a - b) l

let str_begins_with s prefix =
  String.sub s 0 (min (String.length s) (String.length prefix)) = prefix

let str_ends_with s suffix =
  let len = min (String.length s) (String.length suffix) in
  String.sub s (String.length s - len) len = suffix

let chop s = String.sub s 0 (String.length s - 1)
  
let rec explode_string = function
   "" -> []
 | s -> (String.get s 0) :: explode_string (String.sub s 1 (String.length s - 1))
