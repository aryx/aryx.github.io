open List
open Parser
open Types
open Common
open Tree2meaning
open Print
open Printf

;;
Gc.set { (Gc.get()) with Gc.space_overhead = 60 }
;;
Gc.set { (Gc.get()) with Gc.stack_limit = 50 * 1024 * 1024 }

exception Timeout
;;
Random.self_init()
let randbool () = if Random.int 2 = 1 then true else false

let random_env () = 
  let e = {default_env with b = randbool (); i = randbool (); tt = randbool (); u = Random.int 4} in
  let x = Random.int 3 in
  let e =
    if x = 0 then e
    else if x = 1 then {e with em=true}
    else {e with s=true} in
  let x = Random.int 11 in
  let e = 
    if x = 10 then {e with size = None}
    else {e with size = Some x} in
  let colors = [Red;Green;Blue;Cyan;Magenta;Yellow;Blue;White] in
  let x = Random.int (List.length colors + 1) in
  let e =
    if x = List.length colors then {e with color = None}
    else {e with color = Some (List.nth colors x)} in
  e

let random_meaning n = 
  map (fun env -> env, "X") (repeat_f_eff random_env n)
let random_tree n =
  Simpledoc2tree.recreate_tree (random_meaning n)
  
let p file =
  if Flags.display then (printf "processing file %s <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n" file ; flush stdout);
  let tree = 
    let lexbuf = Lexing.from_channel (open_in file) in
    (try                                                                                       
      Parser.main Lexer.token lexbuf
    with
    | Failure s ->
	Printf.printf "Syntax error near character %d: %s\n"
          (Lexing.lexeme_start lexbuf) s;
	exit 0
    | _ ->
	Printf.printf "Syntax error near character %d\n"
          (Lexing.lexeme_start lexbuf);
	exit 0
    ) in
  let doc = convert tree in
  let sdoc = agglomerate_spaces doc in

  if Flags.display && length doc < 1000 then
    begin
      printf "meaning: %s\n" (meaning_doc2s doc) ;
      printf "meaning: %s\n" (meaning_doc_simple2s sdoc) ; flush stdout
    end ;

  if Flags.use_iterater then
    (Sys.set_signal Sys.sigalrm
       (Sys.Signal_handle (fun _ -> printf "Time is up\n"; raise Timeout));
     ignore(Unix.alarm Flags.timeout);
     
     let initial_size = tree_size tree in

     let best  = ref tree in
     let bestsize = ref initial_size in
     let lastsize = ref 0 in
     let depth = ref Flags.iterater_initial_depth in
     (try
       while true do
	 if Flags.display then (printf "iterating %4d..." !depth; flush stdout) ; 
	 Best_combinatorial.cut := Some (!depth) ;    
	 if Flags.check_both_with_and_without_remove_permut then
	   Flags.remove_permut := true ;
	 let best2 = Best_combinatorial.recreate_tree sdoc in
	 let bestsize2  = tree_size best2 in
	 if Flags.display then (printf "\b\b\b done" ; flush stdout) ;
	 if not (is_equivalent !best best2) then
	   failwith "bad tree"
	 else 
	   if Flags.display then (printf ": %.2f (%8db)\n" (float bestsize2 /. float initial_size) bestsize2; flush stdout) ; 
	   if bestsize2 <= !bestsize then (
	     if Flags.limit_iterater && bestsize2 = !lastsize && !depth >= 32 then 
	       begin
                (* fixpoint found *)

		 if Flags.check_both_with_and_without_remove_permut then
		   begin
		     Flags.remove_permut := false ;
		     let best2' = Best_combinatorial.recreate_tree sdoc in
		     let bestsize2'  = tree_size best2' in
		     if bestsize2' < bestsize2 then
		       begin
			 printf "\nwith    permut %s\n" (tree2s best2) ;
			 printf   "without permut %s\n" (tree2s best2') ; flush stdout;
			 failwith (sprintf "without permut is better %d < %d" bestsize2' bestsize2)
		       end
		     else if bestsize2' = bestsize2 then
		       (if Flags.display then printf "without permut iss same %d = %d\n" bestsize2' bestsize2)
		     else 
		       (if Flags.display then printf "without permut iss worse %d > %d\n" bestsize2' bestsize2)
		   end ;		 

		 raise Timeout
	       end ;
	     (best := best2; bestsize := bestsize2)
	   ) else (
	     printf "\nbefore %s\n" (tree2s !best) ;
	     printf "after  %s\n" (tree2s best2) ; flush stdout;
	     printf "more in depth is worse"
	   );
	   lastsize := bestsize2 ;
	   if !depth > 10000000 then raise Timeout;
	   depth := !depth * 2
       done
     with Timeout -> ());
     if Flags.iterater_initial_depth = !depth then failwith "not enough time for an iteration" ;
     if Flags.display then (printf "best tree size(%d / %d = %.2f): %s\n" !bestsize initial_size (float !bestsize /. float initial_size) (if !bestsize < 100 then tree2s !best else "") ; flush stdout);
     )
  else 
    let tree_simple = Simpledoc2tree.recreate_tree sdoc in
    Best_combinatorial.cut := Flags.good_depth ;
    let tree_good = Best_combinatorial.recreate_tree sdoc in
    Best_combinatorial.cut := Flags.best_depth ;
    let tree_best = 
      if Flags.good_depth = Flags.best_depth then tree_good else
      Best_combinatorial.recreate_tree sdoc in

    let size_tree = tree_size tree in
    let size_tree_best = tree_size tree_best in
    let size_tree_good = tree_size tree_good in
    let size_tree_simple = tree_size tree_simple in

    if Flags.display then
      begin
	printf "input  meaning: %s\n" (meaning_doc2s (convert tree)) ;
	printf "simple meaning: %s\n" (meaning_doc2s (convert tree_simple)) ;
	printf "input  tree: %s\n" (tree2s tree) ;
	printf "best   tree: %s\n" (tree2s tree_best) ;
	printf "good   tree: %s\n" (tree2s tree_good) ;
	printf "simple tree: %s\n" (tree2s tree_simple) ;
	printf "sizes: input %d best %d good %d simple %d\n" size_tree size_tree_best size_tree_good size_tree_simple ;
	if !Flags.remove_permut then printf "remove_permut: %d\n" !Best_combinatorial.remove_permut_counter ;
	flush stdout
      end ;
    
    if not (is_equivalent tree tree_simple) then
      failwith "bad simple tree" ;

    if not (is_equivalent tree tree_best) then
      failwith "bad best tree" ;

    if size_tree_good < size_tree_best then
      failwith "best tree worse than good tree" ;
    
    if size_tree_good > size_tree_best then
      failwith "not good enough" ;
    
    if size_tree_best > size_tree then
      failwith "best tree longer than input tree" ;

    if size_tree_best > size_tree_simple then
      failwith "best tree longer than simple tree"


let _ =
  try
    match (Array.to_list Sys.argv) with
    | [] -> failwith ""
    | [ "./genrandom" ; nb ] -> print_string (tree2s (random_tree (int_of_string nb)))
    | [ s ] -> flush stdout ; p "test"
    | _ :: l -> iter p (filter (fun f -> try let o = Unix.opendir f in Unix.closedir o ; false with _ -> true) l)
  with a -> flush stdout ; raise a
