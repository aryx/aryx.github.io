val remove_permut : bool ref
val check_both_with_and_without_remove_permut : bool
val use_iterater : bool
val limit_iterater : bool
val timeout : int
val iterater_initial_depth : int
val good_depth : int option
val best_depth : int option
val display : bool
val display_mean_open_tags : bool
val display_nb_choices_removed : bool
val display_choices : bool
