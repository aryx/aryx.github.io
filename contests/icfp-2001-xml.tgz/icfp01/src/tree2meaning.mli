val default_env : Types.env
val convert_simple_tag : Types.env -> Types.simple_tag -> Types.env
val increment_underline : int -> int
val tag2cost : Types.tag -> int
val add_tag_to_env : Types.env -> Types.tag -> Types.env
val tags2env : Types.tag list -> Types.env
val compact_meaning_doc :
  (Types.env * bool * string) list -> (Types.env * bool * string) list
val agglomerate_spaces :
  (Types.env * bool * string) list -> (Types.env * string) list
val convert : Types.tree -> Types.meaning_doc
val convert_elem :
  Types.env -> Types.tree_elem -> (Types.env * bool * string) list
val is_equivalent : Types.tree -> Types.tree -> bool
val tree_size : Types.tree -> int
