open Types
open List
open Print

open Common

let convert_size = function
  | None -> []
  | Some s -> [ Siz s ]

let convert_color = function
  | None -> []
  | Some c -> [ Col c ]

let convert_underline u = repeat U u

let env2tags_openonly env next_env =
  let flags = 
    map snd (filter fst [
	     env.s, S ;
(*	     env.em, EM ;*)
	     env.b, Sim B ;
	     env.i, Sim I ;
	     env.tt, Sim TT ;
	   ]) in
  flags @ convert_underline env.u @
  (if next_env.size  = None && env.size  <> None then convert_size env.size else []) @
  (if next_env.color = None && env.color <> None then convert_color env.color else [])

let env2tags_colorsize env next_env =
  (if next_env.size  = None && env.size  <> None then convert_size env.size else []) @
  (if next_env.color = None && env.color <> None then convert_color env.color else [])

let env2tags env =
  let flags = 
    map snd (filter fst [
	     env.s, S ;
	     env.em, EM ;
	     env.b, Sim B ;
	     env.i, Sim I ;
	     env.tt, Sim TT ;
	   ]) in
  flags @ convert_color env.color @ convert_size env.size @ convert_underline env.u

let reparse l =
  let s_doc = String.concat "" (map for_reparse2s (rev l)) in
  Parser.main Lexer.token (Lexing.from_string (s_doc))

let doc2tree_elem (env,s) =
  let tags = env2tags env in
  map (fun t -> End t) (rev tags) @ [ Str s ] @ map (fun t -> Open t) tags

let (recreate_tree : meaning_doc_simple -> tree) = fun doc -> reparse (map_flatten doc2tree_elem (rev doc))
