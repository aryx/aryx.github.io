open List
open Parser
open Types
open Common
open Tree2meaning
open Print
open Printf

;;
Gc.set { (Gc.get()) with Gc.space_overhead = 100 }
;;
Gc.set { (Gc.get()) with Gc.stack_limit = 50 * 1024 * 1024 }

exception Timeout

let _ =
  let tree = 
    let lexbuf = Lexing.from_channel stdin in
    (try                                                                                       
      Parser.main Lexer.token lexbuf
    with
    | Failure s ->
	Printf.printf "Syntax error near character %d: %s\n"
          (Lexing.lexeme_start lexbuf) s;
	exit 0
    | _ ->
	Printf.printf "Syntax error near character %d\n"
          (Lexing.lexeme_start lexbuf);
	exit 0
    ) in
  let best  = ref tree in
  (Sys.set_signal Sys.sigalrm
     (Sys.Signal_handle (fun _ -> raise Timeout)));
   ignore(Unix.alarm (int_of_string (Array.get Sys.argv 1) - 10));

   (try
     let doc = convert tree in
     let sdoc = agglomerate_spaces doc in

     let initial_size = tree_size tree in
   
     let bestsize = ref initial_size in
     let lastsize = ref 0 in
     let depth = ref Flags.iterater_initial_depth in
   
     while true do
       Best_combinatorial.cut := Some (!depth) ;    
       let best2 = Best_combinatorial.recreate_tree sdoc in
       let bestsize2  = tree_size best2 in
       (if bestsize2 <= !bestsize then 
	 if not (is_equivalent !best best2) then
	   () (* failwith "bad tree" *)
	 else
	   (
	    best := best2; bestsize := bestsize2;
	    (if Flags.limit_iterater && bestsize2 = !lastsize && !depth >= 128 then 
	      begin
                (* fixpoint found *)
		Flags.remove_permut := false ;
		depth := Flags.iterater_initial_depth;
	      end
	    else 
	      ()
	    )
	   )
       else ()
       );
       lastsize := bestsize2 ;
       depth := !depth *2;
     done
   with _ -> ()
   );
   
   printf "%s"(tree2s !best);
   flush stdout;

		      
