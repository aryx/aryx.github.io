open Types
open Common
open List

let u2s = function
  | 0 -> ""
  | 1 -> "u"
  | 2 -> "u2"
  | 3 -> "u3"
  | _ -> failwith "u2s"

let color2s = function
  | Red     -> "r"
  | Green   -> "g"
  | Blue    -> "b"
  | Cyan    -> "c"
  | Magenta -> "m"
  | Yellow  -> "y"
  | Black   -> "k"
  | White   -> "w"

let msize2s = function
  | None -> ""
  | Some s -> "=" ^ string_of_int s

let mcolor2s = function
  | None -> ""
  | Some s -> color2s s

let tag2s = function
  | Col c -> color2s c
  | Siz s -> string_of_int s
  | Sim B -> "B"
  | Sim I -> "I"
  | Sim TT -> "TT"
  | EM -> "EM"
  | PL -> "PL"
  | S -> "S"
  | U -> "U"

let env2s env =
  let flags = 
    String.concat "" (map (fun (b, s) -> if b then s else "") [
	    env.b, "B" ;
	    env.em, "EM" ;
	    env.i, "I" ;
	    env.s, "S" ;
	    env.tt, "TT" ;
	  ]) in
  flags ^ u2s env.u ^ msize2s env.size ^ mcolor2s env.color


let meaning_doc2s doc =
  let one (env, _, s) = env2s env ^ "(" ^ s ^ ")" in
  String.concat "" (map one doc)

let meaning_doc_simple2s doc =
  let one (env, s) = env2s env ^ "(" ^ s ^ ")" in
  String.concat "" (map one doc)

let for_reparse2s = function
  | Open tag -> Printf.sprintf "<%s>" (tag2s tag)
  | End  tag -> Printf.sprintf "</%s>" (tag2s tag)
  | Str s -> s

let rec tree_elem2s = function
  | Tag(tag,tree) -> Printf.sprintf "<%s>%s</%s>" (tag2s tag) (tree2s tree) (tag2s tag)
  | Data s -> s
  | Space s -> s

and tree2s tree = 
  String.concat "" (map tree_elem2s tree)
