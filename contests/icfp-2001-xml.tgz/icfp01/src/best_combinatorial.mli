type choice_maker =
  Types.env ->
  Types.env ->
  Types.env ->
  Types.tag list * Types.tag list -> (Types.tag list * Types.tag list) list
val remove_permut_counter : int ref
val cut : int option ref
val for_reparse2cost : Types.for_reparse -> int
val reparse_end2cost : Types.tag list -> int
val two_tags2openclose :
  Types.tag list -> Types.tag list -> Types.for_reparse list
val recreate_local :
  choice_maker ->
  Types.env ->
  Types.tag list * Types.tag list ->
  Types.for_reparse list ->
  int ->
  Types.env * string ->
  Types.env ->
  (int * (Types.env * Types.tag list * Types.tag list) *
   Types.for_reparse list)
  list
val recreate :
  choice_maker ->
  (int * (Types.env * Types.tag list * Types.tag list) *
   Types.for_reparse list)
  list -> (Types.env * string) list -> Types.for_reparse list list
val para_recreate_tree :
  choice_maker -> Types.meaning_doc_simple -> Types.tree
val is_pl_needed : Types.env -> Types.env -> bool
val is_pl_useful : int -> Types.env -> Types.env -> bool
val diff_env : Types.env -> Types.env -> Types.tag list
val is_pl_before_stags : bool -> Types.tag list -> bool
val intersect_env_openonly : Types.env -> Types.env -> int
val difference_env_openonly : Types.env -> Types.env -> int
val includes_env_openonly : Types.env -> Types.env -> bool
val is_pl_not_useful : Types.env -> Types.env -> Types.env -> bool
val is_possible_without_close : Types.env -> Types.env -> bool
val combinatorial_choice_maker : choice_maker
val recreate_tree : Types.meaning_doc_simple -> Types.tree
