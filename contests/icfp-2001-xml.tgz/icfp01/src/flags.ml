let remove_permut = ref true
let check_both_with_and_without_remove_permut = true

let use_iterater = true
let limit_iterater = true
let timeout = 120

let iterater_initial_depth = 4

let good_depth = Some 16
let best_depth = good_depth

let display = true
let display_mean_open_tags = false
let display_nb_choices_removed = false
let display_choices = false
