{
open Lexing
open Parser
}
let whitespace = [' ' '\t' '\n' '\r' ]+ (* SPC = 0x20 CR = 0x0D LF = 0x0A TAB = 0x09 *)

rule token = parse
| "<"              { OPEN (intags lexbuf) }
| "</"             { END  (intags lexbuf) }

| whitespace { SPACE (lexeme lexbuf) }
| [^'<''>' ' ' '\t' '\n' '\r' ]+       { STR (lexeme lexbuf) } (* 0x21 to 0x7E *)
| eof              { EOF }

and intags = parse
| [^'>']+ '>'           { let s = lexeme lexbuf in (String.sub s 0 (String.length s - 1))}

(* | _              { raise (Error "illegal character") } *)

