val convert_size : Types.size option -> Types.tag list
val convert_color : Types.color option -> Types.tag list
val convert_underline : int -> Types.tag list
val env2tags_openonly : Types.env -> Types.env -> Types.tag list
val env2tags_colorsize : Types.env -> Types.env -> Types.tag list
val env2tags : Types.env -> Types.tag list
val reparse : Types.for_reparse list -> Types.tree
val doc2tree_elem : Types.env * string -> Types.for_reparse list
val recreate_tree : Types.meaning_doc_simple -> Types.tree
