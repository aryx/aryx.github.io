open Common

open Lib

##let _ = Gc.set { (Gc.get()) with Gc.stack_limit = 50 * 1024 * 1024 }

let do_something  arg1 arg2 = ()
let do_something2 arg1 arg2 = ()
  
let robber whichone = 
  Bot.robber (Reg (("Aryx-Robber-" ^ whichone), Robber))
    (match whichone with
    | "dumb" -> Botrobber.bot_dumb
    | "david_0_" -> Botrobber.bot_david 0 
    | "david_1_" -> Botrobber.bot_david 1
    | "david_2_" -> Botrobber.bot_david 2
    | "last" -> Botrobber.bot_last ## can take more parameters via 2 different -robber_... options
    | "BEST" -> Botrobber.bot_last ## can take more parameters via 2 different -robber_... options ## CONFIG
    | s -> failwith ("no such bot:" ^ s)
    )


let rec cop whichone = 
  match whichone with
    | "dumb" -> Bot.cop (Reg(("BAryx-Cop-" ^ whichone), Cop CopCar)) Botcop.bot_dumb
    | "rand" -> Bot.cop (Reg(("BAryx-Cop-" ^ whichone), Cop CopCar)) Botcop.bot_random_mc_gruff
    | "starsky" -> Bot.cop (Reg(("BAryx-Cop-" ^ whichone), Cop CopFoot)) Botcop.bot_starsky
    | "deploy_chase" -> Bot.cop (Reg(("BAryx-Cop-" ^ whichone), Cop CopCar)) Botcop.bot_to_bank
    | "BEST" ->         Bot.cop (Reg(("BAryx-Cop-" ^ whichone), Cop CopCar)) Botcop.bot_to_bank ## CONFIG
    | "deploy_hint" -> Bot.cop (Reg(("BAryx-Cop-" ^ whichone), Cop CopCar)) (Botcop.bot_forecast)
    | "deploy_5" -> Bot.cop (Reg(("BAryx-Cop-" ^ whichone), Cop CopCar)) (Botcop.bot_forecast_5)
    | "deploy_smell" -> Bot.cop (Reg(("BAryx-Cop-" ^ whichone), Cop CopFoot)) (Botcop.bot_forecast_5_smell) ## FRED: CopCar -> CopFoot
    | "deploy_smell_car" -> Bot.cop (Reg(("BAryx-Cop-" ^ whichone), Cop CopCar)) (Botcop.bot_forecast_5_smell) 
    | _ -> raise Impossible

let main () = 
  begin
    match (basename Sys.argv.(0)) with
    | "robber"  -> robber "BEST"
    | "cop"     -> cop "BEST"
    | _ ->
        
    let arg1 = ref None in
    let arg2 = ref None in
    let default_robber = ref true in
    let options = Arg.align
      [ 
        "-verbose",  Arg.Set Flag.verbose, "  verbose mode";
        "-verbose_comm",  Arg.Set Flag.verbose_comm, "  verbose comm mode";
        "-setX",  Arg.Set_int Flag.xglob, "  set xglob";
        "-robber",  Arg.Set default_robber, "  set robber";
        "-cop",  Arg.Clear default_robber, "  set cop";
        "-detrandom", Arg.Clear Flag.nondet_random, " set random to some determinate behaviour(do not use seed)";

        "-robber_depth_chess", Arg.Set_int Flag.robber_depth_chess, " set chess depth (2 good, 3 can cause pbs, 1 not enough can cause pbs)";
        "-robber_erase_edges_radius", Arg.Set_int Flag.robber_erase_edges_radius, " set edges radius depth (1 seems good, 2 can cause pbs)";
      ] in 
    let usage_msg = 
      ("Usage: " ^ basename Sys.argv.(0) ^ " [options] <arg1> <arg2>\nOptions are:") in
    Arg.parse
      options
      (fun s -> 
        match !arg1 with
        | None -> arg1 := Some s
        | Some arg1 -> 
            (arg2 := Some s;
             ##do_something2 arg1 arg2;
             ## Unix.sleep 6;  can here, np
             let _ = if !Flag.nondet_random  then Random.self_init () else () in

             if !default_robber 
             then robber arg1
             else cop arg1
            )
      )
      usage_msg;
    (match (!arg1, !arg2) with
    | (Some _, Some _) -> ()
    | _ -> Arg.usage options usage_msg
    );
          
  end


let _ = if not !Sys.interactive then main ()
