open Lib

let main = 
  Bot.robber (Reg (("Aryx-Robber-" ^ "last"), Robber))
    (Botrobber.bot_last)
