open Message_lexer
open Common

let trace = false

let token_string = function
  | EOL -> "EOL"
  | CLOSEBANNER x -> Printf.sprintf "%s\\" x
  | OPENBANNER x -> Printf.sprintf "%s/" x
  | TOK s -> s
  | TAG s -> Printf.sprintf "%s:" s


let (next_token:  unit -> Message_lexer.token option)  = 
  let lexbuf = Lexing.from_channel stdin in
  fun () -> 
    try 
      Some (Message_lexer.token lexbuf)
    with
	_ -> None


type lazy_list = Empty | Call | Elt of token * (lazy_list ref )

type tokens =  lazy_list ref


let next_token (l:tokens)  =
  match !l with
    | Empty -> None
    | Call -> 
	(match next_token () with
	  | None -> None
	  | Some t -> 
	      let rest = ref Call in
	      l:= Elt (t,rest) ; Some (t,rest)) 
    | Elt(t,rest) -> Some (t,rest)

let rec get_next (k:int) (l:tokens) : Message_lexer.token list * tokens =
  match k with
    |0 -> ([],l)
    | n -> match next_token l with
	| None -> failwith "parse_error get_next"
	| Some (t,l) -> 
	    if trace then print_string (token_string t);
	    let tokens, res = get_next (k-1) l in
	    (t::tokens,res)




(*********************************************************************************************)
(** Parser combinators **)

let parse_tag1 (name:string) (tokens:tokens) :  string * tokens  =
  if trace then Printf.printf "parse_tag1 %s\n" name;
  match get_next  3 tokens with
    | [TAG nm ; TOK n ; EOL],l -> if nm = name then n,l else failwith (Printf.sprintf "parse error parse_tag1(1) %s" name)
    |   l,  _   -> failwith (Printf.sprintf "parse error parse_tag1(2) %s %s" name (String.concat ";" (List.map token_string l)))

let parse_tag2 (name:string) (tokens:tokens) : (string*string) * tokens  =
  match get_next  4 tokens with
    | [TAG nm ; TOK n ; TOK m; EOL],l -> if nm =name then ((n,m),l) else failwith "parse error parse_tag2"
    |     _   -> failwith "parse error parse_tag2"



let parse_banner (banner:string) (parse_body: tokens -> 'a * tokens) (tokens: tokens): 'a * tokens = 
  if trace then Printf.printf "parse+banner :%s" banner;
  match get_next 2 tokens  with
    | [OPENBANNER (ban) ; EOL],tokens -> 
	if ban = banner then
	  let res,tokens = parse_body tokens in
	  (match get_next 2 tokens with
	    | [CLOSEBANNER ban; EOL],tokens -> 
		if ban = banner then res,tokens else failwith "parse error bad banner"
	    | _ -> failwith "parse error parse_banner")
	else failwith "parse_banner : bad banner"

    | _ -> failwith "parse error parse_banner"
	      
let alt (p1:tokens -> 'a *tokens) (p2:tokens -> 'b*tokens) (tokens:tokens) : ('a,'b) either * tokens=
  try
    let res,tokens = p1 tokens in
    (Left res),tokens
  with
      _ ->     let res,tokens = p2 tokens in
    (Right res),tokens

let rec alt_list l tokens = 
  match l with 
    | [] -> failwith "parse error"
    | e::l -> 
	try e tokens 
	with _ -> alt_list l tokens

(* should use alt with parse_list *)
let parse_banner_list (name:string) (parse_elt:tokens-> 'a *tokens) (tokens:tokens): 'a list * tokens=
  let rec iter_tags tokens =
    match next_token tokens with
      | Some (TAG nm,tokens) -> 
	  if name = nm then
	    let res,tokens = parse_elt tokens in 
	    let rest,tokens = iter_tags tokens in
	    res::rest, tokens
	  else failwith "parse_banner_list : bad tag"
      | Some (CLOSEBANNER nm,tokens) -> 
	  if nm <> name then failwith "parse_banner_list : bad clsing banner";
	  (match next_token tokens with
	    |	Some (EOL,tokens) -> [],tokens
	    |   _  -> failwith "parse_banner_list")
      |  Some s    -> failwith (Printf.sprintf "parse error parse_banner_list(1)")
      |  _    -> failwith (Printf.sprintf "parse error parse_banner_list(2)")
  in
  match get_next 2 tokens with
    | [ OPENBANNER (banner) ; EOL],tokens -> 
	  if banner<> name then failwith "parse_banner_list : bad open banner";
	iter_tags tokens 
    | _ -> failwith "parse error parse_banner(3)"


let rec parse_seq (k:int) (parse_elt:tokens -> 'a*tokens) (tokens:tokens): 'a list*tokens = 
  match k with
    | 0 -> [],tokens
    | n -> 
	let res,tokens = parse_elt tokens in
	let rest,tokens = parse_seq (k-1) parse_elt tokens in
	res::rest,tokens

(*************************************************************************************************)
(** Entry points **)

open Lib

let parse_ptype = function
  | "cop-foot" -> Cop CopFoot
  | "cop-car" -> Cop CopCar
  | "robber" -> Robber
  |   _ -> failwith "parser error : bad ptype"

let ptype_string (p:player) : string =
  match p with
    |  Robber -> "robber"
    | Cop CopCar -> "cop-car"
    | Cop CopFoot -> "cop-foot"


let parse_register_msg tokens : register_msg * tokens=   
  let (bot,ptyp),tokens  =   parse_tag2 "reg"  tokens in Reg (bot,parse_ptype ptyp) ,tokens


let parse_node_tag = function
  | "hq" -> Hq
  | "bank" -> Bank
  | "robber-start" -> Robber_start
  | "ordinary" -> Ordinary
  |  _ -> failwith "bad node tag"

let node_tag_string (node:node) : string =
  match node with
    | Hq -> "hq"
    | Bank -> "bank"
    | Robber_start -> "robber-start"
    | Ordinary -> "ordinary"

let parse_nod  (tokens:tokens) : (loc * node * (int * int))*tokens =
  match get_next 5 tokens with
      [ TOK loc;TOK node_tag; TOK coor ; TOK coor' ; EOL],tokens -> (Loc loc, parse_node_tag node_tag, (int_of_string coor , int_of_string coor')),tokens
    |  _ -> failwith "parse error : parse_nod"


let parse_edge_tag = function
  | "car" -> CarEdge
  | "foot" -> FootEdge
  |  _ -> failwith "bad edge tag"


let edge_tag_string (e:edge) : string =
  match e with
    | CarEdge -> "car"
    | FootEdge -> "foot"


let parse_edg (tokens:tokens): ((loc * loc) * edge)*tokens =
  match get_next 4 tokens with
      [ TOK loc; TOK loc'; TOK edget ; EOL],tokens -> ((Loc  loc, Loc loc'), parse_edge_tag edget ),tokens
    |  _ -> failwith "parse error : parse_edg"

  


let parse_world_skeleton_msg  tokens : world_skeleton_msg*tokens =
  let parse tokens =
    let name,tokens = parse_tag1 "name" tokens in
    let robber,tokens  = parse_tag1 "robber" tokens in
    let cops,tokens = parse_seq 5 (parse_tag1 "cop") tokens in
    let nodes,tokens = parse_banner_list "nod" parse_nod tokens in
    let edges,tokens  = parse_banner_list "edg" parse_edg tokens in
    { 
      wsk_name = name;
      wsk_robber = robber ;
      wsk_cops = cops;
      wsk_nodes = nodes;
      wsk_edges = edges;
    },tokens
    in
  parse_banner "wsk" parse tokens

let parse_bv tokens :(loc * int)*tokens =
  match get_next 3 tokens with
    | [ TOK loc; TOK bk ; EOL],tokens -> (Loc loc,int_of_string bk),tokens
    |   _ -> failwith "parse_bv"
 
let parse_ev (tokens:tokens): (loc *evidence) *tokens=
  match get_next 3 tokens with
    | [ TOK loc; TOK bk; EOL],tokens -> (Loc loc, WasHereAt (int_of_string bk)),tokens
    |   _ -> failwith "parse_ev"


let parse_pl (tokens:tokens) :(playername * loc * player)*tokens =
  match get_next 4 tokens with
    | [ TOK bot; TOK loc ; TOK ptype; EOL ],tokens -> (bot,Loc loc,parse_ptype ptype),tokens
    |   _ -> failwith "parse_ev"


let parse_world_msg_body tokens = 
  let wrd,tokens = parse_tag1 "wor" tokens in
  let rbd,tokens = parse_tag1 "rbd" tokens in
  let bv,tokens = parse_banner_list "bv" parse_bv tokens  in
  let ev,tokens = parse_banner_list "ev" parse_ev tokens  in
  let smll,tokens = parse_tag1 "smell" tokens in
  let pl,tokens = parse_banner_list "pl" parse_pl tokens in
  {
    w_round = int_of_string wrd;
    w_robber_butin =  int_of_string rbd;
    w_evidence = ev ;
    w_smell = Smll (int_of_string smll);
    w_players = pl;
    w_banks_butin = bv
  },tokens

let parse_world_msg tokens :world_msg *tokens= 
 (parse_banner "wor" parse_world_msg_body tokens)



let parse_move_msg tokens:move_msg*tokens = 
  let (x,y),tokens = parse_tag2 "mov" tokens in
  Move (Loc x, parse_ptype y),tokens




let parse_game_over tokens : gameover_msg*tokens = 
  match get_next 2 tokens with
    | [TOK "game-over";EOL] ,tokens -> GameOver,tokens
    | _ -> failwith "parse error"


let parse_game_over_world tokens : (gameover_msg,world_msg) either *tokens=
  alt parse_game_over parse_world_msg tokens
	      


let parse_inform_msg tokens : inform_msg*tokens = 
  let parse_inf tokens =
    match get_next 6 tokens with
      |[ TOK bot ; TOK loc ; TOK ptype ; TOK world ; TOK certainty; EOL],tokens -> 
	 (bot, Loc loc , parse_ptype ptype , int_of_string world , Certainty (int_of_string certainty)) ,tokens
      |   _ -> failwith "parse_inf" in
  let res,tokens = parse_banner_list "inf" parse_inf tokens in
  Inform res,tokens


let parse_plan_msg tokens : suggest_plan_msg *tokens =
  let parse_plan tokens =
    match get_next 5 tokens with
      |[ TOK bot ; TOK loc ; TOK ptype ; TOK world ; EOL],tokens -> (bot, Loc loc , parse_ptype ptype , int_of_string world),tokens
      |   _ -> failwith "parse_inf" in
  let res,tokens = parse_banner_list "plan" parse_plan tokens in
  SuggestPlan res,tokens


let parse_vote_result tokens : vote_result_msg*tokens =
  let res,tokens =
    (match next_token tokens with
      | Some (TAG "winner",tokens) -> 	
	  (match get_next 2 tokens with
	    | [TOK bot ; EOL],tokens -> Winner bot,tokens
	    |   _ -> failwith "error")
      | Some (TAG "nowinner",tokens) -> 
	  (match next_token tokens with
	    | Some (EOL,tokens) -> NoWinner,tokens
	    |  _ -> failwith "error"
	  )
      | _ -> failwith "error"
    ) in
  VoteResult res,tokens

let parse_msg_inform tokens : from_msg_inform*tokens =
  let parse_from tokens =
    match get_next 2 tokens with
	[ TOK bot ; EOL],tokens -> 
	  let res,tokens = parse_inform_msg tokens in
	  (bot,res),tokens
      |  _ -> failwith "parse_msg_inform" in
  (parse_banner_list  "from" parse_from tokens)


let parse_msg_plan tokens : from_msg_plan*tokens =
  let parse_plan tokens =
    match get_next 2 tokens with
	[ TOK bot ; EOL] ,tokens -> 
	  let res,tokens = parse_plan_msg tokens in
	  (bot,res),tokens
      |  _ -> failwith "parse_msg_plan" in
  parse_banner_list  "from" parse_plan tokens


type message = 
  | From_msg_plan of from_msg_plan 
  | From_msg_inform of from_msg_inform
  | World_skeleton_msg of world_skeleton_msg
  | World_msg of world_msg
  | Move_msg of move_msg
  | Over of gameover_msg
  | VoteResultMsg of vote_result_msg      
  | Void


	  
let p1 tokens =     
  let res,tokens = parse_game_over tokens in
  Over res,tokens

let p2 tokens =     
  let res,tokens = parse_world_msg tokens in
  World_msg res,tokens

let p3 tokens   =     
  let res,tokens = parse_move_msg tokens in
  Move_msg res,tokens

let p4 tokens =     
  let res,tokens = parse_world_skeleton_msg tokens in
  World_skeleton_msg res,tokens

let p5 tokens = 
  let res,tokens = parse_msg_inform tokens in
  From_msg_inform res,tokens
    
let p6 tokens = 
  let res,tokens = parse_msg_plan tokens in
  From_msg_plan res,tokens

let p7 tokens = 
  let res,tokens =   parse_vote_result tokens in
  VoteResultMsg res,tokens


let empty tokens =
  match next_token tokens with
    | Some (EOL,tokens) -> Void,tokens
    | _ -> failwith "parse error"


let tester tokens = 
  alt_list [p1;p2;p3;p4;p5;p6;p7;empty] tokens


(*******************************************************)
(** printers **)

let world_skeleton_string (wk:world_skeleton_msg) : string = 
  let node_string (Loc loc ,node , (i1 , i2)) =
    Printf.sprintf "\t%s %s (%i,%i)" loc (node_tag_string node) i1 i2 in
  let edge_string ((Loc l1,Loc l2) ,edge)  =
    Printf.sprintf "\t%s -%s-> %s " l1 (edge_tag_string edge) l2 in

  let 
    { 
      wsk_name = myname;
      wsk_robber = robber;
      wsk_cops =   cops ;
      wsk_nodes = nodes;
      wsk_edges = edges
    } = wk in
  Printf.sprintf 
"{
   wsk_name   = %s;
   wsk_robber = %s
   wsl_cops   = %s
   wsk_nodes  =\n %s
   wsk_edges  = %s
}" myname robber 
    (String.concat ";" cops) 
    (String.concat "\n" 
      (List.map node_string nodes))
    (String.concat "\n" (List.map  edge_string edges))


let world_msg_string (msg: world_msg) :string = 
	let {
	  w_round =  round;
	  w_robber_butin = butin;
	  w_banks_butin = banks;
	  w_evidence = evidences;
	  w_smell = Smll smell;
	  w_players = players
	}  = msg in
   Printf.sprintf 
"{
  w_round =  %i;
  w_robber_butin = %i;
  w_banks_butin = %s;
  w_evidence = %s;
  w_smell = %i;
  w_players = %s
}" round butin 
     (String.concat ";" (List.map (fun (Loc s,i) -> Printf.sprintf " Bank %s : %i " s i) banks))
     (String.concat ";" (List.map (fun (Loc s,WasHereAt i) -> Printf.sprintf " %s : WasHereAt %i " s i) evidences))
     smell
     (String.concat ";" (List.map (fun (name, Loc l,player) -> Printf.sprintf "%s %s %s" name l (ptype_string player)) players))


let msg_gameover_or_world_msg_string (msg : (gameover_msg,world_msg) either) : string = 
  match msg with
    | Left gameover_msg -> "gameover"
    | Right world_msg -> world_msg_string world_msg


let msg_inform_string (Inform msg ) : string = 
  let send_inform (playername , Loc loc , player , round , Certainty certainty) =
    Printf.sprintf "\t %s %s %s %i %i\n" playername loc (ptype_string player) round certainty in
  String.concat  "\n" (List.map send_inform msg)

    
let from_msg_inform_string (msg: from_msg_inform) : string = 
  String.concat "\n" (List.map (fun (name,inform_msg) -> Printf.sprintf "%s says : %s" name (msg_inform_string inform_msg)) msg)


let msg_plan_string (SuggestPlan msg:  suggest_plan_msg ) : string = 
  let plan_string (playername , Loc loc , player , round ) =
    Printf.sprintf "\t %s goto %s with %s at round %i\n" playername loc (ptype_string player) round in
  String.concat "\n" (List.map plan_string msg)

let from_plan_msg_string (msg: from_msg_plan) : string = 
  String.concat "\n" (List.map (fun (name,plan_msg) -> Printf.sprintf "%s suggests : %s" name (msg_plan_string plan_msg)) msg)


let vote_res_msg_string (VoteResult msg: vote_result_msg) : string = 
  match msg with
    | Winner pn -> Printf.sprintf "winner %s" pn
    | NoWinner   -> "nowinner"




let  message_string (msg: message) : string = 
  match msg with
  | From_msg_plan  from_msg_plan  -> from_plan_msg_string from_msg_plan
  | From_msg_inform  from_msg_inform -> from_msg_inform_string from_msg_inform
  | World_skeleton_msg  world_skeleton_msg -> world_skeleton_string world_skeleton_msg
  | World_msg  world_msg -> world_msg_string world_msg
  | Move_msg  move_msg -> "Move"
  | Over  gameover_msg -> "gameover"
  | VoteResultMsg  vote_result_msg  -> vote_res_msg_string   vote_result_msg
  | Void -> "void"
