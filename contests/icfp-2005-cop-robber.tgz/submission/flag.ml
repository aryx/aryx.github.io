let verbose  = ref false
let verbose_comm  = ref false
let xglob = ref 0
let nondet_random = ref true


##CONFIG
## 0 dead (1 deploy_chase)
## 1 dead (1 deploy_chase)
## 2 work quite well, enough for cul-de-sac
## 3 and bug :((( with 1 deplay_chase  (cos nothing become safe  cos at 3 from many cops)
let robber_depth_chess = ref 2

##CONFIG
## 2 dead (2 deploy_chase,  sometimes)
let robber_erase_edges_radius = ref 2

(*
-level_log
-log_modules/functions "lfs.algo, lfs.dirs, ...."
-command
*)
