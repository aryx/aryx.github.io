open Lib

let main = 
  Bot.cop (Reg(("BAryx-Cop-" ^ "smell_car"), Cop CopCar)) 
    (Botcop.bot_forecast_5_smell) ## FRED: CopCar -> CopFoot



