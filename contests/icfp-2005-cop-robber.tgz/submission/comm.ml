open Common
open Lib
open Message_parser

let debug = Flag.verbose_comm


(*let (display_dot: 'a graph -> ('a -> string) -> unit) = fun (nodes, arcs)
func ->
  let file = open_out "test.dot" in
  output_string file "digraph misc {\n" ;

  List.iter (fun (n, node) -> output_int file n; output_string file "
  [label=\"";
    output_string file (func node); output_string file " \"];\n"; ) nodes;
  List.iter (fun (i1,i2) ->  output_int file i1 ; output_string file " -> " ;
    output_int file i2 ; output_string file " ;\n"; ) arcs;
  output_string file "}\n" ;
  close_out file;
  let status = Unix.system "viewdot test.dot" in
  ()
*)

module NodeMap = Map.Make(struct type t = string let compare = compare end)


let generate_dot : world_skeleton_msg -> string -> unit = fun wsk file -> 
  let file = open_out file in
  let color_of_edge = function CarEdge -> "red" | FootEdge -> "black" in
  let color_of_node  = function
      | Hq  -> Some "blue"
      | Bank -> Some "yellow"
      | Robber_start -> Some "red" 
      | Ordinary -> None
  in

  let map = List.fold_left (fun map (Loc name,_,pos) -> NodeMap.add name pos map) NodeMap.empty wsk.wsk_nodes in
  let node_name pos = Printf.sprintf  "%i-%i" (fst pos) (snd pos) in

  let rec go_trough rest ddone = 
    match rest with 
	[] -> ()
      | e::lrest -> 
	  let ((Loc l1,Loc l2),edge) = e in
	  (if List.mem ((Loc l2,Loc l1),edge) ddone 
	  then () (* This is a bidirectional edge - already output*) 
	  else
	    if List.mem ((Loc l2,Loc l1),edge) lrest
	    then(* This is ALSO a bidirectional edge -  output Now*) 
		Printf.fprintf file "\"%s\" -> \"%s\" [color = %s]\n" (node_name (NodeMap.find l1 map)) (node_name (NodeMap.find l2 map)) (color_of_edge edge)
	    else (* Unidirectional *)
	      Printf.fprintf file "\"%s\" -> \"%s\" [color = %s , style = dotted]\n" (node_name (NodeMap.find l1 map)) (node_name (NodeMap.find l2 map)) (color_of_edge edge)
	  ); go_trough lrest (e::ddone) in

  output_string file "digraph map {\n" ;
  List.iter (fun (Loc x,node, _) -> match color_of_node node with
    |  None -> ()
    | Some c -> Printf.fprintf file "\"%s\" [style = filled , color = %s ]\n" (node_name (NodeMap.find x map))  c) wsk.wsk_nodes;
  go_trough (List.sort compare wsk.wsk_edges) [];
  output_string file " }\n" ;
  close_out file

(**************************************************************************************)
(* send.... receive.... *)
let send_string str = 
  if !debug then (Printf.fprintf stderr "---> %s\n" str; flush stderr);
  output_string stdout str ; flush stdout


let echo_message str = 
  if !debug then Printf.fprintf stderr "<--- %s\n" str



let (send_register_msg: register_msg -> unit) = fun (Reg(pname,player)) ->
  send_string (Printf.sprintf "reg: %s %s\n" pname (ptype_string player))
## bad reg  send_string (Printf.sprintf "regx: %s %s\n" pname (ptype_string player))
## roober instead of cop  send_string (Printf.sprintf "reg: blup %s\n"  "cop-car")
## too much spaces (Printf.sprintf "reg:   blup %s\n"  "cop-car")


let receive_world_skeleton : unit -> world_skeleton_msg = fun () -> 
  let msg =  fst (parse_world_skeleton_msg (ref Call)) in
  generate_dot msg "/tmp/file.dot";
  echo_message (world_skeleton_string msg) ;
  msg

let receive_msg_gameover_or_world_msg : unit -> (gameover_msg,world_msg) either = fun () -> 
  let msg = fst (parse_game_over_world (ref Call)) in
  echo_message (msg_gameover_or_world_msg_string msg) ;
  msg
  

let send_move_msg (Move (Loc x,typ) :move_msg) = 
  send_string (Printf.sprintf "mov: %s %s\n" x (ptype_string typ)) 

let send_inform_msg (Inform l) = 
  let send_inform (playername , Loc loc , player , round , Certainty certainty) =
    send_string (Printf.sprintf "inf: %s %s %s %i %i\n" playername loc (ptype_string player) round certainty) in
  send_string "inf\\ \n";
  List.iter send_inform l;
  send_string "inf/ \n" 

let receive_from_inform_msg : unit -> from_msg_inform = fun () -> 
  let msg =  fst (parse_msg_inform (ref Call)) in
  echo_message (from_msg_inform_string msg) ;
  msg


let send_plan_msg (SuggestPlan l:suggest_plan_msg) : unit =
  let send_plan (playername , Loc loc , player , round ) =
    send_string (Printf.sprintf "plan: %s %s %s %i\n" playername loc (ptype_string player) round ) in
  send_string "plan\\ \n";
  List.iter send_plan l;
  send_string "plan/ \n"

let receive_from_plan_msg : unit -> from_msg_plan = fun () -> 
  let msg =  fst (parse_msg_plan (ref Call)) in
  echo_message (from_plan_msg_string msg) ; msg

let send_vote_msg (Voting l:voting_msg) = 
  send_string "vote\\ \n";
  List.iter (fun x -> send_string (Printf.sprintf "vote: %s\n"x )) l;
  send_string "vote/ \n"
  
  
let receive_vote_res_msg : unit -> vote_result_msg = fun () -> 
  let msg =  fst (parse_vote_result (ref Call)) in
  echo_message (vote_res_msg_string msg) ;
  msg
