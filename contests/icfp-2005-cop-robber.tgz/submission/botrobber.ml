 open Common
open Dumper

open Lib

open Bot

##bots:
## dumb
## random


## used to compute/select free banks (and faufileur1)
let (dist_nearest_cop: world -> loc -> int) = fun w loc1 -> 
  w.state.other_cops_info 
    +> List.map (fun (p, state, loc2) -> dist_path w (loc2, loc1) (Cop state))
    +> List.sort (fun i1 i2 -> compare i1 i2)
    +> List.hd


## used by faufileur2
let (dist_nearest_bank: world -> loc -> int) = fun w loc1 -> 
  w.state.banks_info 
    +> List.map (fun (loc2, m) -> dist_path w (loc2, loc1) Robber)
    +> List.sort (fun i1 i2 -> compare i1 i2)
    +> List.hd



(*******************************************************************************)

(*** Proposal to compute a  move that cannot lead to interception.

  It makes the assumption the worst case assumption that the cop can track me - it knows what choice I am doing
  Suppose that d is the distance for the cop to get me
  
  We compute a function "path_to_escape" : pos * pos -> int
  if from myloc I choose loc' then how long does it takes to find the first intersection
  
  A move is safe is path_to_escape >= 2*d  

  I think it allows to go in the bank in the deadend and escape before the cop arrives

  
  This does not work for multiple cops => take into account the arity of the intersection ??

  Another proposal, simulate the worst case (all the cops are tacking you)
     by only choosing a safe move as described above


*)

(*** Other Proposal to compute a  move that cannot lead to interception.
  chess
*)

let debug_danger = true

let (is_dangerous_chess: world -> loc -> bool) = fun w loc_start -> 
  let rec is_dangerous_aux loc depth =
    let _ = if debug_danger then pr2 (Printf.sprintf "%s> is_dangerous_chess: testing %s at depth %s" (repeat "-" depth +> String.concat "") (dump loc) (dump depth)) in
    (if depth > !Flag.robber_depth_chess
    then false
    else 
      let nearest_cop_dist = dist_nearest_cop w loc in
      let around_and_here = around_and_here w loc Robber in

      ((nearest_cop_dist - depth) <= 1) ## modulate ? 
        || ##subtil: || and not &&    
      (around_and_here +> List.for_all (fun newloc -> is_dangerous_aux newloc (depth+1)))
     )
    +> (fun res -> if debug_danger then pr2 ((Printf.sprintf "%s< is_dangerous_chess: " (repeat "-" depth +> String.concat ""))^ string_of_bool res); res)
       
  in
  is_dangerous_aux loc_start 0




##todo: is_dangerous --> dangerousness_level (return  dangerous_indices (number of steps before dangerous))
let (is_dangerous: world -> loc -> bool) = fun w loc1 -> 
  ## || is on the bank (note: useless because of after, but sometimes redundant code is not bad, safer is better)
  w.state.other_cops_info +> List.exists (fun (p, state, loc2) -> 
    loc1 = loc2
    )
   ||

  ## || can go there in one step
  w.state.other_cops_info +> List.exists (fun (p, state, loc2) -> 
    dist_path w (loc2, loc1) (Cop state) <= 1 
    )
 || 
   is_dangerous_chess w loc1






(*******************************************************************************)

let depth_handling_cops = ref 2

## can do it based on warshall_matrix ? hard (cos filter not enough)
## can do it based on node_matrix ? yes (erase row and columns
## could do it by from digraph return original (list format), filter, and rebuild
let (compute_map_robber_handling_cops: world -> ((loc, node, edge) Graph.digraph)) = fun w -> 
  let (myname, myplayer, myloc) = w.me in

  ##those where is cop, and around cop (with state)
  let dangerous_nodes = 

    ## at 0 move
    let shot = Setb.from_list (w.state.other_cops_info +> List.map (fun (p, state, loc) -> (state, loc))) in

    ## at 1 move
    let shot = 
      if !depth_handling_cops >= 1 then
      Setb.fold (fun (state, loc) a  -> 
        Setb.union a 
          (Setb.from_list 
              ##TODO:  if Hq the state of the cop can change => have to put two (newstate, newloc)
              ((Bot.around w loc (Cop state)) +> List.map (fun newloc -> (state, newloc)))
          )
       ) shot shot
      else shot
    in

    ## at 2 move
    let shot = 
      if !depth_handling_cops >= 2 then
      Setb.fold (fun (state, loc) a  -> 
        Setb.union a 
          (Setb.from_list 
              ##TODO:  if Hq the state of the cop can change => have to put two (newstate, newloc)
              ((Bot.around w loc (Cop state)) +> List.map (fun newloc -> (state, newloc)))
          )
       ) shot shot
      else shot
    in

    
    shot 
      +> Setb.elements 
      +> List.map (fun (state, loc) -> loc)
      ## CONFIG ? 
      +> List.filter (fun loc -> loc != myloc) ## dont want erase my own node, otherwise cant compute path
  in
  
  
  ##get map_without_nodes (erase,  edge with one dangerous)
  let newmap = Graph.erase_edges_containing dangerous_nodes (w.map_foot FootEdge) in ## it is my map
  newmap

let (compute_best_way_robber_handling_cops: world -> (edge -> (loc * loc) -> (loc list))) = fun w -> 
  let newmap = compute_map_robber_handling_cops w in
  let new_best_way = Graph.global_best_way  newmap in
  (fun edge (loc1, loc2) -> 
    let _ = assert (edge = FootEdge) in
    new_best_way loc1 loc2
  )


## may have less banks !! cos exn
## quite similar too my_best_path_to (and so to best_path_to)
let (my_path_to_banks_handling_cops: world -> path_to_banks) = fun w -> 
  let (myname, myplayer, myloc) = w.me in
  let _ = assert (myplayer = Robber) in

  let best_way = compute_best_way_robber_handling_cops w in
  w.state.banks_info +> List.fold_left (fun a (loc, m) -> 
    try 
      let path = best_way FootEdge (myloc, loc) in
        ({
          start = myloc ; 
          dest = loc; 
          player = Robber ; 
          path =  path ;
          len = List.length path;
        }, m)
        ::a
    with _ -> a
   ) []

let rec min_list = function
    [] -> failwith "min_list : nil arg"
  | [a] -> a
  | a::b::q -> Graph.min a (min_list (b::q))

let rec and_list = function
    [] -> failwith "and_list : nil arg"
  | [a] -> a
  | a::b::q -> a || (and_list (b::q))

let (best_dist : Lib.world -> copstate -> (loc * loc) -> Graph.int') = fun w ->
  function
      CopCar -> w.best_dist_car
    | CopFoot -> w.best_dist_foot
  

let (risk_cop : world -> Graph.int' array) = fun w ->
  Array.init (Array.length w.map.Graph.matrix)
    (fun i -> min_list
       (List.map
	  (fun (playername,copstate,loc) ->
	     best_dist w copstate (loc,(Mapb.find i w.map.Graph.int_to_nodes)))
	  w.state.other_cops_info))

let (smell_cop : world -> bool array) = fun w ->
  Array.init (Array.length w.map.Graph.matrix)
    (fun i -> and_list
       (List.map
	  (fun (playername,copstate,loc) ->
	     match copstate with
		 CopFoot ->  
		   Graph.comp (w.best_dist_foot (loc,(Mapb.find i w.map.Graph.int_to_nodes))) (Graph.I 2)
	       | CopCar -> 
		   Graph.comp (w.best_dist_car (loc,(Mapb.find i w.map.Graph.int_to_nodes))) (Graph.I 1))
	  w.state.other_cops_info))

let (my_dist : world -> Graph.int' array) = fun w ->
  let (_,_,loc) = w.me in
    Array.init (Array.length w.map.Graph.matrix)
      (fun j -> w.best_dist_foot (loc,Mapb.find j w.map.Graph.int_to_nodes))

exception InBank

let (path_handling_cops_risk : world -> 
         (bool->Graph.int'->Graph.int'->Graph.int') -> path_to_banks) = fun w risk ->
  let (myname, myplayer, myloc) = w.me in
  let _ = assert (myplayer = Robber) in

  let best_way = Graph.local_best_way_with_risk (w.map_foot FootEdge) risk (smell_cop w) (risk_cop w) (my_dist w) myloc in
    sort_banks
  (w.state.banks_info +> List.fold_left (fun a (loc, m) -> 
    try 
## DIE MORE      (if loc=myloc then raise (*toto*)InBank
      (if loc=myloc then 
({
              start = myloc ; 
              dest = loc; 
              player = Robber ; 
              path =  [];
              len = 0;
            }, m)::a
       else
	 let path = best_way loc in
           ({
              start = myloc ; 
              dest = loc; 
              player = Robber ; 
              path =  path ;
              len = List.length path;
            }, m)::a)
    with Graph.NoWay -> a
   ) [])


(*******************************************************************************)
let nodeadlock w commands = 
  commands


let deadlock w commands = 
  commands




(*******************************************************************************)
let rec nopattern w commands = 
  commands

##todo: fault: can loop ? => put in engine
let rec pattern w commands = 
  let (myname, myplayer, myloc) = w.me in
  commands 
    +> List.filter (fun (Move (loc,_)) -> not (is_dangerous w loc))
(*
DONE: move that in exn handler
    +> (fun xs -> 
          if xs = [] 
          then Bot.around_and_here w myloc myplayer
                 +> List.map (fun loc -> Move (loc, myplayer))
                 +> pattern w
          else xs
       )
*)




(*******************************************************************************)
##todo: test give not adjacent

##semitested: give not valid (with random-illegal, I get error)
##tested: Move (Loc "NOWHERE", snd3 w.me)
##tested_nodiag: Move (thd3 w.me, Cop CopCar)


##dumb 
let strat_dumb w = 
      let (myname, myplayer, myloc) = w.me in
      [ Move (thd3 w.me, snd3 w.me) ]


##random,  with some possible illegal move
let strat_random w = 
      let (myname, myplayer, myloc) = w.me in

      let succ = w.map +> Graph.successors myloc in
      pr2 (sprintf "Successors = %s" (dump succ));
      let _ = assert (List.length succ > 0) in
      [Move (random_list succ, snd3 w.me) ]


##random,  legal move
let strat_random_legal w = 
      let (myname, myplayer, myloc) = w.me in

      let succ = w.map_foot FootEdge +> Graph.successors myloc in
      pr2 (sprintf "Successors = %s" (dump succ));
      let _ = assert (List.length succ > 0) in
      
      [Move (random_list succ, snd3 w.me)]
        +> (fun res -> pr2 (sprintf "I am going there: %s" (dump res)); res)


let strat_nearest w = 
      let (myname, myplayer, myloc) = w.me in

      ##nearest, naive
      ##let dist_banks = 
      ##  w.state.banks_info +> List.map (fun (loc, _) -> 
      ##    w.best_way_foot FootEdge (myloc, loc)
      ##    ) in
      ##let sorted_banks = List.sort (fun a b -> List.length a - List.length b) dist_banks in
      ####tested: get longest one with 
      ####  let sorted_banks = List.sort (fun a b -> List.length b - List.length a) dist_banks in
      #### note that strange behaviour cos as gets closer to farest, then the target change :)
      ##let best_bank = List.hd sorted_banks in
      ##pr2 (sprintf "Plan = %s" (dump best_bank));
      ##let next_move = List.hd best_bank in
      ##[Move (next_move, snd3 w.me)]

      ##nearest, naive,  bis
      ##TODO handle cops here !!! note that it also filter some banks  cos no path to go there
      let path_banks = Bot.my_path_to_banks w in

      ##nearest handling cops inmpossible path
      let path_banks = my_path_to_banks_handling_cops w in

      let sorted_banks = Bot.sort_banks path_banks in
      ####  let sorted_banks = List.sort (fun a b -> List.length b - List.length a) dist_banks in

      ## modulated_money, not used cos taux de remplissage tel que meme si 0 pour l'instant, better to stay here
      let sorted_banks_NOTUSED = sorted_banks +> List.filter (fun (loc, money) -> money != 0) in

      ## modulated_ending (just special case)
      let sorted_banks = 
        sorted_banks +> List.filter (fun (loc, money) -> 
          let is_at_end_so_all_empty = 
            w.state.banks_info +> List.for_all (fun (_,i) -> i <= 50) in
          if is_at_end_so_all_empty 
          then money != 0 
          else true ## better to stay here, cos would be too long to go elsewhere
              ) in

      ## filter free   TODO compute freeness indices (no more filter but a map)
      let sorted_banks = 
        sorted_banks 
          +> List.filter (fun (path, _) -> 
            let target_bank = path.dest in
            let dist_nearest_cop = dist_nearest_cop w target_bank in
            dist_nearest_cop > 1 ##CONFIG
              ) in
            


      let (best_bank, _) = List.hd sorted_banks in
      let next_move  = List.hd best_bank.path in

      pr2 (sprintf "Plan = %s" (dump best_bank.path));

      [Move (next_move, myplayer)]
      
      
  


(*******************************************************************************)
let make_bot strat pattern deadlock = 
  {
    compute_move_robber = (fun w -> 
      ##assert_world

      let (myname, myplayer, myloc) = w.me in
      let _ = assert_equal myplayer Robber in

      pr2 "";
      pr2 "still living";
      pr2 (sprintf "I am %s with name %s, I am at:%s, round = %s" (dump myplayer) (myname) (dump myloc) (dump w.state.round_number));

      ##todo: timeout ?
      try 
        depth_handling_cops := !Flag.robber_erase_edges_radius;
        pattern w 
          (deadlock w 
             (try 
             (strat w)
             with e -> (pr2 ("EXN_STRAT1" ^ Printexc.to_string e); raise e)
             )
          ) +> random_list
      with
        e -> 
          begin
            pr2 ("EXN_1=" ^ Printexc.to_string e);
            pr2 ("TRYING AGAIN");
            try 
              depth_handling_cops := 1;
              pattern w 
                (deadlock w 
                 (try 
                   (strat w)
                 with e -> (pr2 ("EXN_STRAT2" ^ Printexc.to_string e); raise e)
                 )
                ) +> random_list
            with
              e -> 
                begin 
                  pr2 ("EXN_2=" ^ Printexc.to_string e);
                  pr2 ("TRYING ALL AROUND & SURVIVE");
                  try 
                    Bot.around_and_here w myloc myplayer 
                      +> List.map (fun loc -> Move (loc, myplayer))
                      +> pattern w 
                      +> random_list 
                  with e -> 
                    begin 
                      pr2 ("EXN_3=" ^ Printexc.to_string e);
                      pr2 ("!!!!!!!!!!!!!!!!!!!! I AM COMPLETLY LOST, !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                      ## pattern survival have not done correctly his job,  should not happen
                      pr2 ("EMERGENCY PLAN, faufileur (and pray)");

                      try 
                        ## Emergency mode !!! pas vu venir => se faufiler, essayer aller a cot� de plus loin
                        ## faufileur
                        Bot.around_and_here w myloc myplayer 
                        +> List.map (fun loc -> 
                          let nearest_cop = dist_nearest_cop w loc in
                          ##let nearest_bank = 0 in
                          let nearest_bank = dist_nearest_bank w loc in  ## faufileur2
                          (loc, nearest_cop + nearest_bank) ## ex: loc at 1 step from one cop, and 0 from bank  is very dangerous
                            )
                        +> List.sort (fun (_, dist1) (_, dist2) -> compare dist2 dist1) ## the more distance, the better for our survival
                        +> List.hd
                        +> (fun (loc, dist) -> Move (loc, myplayer))
                      with e -> 
                        begin 
                          pr2 ("EXN_4=" ^ Printexc.to_string e);
                          pr2 ("!!!!!!!!!!!!!!!!!!!! FIN DES HARRICOTS, !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                          Move (myloc , myplayer)
                        end
                    end
                end
          end
     );
  } 

let bot_dumb = make_bot strat_dumb nopattern nodeadlock
let bot_last = make_bot strat_nearest pattern deadlock




let trace_edge w x y=
  match Graph.get_edge w.map x y with
      Some FootEdge ->  pr2 (Printf.sprintf "Foot way between %s and %s\n" (print_loc x) (print_loc y))
    | Some CarEdge ->  pr2 (Printf.sprintf "Car way between %s and %s\n" (print_loc x) (print_loc y))
    | None -> pr2 (Printf.sprintf "No way between %s and %s !!!\n" (print_loc x) (print_loc y))

let bot_david n =  
        let risk = [|
	  (fun can_be_smelled dcops dme -> match dcops with 
	       Graph.I 0 -> Graph.Infty 
	     | Graph.I 1 -> Graph.Infty
	     | _ -> Graph.I 1);
	  (fun can_be_smelled dcops dme -> match dcops with 
	      Graph.I 0 -> Graph.Infty 
	    | Graph.I 1 -> if Graph.comp dme (Graph.I 4) then Graph.Infty else Graph.I 1
	    | _ -> Graph.I 1);
	  (fun can_be_smelled dcops dme -> 
	     if can_be_smelled then Graph.Infty
	     else match dcops with 
		 Graph.I 0 -> Graph.Infty 
	       | Graph.I 1 -> if Graph.comp dme (Graph.I 4) then Graph.Infty else Graph.I 1
	       | _ -> Graph.I 1)
	|] in 

  { compute_move_robber =  
      let rec aux n = fun w  -> 
	let pr3 s = pr2 (Printf.sprintf "%d: %s" w.state.round_number s) in
	let (myname, myplayer, myloc) = w.me in 
	let rec_call () = 
	  if n>0 then
	    begin
	      pr3 (Printf.sprintf "no way... I will try the level %d" (n-1));
	      aux (n-1) w
	    end
	  else
	    begin
	      pr3 "no way... (mode 0) I will wait !";
	      Move (myloc, myplayer)
	    end in
	  (match (path_handling_cops_risk w risk.(n)) with 
	       [] -> rec_call ()
	     | (b1,_)::(b2,_)::l when b1.len=0 ->
		 (pr3 "In bank !!! I go to the next bank"; Move (List.hd b2.path, myplayer))
	     | [b1,_] when b1.len=0 ->
		 (pr3 "In bank, but no way now !!!"; rec_call ())
	     | (b1,m)::(b2,_)::l when m=0->
		 (pr3 "the nearest bank is empty"; Move (List.hd b2.path, myplayer))
	     | [b1,m] when m=0 ->
		 (pr3 "Argg : no way and this bank is empty"; rec_call ())
	     | (b,m)::_ -> 
		 (pr3 "let's go to the bank !";Move (List.hd b.path, myplayer))
	  ) in
	aux n
  } 
    





