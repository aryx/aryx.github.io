open Common
open Graph

let pr2 s = 
  if !Flag.verbose 
  then Common.pr2 s
  else ()

(*******************************************************************************)
## 5 cops, 1 robbers, 6 banks 
## taux de remplissage: fast
##   cos 8 rounds to way (so in fact 3 actions per player) and cos other give 1/6 (=> stolen get 5/6 of 1000 and have same vault than 5 others) 
## robbers move at same speed of copfoot, but copcar can go "faster" because they can take shortcomings
##  (but they cant move in all directions when on pedestrian)
## 200 rounds (in fact 100 action per player)
## the robbers lets an evidence only every 8 (and disappaeared after 24 rounds)
## scoring: 
##  each bank has 1000

(*******************************************************************************)
type loc = Loc of string
     and fullloc = loc * (int * int) ##inv: between 0 and 1023

type node = Hq | Bank | Robber_start | Ordinary
type edge = CarEdge | FootEdge


(*******************************************************************************)
type playername = string

type player = Robber | Cop of copstate
     and copstate = CopCar | CopFoot



(*******************************************************************************)
type round = int ##inv: between 0 and 200



(*******************************************************************************)
type evidence = WasHereAt of round

type smell = Smll of int ##inv: 0, 1, or 2,   cant be 2 when copstate = CopCar

type certainty = Certainty of int ##negative means sure that was not here,  inv: between -100  and 100



(*******************************************************************************)
type world = {
  map: (loc, node, edge) digraph; ##inv: unique loc
  state: state;
  robber_start: loc; ## not really needed  FRED: I need this info

  ##cache:
  me: (playername * player * loc); ##dup: with cops_info or robber_loc

  ##note: added redundancy to avoid making mistakes, if want access a map, have to pass also a CarEdge or FootEdge
  map_foot:  edge -> (loc, node, edge) digraph;
  map_car:   edge -> (loc, node, edge) digraph;

  best_way_foot: edge -> (loc * loc) -> (loc list);
  best_way_car:  edge -> (loc * loc) -> (loc list);

  best_dist_foot: (loc * loc) -> int';
  best_dist_car:  (loc * loc) -> int';

  ##additional:
  (*
  current_plan:  ## if want obey other plans, have to remember other plans
  deadlock_counter:
  *)
  }   
  and state =  {
    banks_info: (loc, int) assoc;                        ##inv: lentgth keys = 6, value between 0 and 1000,  each loc different
    other_cops_info: (playername * copstate * loc) list; ##update:  keep only other cops here (if robber other = all cops)  ##inv: 5 players, 1 robber 5 cops todo: have also robber here ?
    robber_info: (playername * int * loc option);                            ##inv: between 0 and 6000

    evidence_current_node: evidence list; ## cop only
    smells_current_node:   smell;         ## cop only
    info_historic: inform_info list;     ## cop only

    round_number: round; ##inv: increment only (and 2 by 2,  for robber 0 -> 2, for cop 1 -> 3)
    
    }
  and inform_info = 
  | OtherGuess of loc * round * certainty     
  | MyGuess of loc * round * certainty  
  | VoteWinner of playername

(*******************************************************************************)
##todo: type client_msg and server_msg (and invariant is only write in client_msg, and only read in server_msg)

type register_msg = Reg of playername * player 

type world_skeleton_msg = 
    { 
      wsk_name:   playername;
      wsk_robber: playername;
      wsk_cops:   playername list; ##inv: 5 cops ? todo: have also his name here ?

      wsk_nodes: (loc * node * (int * int)) list; 
      wsk_edges: ((loc * loc) * edge) list;
    }  
        
type world_msg = 
    {
      w_round:       round;
      w_robber_butin: int;
      w_banks_butin: (loc * int) list; ##inv: 6
      w_evidence: (loc * evidence) list; ##note: list because may have been on this node at different time in the past
      w_smell: smell;
      w_players:  (playername * loc * player) list; ##todo: I think that if robber stolen, then robbername is added in this list (and also at starttime) (and also if the bot is itself the robber))
      ## FRED: I think this is wrong : the robber is never added -> I need its location - however, it is never set
    } 

type move_msg = Move of (loc * player) ##inv: cant change its copstate if not at headquarter, cant change from cop to robber


type gameover_msg = GameOver 

type inform_msg = Inform of (playername * loc * player * round * certainty) list ## inv: playername c'est robber,  (interet de savoir ou etait un cop ?) senbranle
      
type suggest_plan_msg = SuggestPlan of (playername * loc * player * round) list ## inv: playername this time must be a cop,  note that can have a list of moves (ordered moves ?)


##todo: comprend rien
type from_msg_inform = (playername * inform_msg) list
type from_msg_plan   = (playername * suggest_plan_msg) list



type voting_msg = Voting of playername list  ##inv: playername is cop,  must contain each cop name (and only cops) and only once, and order is first is better (from best to worst)

type vote_result_msg = VoteResult of voteresult 
     and voteresult = 
          | Winner of playername ##inv: playername is cop
          | NoWinner


(*******************************************************************************)
let (w: world option ref) = ref None
let myw () = some !w

type cop_engine = 
  { 
    compute_move_cop: world -> move_msg;
    (*
       but plan may be invalid
       how compute order of move commands for one robot if have multiple orders ? ... bordel  
    *)
    compute_inform:  world -> inform_msg;
    compute_plan: world -> suggest_plan_msg;
    compute_eval_plans: from_msg_plan -> world -> voting_msg;

  } 

type robber_engine = 
    {
      compute_move_robber: world -> move_msg;
    } 

let save_map m f =
  let file = open_out f in
    output_value file m;
    close_out file

let (load_map : string -> (loc, node, edge) digraph) = fun f ->
  let file = open_in f in
  let m = input_value file in
    close_in file; m

let print_loc (Loc s) = s

(*******************************************************************************)
let decode_world_skeleton msg = 

  let map = Graph.build_digraph 
      (msg.wsk_nodes +> List.map (fun (loc, _, _) -> loc))
      (msg.wsk_nodes +> List.map (fun (loc, nod, _) -> (loc, nod)))
      (msg.wsk_edges) in

##for i=0 to Array.length map.matrix -1 do
##  for j=0 to Array.length map.matrix -1 do
##    if map.matrix.(i).(j)=Some CarEdge then
##      if map.matrix.(j).(i)<>Some CarEdge then Printf.fprintf stderr "not sym in (%s,%s)\n"
##	(print_loc (Mapb.find i map.int_to_nodes))
##	(print_loc (Mapb.find j map.int_to_nodes))
##done done;

    ## save_map map "SAVE_MAP";

    ##  if copcar then can all, but must restrict directions
  let map_car = (fun edge -> 
      let _ = assert_equal CarEdge in
      Graph.build_digraph 
        (msg.wsk_nodes +> List.map (fun (loc, _, _) -> loc))
        (msg.wsk_nodes +> List.map (fun (loc, nod, _) -> (loc, nod)))
        (msg.wsk_edges)
      ) in

    ##  if copfoot (or robber) then can only pedestrian,  but without restriction on directions (=> can add arcs)
    let map_foot = (fun edge -> 
      let _ = assert_equal FootEdge in
      Graph.build_digraph 
        (msg.wsk_nodes +> List.map (fun (loc, _, _) -> loc))
        (msg.wsk_nodes +> List.map (fun (loc, nod, _) -> (loc, nod)))
        (msg.wsk_edges 
           +> List.filter (fun ((_,_), kind) -> kind = FootEdge)
           +> (fun onlyfoot -> onlyfoot @ (onlyfoot +> List.map (fun ((id1, id2), kind) -> 
                let _ = assert (kind = FootEdge) in
                ((id2, id1), kind)))
              )
        )
        ) in

    let (best_dist_foot,best_way_foot) = Graph.new_global_best_way (map_foot FootEdge) in
    let (best_dist_car,best_way_car)  = Graph.new_global_best_way (map_car CarEdge)   in

    let robber_init_loc = 
      ## FRED: I need this information 
      ## subtil: cos cop see world at n+1, the server dont tell him robber place at that moment
      ##TODO? optimise PAD: not needed
	## TODO : Are we sure that there is always a Robber_start node
	try 
	  let loc,_,_ =  List.find (fun (loc, node, _) -> node = Robber_start) msg.wsk_nodes in
	  loc
	with Not_found -> failwith "Where is the Robber_start node ?" in


  let neww = {

    map = map;
    map_car = map_car;
    map_foot = map_foot;

    best_way_foot = (fun edge (loc1, loc2) -> 
      let _ = assert (edge = FootEdge) in
      best_way_foot loc1 loc2
        );
    best_way_car  = (fun edge (loc1, loc2) -> 
      let _ = assert (edge = CarEdge) in
      best_way_car loc1 loc2
        );
 
    best_dist_car = (fun (i,j) -> best_dist_car i j);
    best_dist_foot = (fun (i,j) ->  best_dist_foot i j);

    robber_start = robber_init_loc;

    me = (msg.wsk_name, Robber (*IN FACT DONT KNOW YET, this will be set by appropriate bot *), Loc "DONTKNOWYET");
    (* FRED: ME, I KNOW, I AM THE COP *)

    state = 
    {
      banks_info = [];
      other_cops_info = msg.wsk_cops +> List.map (fun p -> (p, CopCar, Loc "NOTYET")) +> List.filter (fun (p,_,_) -> p != msg.wsk_name);
      robber_info = (msg.wsk_robber, -1 (* set after *), None (* FRED : Why not Some robber_init_loc *)
      
      ); 
      evidence_current_node = [];
      smells_current_node = Smll 0;
      info_historic = [];

      round_number = 0;

    } 
  } 
  in
  w := Some neww
    
    let my_old_pos = ref ([] : (playername * copstate * loc) list)

##todo: more assert,  such as cant have smells when is a robber
let _counter_decode_world_msg = ref 0
let decode_world_msg msg = 
  incr _counter_decode_world_msg;
  match msg with
  | Left _ -> raise Impossible
  | Right msg -> 
      let oldw = myw() in
      my_old_pos := oldw.state.other_cops_info;
      let oldstate = oldw.state in
      let (myname, myoldplayer, myoldloc) = oldw.me in

      let mynewloc = msg.w_players  ## copy paster de truc dessous
                         +> List.find (fun (p,_,_) -> p = myname) 
                         +> (fun (p, loc, player) -> loc) in

      let neww = { oldw with 
                   
                   me = msg.w_players 
                         +> List.find (fun (p,_,_) -> p = myname) 
                         +> (fun (p, loc, player) -> 
                               let _ = if !_counter_decode_world_msg > 1 then assert_equal player myoldplayer in
                               let _ = assert_equal p myname in
                               (myname, player, loc)
                            );
                   
                   state = { oldstate with 

                             round_number = msg.w_round;
                             banks_info = msg.w_banks_butin;

                             other_cops_info = msg.w_players 
                               +> List.filter (fun (p,_, player) -> p != myname && player != Robber)
                               +> List.map (fun (p, loc, player) -> 
                                 let _ = assert (p != myname) in
                                 (p, 
                                  (match player with Cop x -> x | Robber -> raise Impossible), 
                                  loc
                                 ));

                              robber_info = (fst3 oldstate.robber_info, 
                                             msg.w_robber_butin, 
                                             try 
                                               msg.w_players 
                                                 +> List.find (fun (_,_, player) -> player = Robber)
                                                 +> (fun (_,loc, player) -> let _ = assert (player = Robber) in
                                                  Some loc
                                                   )
                                             with Not_found -> None
                                             
                                             );

                                  
                             evidence_current_node = 
                                msg.w_evidence +> List.map (fun (loc, ev) -> 
                                  let _ = assert (loc = mynewloc) in
                                  let _ = if !_counter_decode_world_msg > 1 then assert (myoldplayer != Robber) in ## robber get the info too ?
                                  ev);
                                    
                             smells_current_node = msg.w_smell; 
                           } 
                 } 
      in
      w := Some neww
     ## let update_bank_amount =  1/6 ....  given by server


let is_gameover msg = 
  match msg with
  | Left _ -> true
  | Right _ -> false


(* FRED: duplicated from bot.ml dependancy pb*)
let (around: world -> loc -> player -> (loc list)) = fun w loc pl -> 
  match pl with
    | Cop CopCar -> w.map_car CarEdge +> Graph.successors loc
    | (Robber | Cop CopFoot) -> w.map_foot FootEdge +> Graph.successors loc


(*let decode_other_one_inform (msg :inform_msg) : info_historic list = 
  let other_guesses = List.fold_right (fun (pn,loc,player,rd,Certainty certainty) guesses -> 
    if rd = round -1  && player = Robber && certainty > 0 
    then (OtherGuess (loc,rd,Certainty certainty)):: guesses
    else guesses) msg [] in
  other_guesses *)


let decode_other_informs ( msg : from_msg_inform) : unit = pr2 "decode_informs_result: Nothing yet, update world"
(*  (* first, transfer my own information to the historic*)
  (* There are duplicated computations with compute_informs *)
  let oldw = myw() in    
  let (myname, myplayer, myloc) = oldw.me in
  let round = oldw.state.round_number in
  let current_evidences = List.map (fun (WasHereAt i) -> (MyGuess(myloc, i, Certainty 100))) oldw.state.evidence_current_node in
  let current_smell = 
    match oldw.state.smells_current_node with
      | Smll 0 -> []
      | Smll 1 -> let around = around oldw myloc Robber in
	let certainty = 100 / (List.length around) in
	List.map (fun loc -> MyGuess (loc, (round -1), Certainty certainty)) around
      | Smll 2 -> let around1 = around oldw myloc Robber in
	let around2 = List.fold_left (fun ar loc -> (around oldw loc Robber)@ar) [] around1 in
	let around2 = uniq around2 in
	let certainty = 100 / (List.length around2) in
	List.map (fun loc -> MyGuess (loc, (round -1), Certainty certainty)) around2
      | Smll n -> failwith "Cannot smell so far away" in
  
  let all_guesses = current_evidences@(current_smell@ (List.fold_right (fun info acc -> (decode_other_informs info)@acc) msg oldw.state.info_historic)) in

  let new_world = 
    {oldw
    with state = {oldw.state with info_historic = all_guesses}} in
  w := Some new_world
*)

let decode_vote_result obj =  pr2 "decode_vote_result: Nothing yet, update world"
 



