open Common
open Bot
open Lib

let bot_dumb = 
  {
    compute_move_cop = (fun w -> 
      Move (thd3 w.me, snd3 w.me)
    );
    compute_inform = (fun w -> Inform [])
    ;
    compute_plan = (fun w ->  SuggestPlan [])
    ;
    compute_eval_plans = (fun msg_plan w  -> Voting (List.map fst msg_plan)
      
    );
  } 



let bot_random = 
  {
    compute_move_cop = (fun w -> 
      let (myname, myplayer, myloc) = w.me in
      let around = around w myloc myplayer in
      Move (random_list around, myplayer)
    );
    compute_inform = (fun w -> Inform [])
    ;
    compute_plan = (fun w ->  SuggestPlan [])
    ;
    compute_eval_plans = (fun msg_plan w  -> Voting (

      List.sort (fun x y -> 
	let (myname, myplayer, myloc) = w.me in
	if x = myname then -1 
	else if y = myname then 1 else compare x y) (List.map fst msg_plan)))
      ;
  } 

type robber_info = 
  | RobberAt of round*loc
  | SmellAt of round*loc*int  (* int = 1 ou 2 *)

let iter_all_node (w:world) (f:loc->'b->'b) (b:'b) : 'b =
  let rec aux n =
    if n<0 then b
    else f (Mapb.find n w.map.Graph.int_to_nodes) (aux (n-1))
  in aux ((Array.length w.map.Graph.matrix)-1)

let overapproxim_robber_position : world -> round -> robber_info -> loc Setb.t = fun w myround r -> 
  let best_dist_foot (x:loc) (y:loc) : Graph.int' = 
    if x=y then (Graph.I 0)
    else w.best_dist_foot (x,y) 
  in
  match r with
      RobberAt (round,loc) -> 
	iter_all_node w 
	  (fun loc' set -> 
	     if Graph.comp (best_dist_foot loc loc') (Graph.I ((myround -1 - round)/2)) 
	     then Setb.add loc' set
	     else set)
	  Setb.empty
    | SmellAt (round,loc,d) -> 
	iter_all_node w 
	  (fun loc' set -> 
	     if Graph.comp (best_dist_foot loc loc') (Graph.I (d + (myround -1 - round)/2)) 
	     then Setb.add loc' set
	     else set)
	  Setb.empty


let bot_random_mc_gruff = 
  {
    compute_move_cop = (fun w -> 
      let (myname, myplayer, myloc) = w.me in
      let around = around w myloc myplayer in
      Move (random_list around, myplayer)
    );
    compute_inform = (fun w -> Inform [])
    ;
    compute_plan = (fun w ->  
      let plan = List.map 
      (fun (pname,state,loc) -> 
	pname, random_list (around w loc (Cop state)),Cop state ,(w.state.round_number +1)) w.state.other_cops_info  in
    SuggestPlan plan)
    ;
    compute_eval_plans = (fun msg_plan w  -> 
      let (myname, myplayer, myloc) = w.me in
      let plan  = List.sort (fun x y -> 
	if x = myname then -1 
	else if y = myname then 1 else compare x y) (List.map (fun (pl,_,_) -> pl) w.state.other_cops_info) in
      Voting plan
      
    );
  } 


let bot_starsky = 
  {
    compute_move_cop = (fun w -> 
      let (myname, myplayer, myloc) = w.me in
      let loc = starsky_position w myplayer in
      let path = my_best_path_to w loc in
      match path.path with
	| [] ->  let around = around w myloc myplayer in Move (random_list around, myplayer)
	| e::l -> Move (e, myplayer)
    );
    compute_inform = (fun w -> Inform [])
    ;
    compute_plan = (fun w ->  SuggestPlan [])
    ;
    compute_eval_plans = (fun msg_plan w  -> Voting (
      List.sort (fun x y -> 
	let (myname, myplayer, myloc) = w.me in
	if x = myname then -1 
	else if y = myname then 1 else compare x y) (List.map fst msg_plan)))
      ;
  } 





let time_to_evidence : world -> int = fun world -> 
  (* In how many rounds, the robber will leave an evidence *)
  let current = world.state.round_number in
  current mod 8

(*****)
(*
  1 - compute_move -> towards the robber
  2 - Dispatch McGuff to other banks
*)

(*type strategy =
  | BankOfRobber of loc list
  | ProtectBank of loc


let current_strat = ref ([] : (playername * strategy) list)
*)

let compute_inform : world -> inform_msg = fun w -> 
  (* I provide my evidences + smells *)
  let (myname, myplayer, myloc) = w.me in
  let (robber_name,_,_) = w.state.robber_info in
  let current_evidences = List.map (fun (WasHereAt i) -> (robber_name, myloc, Robber, i, Certainty 100)) w.state.evidence_current_node in
  let current_smell = 
    match w.state.smells_current_node with
      | Smll 0 -> []
      | Smll 1 -> let around = around w myloc Robber in
	let certainty = 100 / (List.length around) in
	List.map (fun loc -> robber_name, loc, Robber, (w.state.round_number -1), Certainty certainty) around
      | Smll 2 -> let around1 = around w myloc Robber in
	let around2 = List.fold_left (fun ar loc -> (around w loc Robber)@ar) [] around1 in
	let around2 = uniq around2 in
	let certainty = 100 / (List.length around2) in
	List.map (fun loc -> robber_name, loc, Robber, (w.state.round_number -1), Certainty certainty) around2
      |  Smll n -> failwith "Cannot smell so far away" in
  Inform (current_evidences@ current_smell)
	  

let dispatch_to_banks : world -> (playername * (path_info * int)) list = fun w -> 
  let (myname, myplayer, myloc) = w.me in
  let paths_to_banks = List.map (fun (name,banks) -> (name,sort_banks banks)) (other_cops_path_to_banks w) in
  let paths_to_banks = List.sort (fun (n,banks) (n',banks') -> compare (fst (List.hd banks)).len  (fst (List.hd banks)).len) paths_to_banks in
  let me,others = List.partition (fun (name,banks) ->  name = myname ) paths_to_banks in
  let my_bank = List.hd  (snd (List.hd me)) in
  let remove_bank bk l = 
    let bk_dest bk = (fst bk).dest in
    List.map (fun (name,banks) -> name, List.filter (fun x -> bk_dest x <> bk_dest bk) banks) l in
  let others = remove_bank my_bank others in
  let rec sort_banks = function
    | [] -> []
    | (name,banks)::l -> 
	let choice = List.hd banks in
	(name,choice)::(sort_banks (remove_bank choice l)) in 
  (fst (List.hd me),my_bank)::(sort_banks others)


let dispatch_to_banks w =
  let res = dispatch_to_banks w in
  let rec all_diff_banks = function
    | [] -> true
    | (name,bank)::l -> all_diff_banks l && not (List.mem bank (List.map snd l)) in
  if not (all_diff_banks res) then failwith (Dumper.dump res);
  res



let robber_position state : loc option  = 
    match state.robber_info with
      |  ( _,_,None) -> None
      | (_,_,Some loc) -> Some loc

type plan =  loc list

let current_plan = ref (None: path_info option )

let compute_inform w = Inform []


let forcast_bank_of_robber : world -> loc -> loc option = fun w loc -> 
  try Some (( fst (best_bank_from w Robber loc)).dest)
  with Not_found -> failwith "forcast_bank_of_robber"
    (*
    None *)

let strategy_from_robber : world -> loc option -> unit = fun w oloc -> 
  let (myname, myplayer, myloc) = w.me in
  match oloc with
    | None -> ()(* Keep the current plan *)
    | Some loc -> 
	match forcast_bank_of_robber w  loc with
	    None -> ()
	  | Some goal -> current_plan := Some (my_best_path_to w goal)


let robber_position : world -> loc option = fun w -> 
    (if w.state.round_number = 1 
    then Some w.robber_start
    else robber_position w.state)



let compute_plan w = 
  (* I decide my own plan *)
  strategy_from_robber w (robber_position w);
  (* Others are dispatched *)
  let other_goals = dispatch_to_banks w in
  let plan = (* You guys, protect the banks *)
    List.map 
      (fun (pname,state,loc) -> 
	let your_path = List.assoc pname other_goals in
	pname,
	(match (fst your_path).path with
	  | [] -> loc
	  | [e] -> e
	  | e1::l -> e1), Cop state, (w.state.round_number +1)) w.state.other_cops_info in
  SuggestPlan plan

let compute_eval_plans  = (fun msg_plan w  -> Voting (List.map fst msg_plan))

(** TODO.
  The McGruff should have MY strategy - execpt a priority for me
  The evidence + smell should be used
**)

let compute_move_cop = fun w -> 
  let (myname, myplayer, myloc) = w.me in
  let move =  
    match !current_plan with
      | None -> failwith "!! I do not have a plan";	
      | Some info -> 
	  pr2 (Dumper.dump myloc); pr2 (Dumper.dump info);
	  let pi = follow_path info in
	  current_plan := Some pi;
	  Move (pi.start,myplayer)in

  safe_move w myloc myplayer move


let bot_to_bank = 
  {
    compute_move_cop =  compute_move_cop
    ;
    compute_inform = compute_inform
    ;
    compute_plan = compute_plan ;

    compute_eval_plans = compute_eval_plans
    ;
  } 


(*******************************************************************************)
(* Version with redispatch at each step trying to foresee the target of robber *)

(* For each bank, it computes an estimate on the number of steps needed to reach it *)

type bank_status = { 
  robber_path : path_info ; ## I could try to intercept;
  time_to_bank : int ; ## If the robber takes the shortest path -> path.len
  bank_unguarded: int ; ## number of round without a cop around
}

let optimistic_robber_to_banks = ref ([] : bank_status list)

let optimistic_cops_to_banks = ref ([] : (playername * (path_info list)) list) (* McGruff are a best case, they always obey orders*)

type strategy = 
  | GoBank of path_info ## Guys, go to bank and protect it


let update_time_unguarded : world -> path_info -> int = fun w pi ->
  if Botrobber.dist_nearest_cop w pi.dest >1
  then (
    try 
      let bk = List.find (fun bk_st -> bk_st.robber_path = pi) !optimistic_robber_to_banks in
      bk.bank_unguarded + 1
    with Not_found -> 1)
  else 0

let optimistic_plan = ref ([] : (playername * strategy) list)
let last_robberies = ref ([]:(loc * round) list)

let init_bank_status_from_path_info : world -> (path_info*int) list -> bank_status list = fun w banks -> 
  List.map (fun (x,_) -> {
    robber_path = x; 
    time_to_bank = x.len + 
    (try  
      let t = List.assoc x.dest !last_robberies in
      if (t + 8 <= w.state.round_number)
      then w.state.round_number - t
      else 0
    with Not_found -> 0);
    bank_unguarded = update_time_unguarded w x}) banks


let rec fold_follow k bankstatus =
  match k with
    |0 -> bankstatus
    |n -> fold_follow (k-1) 
       {
	 robber_path = follow_path bankstatus.robber_path;
	 time_to_bank =  (bankstatus.time_to_bank -1);
	 bank_unguarded = bankstatus.bank_unguarded ; ## BOF
       }



let update_robber_to_banks : world -> unit = fun w -> 
  let (myname, myplayer, myloc) = w.me in
  match robber_position w with
    | None -> 
	(* Fst, deal with smells *)
	(match w.state.smells_current_node with
	  | Smll 0 -> ()
	  | Smll x -> let (myname, myplayer, myloc) = w.me in (* This is nearly myloc *)
	    optimistic_robber_to_banks := init_bank_status_from_path_info w (path_to_banks w myloc Robber)
	);     
	(* Then, evidences *)
	(let evs = w.state.evidence_current_node in
	let evs = List.sort (fun x y -> -(compare x y)) evs in (* most recent first *)
	if List.length evs > 1
	then optimistic_robber_to_banks := init_bank_status_from_path_info w (path_to_banks w myloc Robber)
	else 
	  match evs with
	    | [] -> ()
	    | (WasHereAt i)::l -> (assert (l = []));
		let approx_i = init_bank_status_from_path_info w (path_to_banks w myloc Robber) in
		let round = w.state.round_number in
		optimistic_robber_to_banks := List.map (fold_follow (round - i)) approx_i
	)
    | Some v -> 
	last_robberies := (v,w.state.round_number)::!last_robberies;
	optimistic_robber_to_banks := init_bank_status_from_path_info w (path_to_banks w v Robber)


let update_cops_to_banks : world -> unit = fun w -> 
  optimistic_cops_to_banks := List.map (fun (x,banks) -> (x, List.map (fun (bk,i) -> bk) banks)) (other_cops_path_to_banks w) 



let forcast_bank_of_robber2 : world -> path_info = fun w -> 
  let l = List.sort (fun j j' -> compare j.time_to_bank j'.time_to_bank) !optimistic_robber_to_banks in
  let the_best = (List.hd l).robber_path in
  the_best


(* Here, I try to reduce my movement *)
(*let forcast_bank_of_robber2 : world -> path_info = fun w -> 
  let l = List.sort (fun j j' -> compare j.time_to_bank j'.time_to_bank) !optimistic_robber_to_banks in
  let l' = List.filter (fun x ->  Botrobber.dist_nearest_cop w x.robber_path.dest >1) l in
  match l' with
    | [] -> (List.hd l).robber_path
    | l' -> try 
	(List.find (fun x -> x.time_to_bank =0 ) l').robber_path
      with
	  Not_found -> (List.hd l).robber_path



let forcast_bank_of_robber2 : world -> path_info = fun w -> 
  match robber_position w with
      None ->  (List.hd !optimistic_robber_to_banks).robber_path
    | Some v -> 
	try
	  (List.find (fun x -> x.robber_path.dest = v) !optimistic_robber_to_banks).robber_path
      with
	  Not_found -> (List.hd !optimistic_robber_to_banks).robber_path

*)



let next_move w (pname,myplayer,myloc) plan = 
  let your_path = List.assoc pname plan in
  let your_next_loc = (follow_path (match your_path with GoBank pi -> pi)).start in
  if your_next_loc = myloc 
  then       
    let around = around w myloc myplayer in
    random_list around
  else 
    your_next_loc


type cop = Hint of bool | Deploy_5 of bool


let last_robber = ref (None: robber_info option)


let current_robber_info w :  robber_info option = 
  let round = w.state.round_number in
  let (myname, myplayer, myloc) = w.me in
  (if round = 1 
  then Some (RobberAt (round,w.robber_start))
  else 
    match robber_position w with
      | None -> 
	  (match w.state.smells_current_node with
	    | Smll 0 -> None
	    | Smll 1 -> Some (SmellAt(round, myloc,1))
	    | Smll 2 -> Some (SmellAt(round, myloc,2))
	    | _ -> None)
      | Some loc -> Some (RobberAt(round,loc))
  )

let compute_optimistic_plan : cop -> world -> suggest_plan_msg = fun cop w -> 
  let deploy_5 = 
    match cop with 
      |Hint x -> false
      | Deploy_5 x -> true in
  let smell = 
    match cop with 
      | Hint x -> x
      | Deploy_5 x -> x in
  update_robber_to_banks w;
  update_cops_to_banks w;
  pr2 (Dumper.dump (!optimistic_cops_to_banks));
  let (myname, myplayer, myloc) = w.me in

  let paths_to_banks = List.map (fun (name,banks) -> (name,sort_banks banks)) (other_cops_path_to_banks w) in
  let paths_to_banks = List.sort (fun (n,banks) (n',banks') -> compare (fst (List.hd banks)).len  (fst (List.hd banks)).len) paths_to_banks in

  let remove_bank bk (l:(playername*path_to_banks) list) : (playername* path_to_banks) list = 
    let bk_dest bk = (fst bk).dest in
    List.map (fun (name,banks) -> name, List.filter (fun x -> bk_dest x <> bk.dest) banks) l in

  let my_bank = (** It is mitigated with the smell *)
    if not smell then my_best_path_to w (forcast_bank_of_robber2 w).dest
    else
      let bank =  my_best_path_to w (forcast_bank_of_robber2 w).dest in
      let approx = match current_robber_info w , !last_robber with
	| None , None -> None
	| Some i1, Some i2 ->  
	    last_robber := Some i2;
	    Some 
	    (Setb.inter (overapproxim_robber_position w w.state.round_number i1) (overapproxim_robber_position w w.state.round_number i2))
	| None , Some i ->  Some (overapproxim_robber_position w w.state.round_number i)
	| Some i,   None -> None
      in
      match approx with
	| None -> bank
	| Some approx -> 
	    let around = around w myloc Robber in
	    let around' = List.filter (fun loc -> not (List.exists (fun (pn,cs,loc') -> loc' = loc) !my_old_pos)) around in
	    let pos = 
	      try 
		random_list (List.filter (fun loc -> Setb.mem loc approx) around') ## works if smell is 1
	      with _ -> 
		try random_list  around' with ## if smell is 2 it could be improved
		    _ -> List.hd around in
	    my_best_path_to w pos in
  let others = 
    let others = (remove_bank my_bank paths_to_banks) in
    if deploy_5 
    then
      let worse_bank =   
	let l = List.sort (fun pi pi' -> compare pi'.time_to_bank pi.time_to_bank ) !optimistic_robber_to_banks 
	in  ( (List.hd l)).robber_path in
      List.filter (fun (name, _) -> name <> myname) (remove_bank worse_bank others)
    else others in
  let rec (sort_banks: (playername * path_to_banks) list -> (playername * path_info) list)  = function
    | [] -> []
    | (name,banks)::l -> 
	let choice = fst (List.hd banks) in
	(name,choice)::(sort_banks (remove_bank choice l)) in 
  let plan =   (myname,GoBank my_bank)::(List.map (fun (n,b) -> n,GoBank b) (sort_banks others)) in
  optimistic_plan := plan;
  (* Build message from plan *)
  let plan = List.map (fun (pname,state,loc) ->  
    (pname, next_move w (pname, Cop state, loc) plan ,Cop state,(w.state.round_number +1))) w.state.other_cops_info in
  SuggestPlan plan
    

let sort_I_am_the_best w x y = 
  let (myname, myplayer, myloc) = w.me in
  if x = myname then -1
  else if y = myname then 1
  else compare x y


let compute_eval_plans  = (fun msg_plan w  -> Voting (List.sort (sort_I_am_the_best w) (List.map (fun (x,y,z) -> x) w.state.other_cops_info)))


let compute_move_cop =  (fun w ->  
  let (myname, myplayer, myloc) = w.me in
  Move (next_move w w.me !optimistic_plan, myplayer))

  

let bot_forecast = 
  {
    compute_move_cop =  compute_move_cop
    ;
    compute_inform = compute_inform
    ;
    compute_plan = compute_optimistic_plan (Hint false);

    compute_eval_plans = compute_eval_plans
    ;
  } 


let bot_forecast_5 = 
  {
    compute_move_cop =  compute_move_cop
    ;
    compute_inform = compute_inform
    ;
    compute_plan = compute_optimistic_plan (Deploy_5 false);

    compute_eval_plans = compute_eval_plans
    ;
  } 


let bot_forecast_5_smell = 
  {
    compute_move_cop =  compute_move_cop
    ;
    compute_inform = compute_inform
    ;
    compute_plan = compute_optimistic_plan (Deploy_5 true);

    compute_eval_plans = compute_eval_plans
    ;
  } 







