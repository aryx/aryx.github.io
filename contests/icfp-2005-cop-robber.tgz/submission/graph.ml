open Common

type ('idnode, 'node, 'edge) digraph = ##('idnode * 'node * 'edge) list
      {
        nodes: ('idnode, 'node) Mapb.t;      
        nodes_to_int: ('idnode,  int) Mapb.t;
        int_to_nodes: (int, 'idnode) Mapb.t; 
        matrix: ('edge option) array array;
      } 
 

let (build_digraph: ('idnode list) -> (('idnode, 'node) assoc) -> ((('idnode * 'idnode) * 'edge) list) -> ('idnode, 'node, 'edge) digraph)  = fun idnodes nodes edges -> 
  let _ = assert_equal (length idnodes) (length nodes) in
  let dims = length idnodes in
  let association = zip nodes (enum 0 (dims -1)) in
  let newnodes = 
    association +> fold_left (fun a ((id, nod), i) -> 
      Mapb.add id nod a
    ) Mapb.empty in
  let nodes_to_int = 
    association +> fold_left (fun a ((id, nod), i) -> 
      Mapb.add id i a
    ) Mapb.empty in
  let int_to_nodes = 
    association +> fold_left (fun a ((id, nod), i) -> 
      Mapb.add i id a
    ) Mapb.empty in
  let convert id = Mapb.find id nodes_to_int in
    
  let matrix = Array.make_matrix dims dims None in
  edges +> List.iter (fun ((id1, id2), edge) -> 
    let i1 = convert id1 in
    let i2 = convert id2 in 
    matrix.(i1).(i2) <- Some edge
    );
  { 
    nodes = newnodes;
    nodes_to_int = nodes_to_int;
    int_to_nodes = int_to_nodes;
    matrix = matrix;
  } 

let array_foldi = fun f a arr -> 
  let res = ref a in
  arr +> Array.iteri (fun i v -> 
    res := f !res (i, v)
    );
  !res

let (successors: 'idnode -> ('idnode, 'node, 'edge) digraph -> 'idnode list) = fun id g -> 
  let i = Mapb.find id g.nodes_to_int in
  let arr = g.matrix.(i) in 
  arr +> array_foldi (fun a (j, v) -> 
    if v = None 
    then a
    else j::a
                     ) []
    +> List.map (fun j -> Mapb.find j g.int_to_nodes)
  
  

let (copy_matrix: 'a array array -> 'a array array) = fun m -> 
  let l = Array.length m in
  if l = 0 then m else
  let result = Array.make l m.(0) in
  for i = 0 to l - 1 do
    result.(i) <- Array.copy m.(i) 
  done;
  result




let (erase_edges_containing: ('idnode list) -> ('idnode, 'node, 'edge) digraph -> ('idnode, 'node, 'edge) digraph) = fun ids g -> 
  let newmatr = copy_matrix g.matrix in
  let _update_matrix = 
    ids 
      +> List.map (fun id -> Mapb.find id g.nodes_to_int) 
      +> List.iter (fun i -> 
          newmatr.(i) +> Array.iteri (fun j e -> newmatr.(i).(j) <- None);
          newmatr     +> Array.iteri (fun j e -> newmatr.(j).(i) <- None)
          ) in
  { g with
    matrix = newmatr
  } 
        
        

let ex_graph1 = 
  build_digraph 
    ["a";"b";"c";"d";"e"] 
    [("a", "a node"); ("b", "b node"); ("c", "c node"); ("d", "d node"); ("e", "e node")]
    [
      (("a", "b"), "edge1");
      (("b", "a"), "edge2");
      (("b", "c"), "edge3");
      (("c", "d"), "edge4");
      (("d", "e"), "edge5");
      (("a", "e"), "edge6");
    ] 


(* test: 
let _ = pr2 (Dumper.dump (successors "a" ex_graph1))
let _ = pr2 (Dumper.dump ex_graph1.int_to_nodes)

let _ = pr2 (Dumper.dump  ex_graph1.matrix)
let _ = pr2 (Dumper.dump ((erase_edges_containing ["b"] ex_graph1).matrix))

let get_edge = fun (x, y) graph -> 
  raise Todo

*)

let get_edge : ('loc, 'node, 'edge) digraph -> 'loc -> 'loc -> 'edge option = fun g x y ->
  g.matrix.(Mapb.find x g.nodes_to_int).(Mapb.find y g.nodes_to_int)

    
  type int' = Infty | I of int

  let (add : int' -> int' -> int') = fun x y ->
    match (x,y) with
	(Infty,_) -> Infty
      | (_,Infty) -> Infty
      | (I x,I y) -> I (x+y)
	  
  let (min : int' -> int' -> int') = fun x y ->
    match (x,y) with
	(Infty,_) -> y
      | (_,Infty) -> x
      | (I x,I y) -> I (min x y)

  let (comp : int' -> int' -> bool) = fun x y -> (* x <= y *)
    match (x,y) with
	(_,Infty) -> true
      | (I x,I y) -> x<=y
      | _ -> false
	  
  let (matrix_copy : 'a array array -> 'a array array)  = fun m ->
    Array.init (Array.length m) (fun i -> Array.copy m.(i))
      
  let (matrix_copy_map : (int -> int -> 'a -> 'b) -> 'a array array -> 'b array array)  = fun f m ->
    (* precondition : m is a square matrix *)
    let size = Array.length m in
      Array.init size
	(fun i -> Array.init size
	   (fun j -> f i j m.(i).(j)))

  let (matrix_bool2int : bool array array -> int' array array) =
    matrix_copy_map 
      (fun i j x ->
	 if i=j then I 0
	 else if x then I 1 
	 else Infty)
      
  let (matrix_bool2intoption : bool array array -> int option array array) = 
    matrix_copy_map
      (fun i j x -> 
	 if i=j then None
	 else if x then Some i
	 else None)
      
  let (floyd_warshall : bool array array -> int' array array * int option array array) = fun m ->
    let t = matrix_bool2int m in
    let p = matrix_bool2intoption m in
    let n = Array.length m -1 in
    for k=0 to n do
      for i=0 to n do
	for j=0 to n do
	  let b = (add t.(i).(k) t.(k).(j)) in
	    if not (comp t.(i).(j) b) then
	      begin
		t.(i).(j) <- b;
		p.(i).(j) <- p.(k).(j)
	      end
	done      
      done      
    done;
      t,p

  let (best_way : int option array array -> int -> int -> int list) = fun p i j ->
    let rec aux j acc =
      let k = p.(i).(j) in
	match k with
	    None -> 
              if i = j 
              then [i]
              else failwith "graph: best_way, impossible"
	  | Some k ->if k=i then acc else aux k (k::acc) 
    in aux j [j]


let (new_global_best_way : ('loc, 'node, 'edge) digraph -> 
 ('loc -> 'loc -> 'int) * ('loc -> 'loc -> 'loc list)) =
  fun m ->
    let mb = matrix_copy_map 
	       (fun i j x -> x<>None)
	       m.matrix in
    let (dist,way) = floyd_warshall mb in
      ((fun n_start n_end ->
	  dist.(Mapb.find n_start m.nodes_to_int).(Mapb.find n_end m.nodes_to_int))
	 ,(fun n_start n_end ->
	     let w = best_way way 
		       (Mapb.find n_start m.nodes_to_int)
		       (Mapb.find n_end m.nodes_to_int) in
	       List.map (fun i -> Mapb.find i m.int_to_nodes) w))

let global_best_way g = snd (new_global_best_way g)

(* usage :
  let best_way_foot = global_best_way gr in
   let w1 = best_way_foot n1 n2;
   let w2 = best_way_foot n3 n4;
   let w3 = best_way_foot n5 n6; ... *)

let (min_list : ('a -> 'a -> bool) -> 'a list -> 'a * 'a list) = 
  fun comp l ->
    let rec (aux : 'a list -> 'a * 'a list) = function
	[] -> failwith "min_list : nil impossible"
      | [a] -> a,[]
      | a::q -> let (min,rest) = aux q in
	  if comp a min then (a,q)
	  else (min,a::rest)
    in aux l
      

type dijk_t = { index : int; mutable d : int'; mutable p : int option }

let (init_dijkstra : int -> int' array array -> dijk_t array) = fun v g ->
  (* g : square matrix *)
  let n = Array.length g in
  let t = Array.init n (fun i -> { index = i; d = Infty; p = None }) in
    t.(v).d <- I 0;
    t

let ex2 = [|
 [| I 0 ; I 1 ;Infty; I 2 |];
 [|Infty; I 0 ;Infty; I 1 |];
 [|Infty; I 1 ; I 0 ;Infty|];
 [| I 2 ;Infty;Infty; I 0 |];
|]

let (relache_dijkstra : dijk_t -> dijk_t -> int' array array -> unit) =
  fun u v g ->
    let x = add u.d g.(u.index).(v.index) in
      if not (comp v.d x) then
	begin
	  v.d <- x;
	  v.p <- Some u.index
	end

let (create_file : dijk_t array -> dijk_t list) = Array.to_list

let print_int' = function
    Infty -> "+oo" | I k -> Printf.sprintf "%3d" k
let print_into = function
    None -> "_|_" | Some k -> Printf.sprintf "%3d" k

let print_dij t = 
  Array.fold_right (fun a r -> Printf.sprintf "|%d:%s%s" a.index (print_into a.p) r) t "|\n"

let (dijkstra : int' array array -> int -> int' array * int list option array) = fun g start ->
  let dij = init_dijkstra start g in
  let n = Array.length g in
  let rec aux = function
      [] -> ()
    | f -> (* print_string (print_dij dij); *)
	let (u,f') = min_list (fun x y -> comp x.d y.d) f in
	  Array.iteri 
	    (fun j d -> if d<>Infty then relache_dijkstra u dij.(j) g)
	    g.(u.index);
	  aux f'
  in
  let rec best_way j acc =
    match dij.(j).p with
	None -> None
      | Some k -> if k=start then Some acc else best_way k (k::acc)
  in
    aux (create_file dij);
    Array.init n (fun i -> dij.(i).d),
    Array.init n (fun i -> best_way i [i])

let (build_dist_matrix : ('loc, 'node, 'edge) digraph -> int' array array) = fun g ->
  Array.mapi 
    (fun i t ->
       Array.mapi
	 (fun j e ->
	    if i=j then I 0
	    else if e<>None then I 1
	    else Infty) t) g.matrix

(* let _ = dijkstra ex3 0 *)

exception NoWay

let (local_best_way : ('loc, 'node, 'edge) digraph -> 'loc -> 'loc -> 'loc list) =
  fun m n_start ->
    let (d,w) = dijkstra (build_dist_matrix m) (Mapb.find n_start m.nodes_to_int) in
      fun n_end -> 
	match w.(Mapb.find n_end m.nodes_to_int) with
	    None -> raise (*toto*)NoWay
	  | Some l -> List.map (fun i -> Mapb.find i m.int_to_nodes) l

let (build_dist_matrix_risk : ('loc, 'node, 'edge) digraph -> 
                              (bool -> int' -> int' -> int') ->
                               bool array -> int' array -> int' array ->
                               int' array array) = fun g risk t_smell t_risk t_dist ->
  Array.mapi 
    (fun i t ->
       Array.mapi
	 (fun j e ->
	    if i=j then I 0
	    else if e<>None then risk t_smell.(j) t_risk.(j) t_dist.(j)
	    else Infty) t) g.matrix

let (local_best_way_with_risk : ('loc, 'node, 'edge) digraph -> 
                                (bool -> int' -> int' -> int') ->
                                bool array -> int' array -> int' array -> 'loc -> 'loc -> 'loc list) =
  fun m risk t_smell t_risk t_dist n_start ->
    let (d,w) = dijkstra
		  (build_dist_matrix_risk m risk t_smell t_risk t_dist)
		  (Mapb.find n_start m.nodes_to_int) in
      fun n_end -> 
	match w.(Mapb.find n_end m.nodes_to_int) with
	    None -> raise (*toto*)NoWay
	  | Some l -> List.map (fun i -> Mapb.find i m.int_to_nodes) l

