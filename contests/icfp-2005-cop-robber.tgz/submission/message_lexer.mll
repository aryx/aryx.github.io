{                                                                                           
type token =
  | EOL
  | CLOSEBANNER of string
  | OPENBANNER of string
  | TOK of string
  | TAG of string


let remove_last lexbuf = 
  let lex = (Lexing.lexeme lexbuf) in
  String.sub lex 0 ((String.length lex) -1)
}                                                                                           

let openbanner = ['a'-'z''A'-'Z']+ '\\'
let closebanner = ['a'-'z''A'-'Z']+ '/'
let tag  = ['a'-'z''A'-'Z']+':'
let tok = ['-''a'-'z''A'-'Z''0'-'9''_''#''('')']+
let eol = "\r\n" | '\n'


rule token = parse                                                                          
| [' ' '\t']     { token lexbuf }     (* skip blanks *)
| eol {EOL}
| closebanner {CLOSEBANNER (remove_last lexbuf)}
| openbanner  {OPENBANNER (remove_last lexbuf)}
| tag {TAG (remove_last lexbuf)}
| tok {TOK ( (Lexing.lexeme lexbuf))} 

