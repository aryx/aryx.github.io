open Lib

let main =
Bot.robber (Reg (("Aryx-Robber-" ^ "david_2_"), Robber))
 (Botrobber.bot_david 2)
