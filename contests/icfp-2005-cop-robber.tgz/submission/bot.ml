open Common

open Lib

let (around: world -> loc -> player -> (loc list)) = fun w loc pl -> 
  match pl with
    | Cop CopCar -> w.map_car CarEdge +> Graph.successors loc
    | (Robber | Cop CopFoot) -> w.map_foot FootEdge +> Graph.successors loc

let (around_and_here: world -> loc -> player -> (loc list)) = fun w loc pl -> 
  loc::(around w loc pl)

let safe_move : world -> loc -> player -> move_msg  -> move_msg =   fun w  loc  pl  (Move (loc',pl')) -> 
  if pl <> pl'
  then failwith "TODO: Hq transportation change"
  else
    let around = around w loc pl in
    if (List.mem loc' around && pl = pl') or loc = loc'
    then Move (loc',pl')
    else (pr2 "EXN: Bad move, TOFIX DEVRAIT PAS ARRIVER PUTAIN"; Move(loc,pl))


type path_info = {
  start : loc ; 
  dest : loc ; 
  player: player;
  len : int ; 
  path : loc list (* dest is the last loc of path *)
}

let best_path (w:world) (start: loc) (dest:loc) (pl:player) : path_info =
  let path =
    match pl with
      | Cop CopCar -> w.best_way_car CarEdge (start,dest)
      |   pl -> w.best_way_foot FootEdge (start,dest) in
  {
    start = start ; 
    dest = dest; 
    player = pl ; 
    path =  path ;
    len = List.length path;
  }


let my_best_path_to (w:world) (dest:loc) : path_info =
  let (myname, myplayer, myloc) = w.me in
  best_path w myloc dest myplayer


let (dist_path: world -> (loc * loc) -> player -> int) = fun w (start, dest) pl -> 
  (best_path w start dest pl).len


type path_to_banks = (path_info * int) list

let path_to_banks (w:world) (start:loc) (pl:player) : path_to_banks  =
  List.map (fun (loc, m) ->  (best_path w start loc pl, m)) w.state.banks_info

let my_path_to_banks : world ->  path_to_banks = fun w -> 
  let (myname, myplayer, myloc) = w.me in
  path_to_banks w myloc myplayer


let (sort_banks: path_to_banks -> path_to_banks) = fun dist_banks -> 
  List.sort (fun (a,_) (b,_) -> compare a.len b.len) dist_banks 
    +> (fun l -> assert (List.length l = List.length dist_banks); l)

let path_to_banks (w:world) (start:loc) (pl:player) : path_to_banks  =
  List.map (fun (loc, m) ->  (best_path w start loc pl, m)) w.state.banks_info

let best_bank_from : world -> player -> loc -> path_info *int = fun w pl loc -> 
  List.hd (sort_banks (path_to_banks w loc pl))
   


let other_cops_path_to_banks  : world -> (playername * path_to_banks)list  = fun w -> 
  List.map (fun (name,state,loc) -> (name , (path_to_banks w loc (Cop state)))) w.state.other_cops_info

let is_bank_loc : world -> loc -> bool  = fun w loc -> 
  try 
    ignore (List.assoc loc w.state.banks_info) ; true
  with Not_found -> false


let is_bank : world -> loc -> int option  = fun w loc -> 
  try 
    let i= (List.assoc loc w.state.banks_info) in
    if i = 0 ## can be twicked
    then None
    else Some i
  with Not_found -> None


let starsky_position : world -> player -> loc = fun w pl ->
  let banks = w.state.banks_info in
  let all_pairs = get_pair banks in
  let dists = List.map (fun ((b1,v1),(b2,v2)) -> best_path w b1 b2 pl )  all_pairs in
  pr2 ("STARSKY:"^ (Dumper.dump dists));
  let path = List.hd (List.sort (fun x y -> compare x.len y.len) dists) in
  let middle =(path.len+1) / 2 in
  let rec get k l = 
    match k with
      | 0 -> List.hd l
      | n -> get (k-1) (List.tl l) in
  get (middle-1) path.path


let follow_path : path_info -> path_info = fun pathi -> 
  if pathi.start = pathi.dest
  then pathi (* Do not move *)
  else {pathi with start = List.hd pathi.path ; path = List.tl pathi.path ; len = pathi.len -1} 
    



(*******************************************************************************)
## send_... receive_....  decode_... compute_...

let robber name botrobber = 
  begin
    Comm.send_register_msg name;
    let skeleton_msg = Comm.receive_world_skeleton() in
    ##Unix.sleep 2;  ##seems can here, strange
    decode_world_skeleton(skeleton_msg);
    while true do
      let msg = Comm.receive_msg_gameover_or_world_msg() in
      if is_gameover (msg) 
      then exit 0 ##todo: failwith "gameover"
      else 
        begin 
          ##Unix.sleep 2;  ##seems can here, strange
          decode_world_msg(msg);
          let move = botrobber.compute_move_robber (myw()) in ## BIGFUNCTIONNNNNNNNNNNNNNNNNNNNNNNNNN
          Comm.send_move_msg(move);
        end
    done
  end


          

    
let cop name botcop = 
   begin
      Comm.send_register_msg name;
      let skeleton_msg = Comm.receive_world_skeleton() in
      ##Unix.sleep 1;  ##seems can here, strange
      decode_world_skeleton(skeleton_msg);
      while true do
        let msg = Comm.receive_msg_gameover_or_world_msg() in
          if is_gameover(msg)
          then exit 0 ##todo: failwith "gameover"
          else
            begin
              ##Unix.sleep 1;  ##seems can here, strange
              decode_world_msg(msg);
              let inform = botcop.compute_inform (myw()) in 
              Comm.send_inform_msg(inform);
              let other_informs = Comm.receive_from_inform_msg() in
              decode_other_informs(other_informs); 
              let plan = botcop.compute_plan (myw()) in
              Comm.send_plan_msg(plan);
              let other_plans = Comm.receive_from_plan_msg() in
              let choice = botcop.compute_eval_plans (other_plans) (myw()) in
              Comm.send_vote_msg(choice);
              let vote_result_msg = Comm.receive_vote_res_msg() in
              ## with vote_result_msg and other_plans know what is the winning (assoc playername with corresponding plan)
              decode_vote_result(vote_result_msg); ## normally nothing
              let move = botcop.compute_move_cop (myw()) in  ## BIGFUNCTIONNNNNNNNNNNNNNNNNNNNNNNNNN
              Comm.send_move_msg(move);
            end
      done
   end

