binaries are included (two sets cop/robber)
make should also work 


teamname:
 francois-toulour

members:
 Yoann Padioleau     (padiolea@irisa.fr)
 David Pichardie     (david.pichardie@irisa.fr)
 Frederique Besson   (fbesson@irisa.fr)

special guest:

idea: 

algo:


  
  
