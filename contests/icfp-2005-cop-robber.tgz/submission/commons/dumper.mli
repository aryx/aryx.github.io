(* Dump an OCaml value into a printable string.
 * By Richard W.M. Jones (rich@annexia.org).
 * $Id: dumper.mli,v 1.1.1.1 2005/06/22 15:07:55 cvsguy Exp $
 *)

val dump : 'a -> string
