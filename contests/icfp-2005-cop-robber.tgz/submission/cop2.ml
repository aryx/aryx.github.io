open Lib

let main = 
Bot.cop (Reg(("BAryx-Cop-" ^ "smell"), Cop CopFoot)) 
  (Botcop.bot_forecast_5_smell) ## FRED: CopCar -> CopFoot



