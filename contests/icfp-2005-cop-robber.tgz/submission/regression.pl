#!/usr/bin/perl

# 1 deploy_hint + 4 mcgruffs

#flag launch_with_gui ??
#my $GUI_SERVER_OPTION
#my $WRAPPER_ROBBER_GUI_OPTION

my $bot_path = "$ARGV[0]";
#old: my $bot_path = "/home/pad/lfs_icfp/main.nc";

#my $robber1   = "\"$bot_path -robber BEST _\"";
#my $robber2   = "\"$bot_path -robber BEST _\"";
my $robber_pad   = "\"$bot_path -robber BEST _\"";
my $robber_david2 = "\"$bot_path -robber david_2_ _\"";
my $robber_david1 = "\"$bot_path -robber david_1_ _\"";
my $robber_david0 = "\"$bot_path -robber david_0_ _\""; # 0 is better

my $cop_deploy_smell_car = "\"$bot_path -cop deploy_smell_car _\"";
my $cop_deploy_smell = "\"$bot_path -cop deploy_smell _\"";
my $cop_deploy_5 = "\"$bot_path -cop deploy_5 _\"";
my $cop_deploy_hint = "\"$bot_path -cop deploy_hint _\"";
my $cop_deploy_chase = "\"$bot_path -cop deploy_chase _\"";
my $cop_random = "\"$bot_path -cop rand _\"";

my $mcgruff = "mcgruff";

sub launch_one_exp { 
    my ($command_bots, $command_robber) = @_;
    print "./server $command_bots  --robber $command_robber\n";
    system("./server $command_bots --robber $command_robber");
    #parse
    #add score
    #check condition print command line
}

#my $COUNT_REPEAT = 4; # try multiple times the same,  cos have a random
my $COUNT_REPEAT = 3; # try multiple times the same,  cos have a random

my $COUNT_TO_X_BOTS = 5;

# try most dangerous first,  can filter  some and see if score change
my @opponents = ($cop_deploy_smell, $cop_deploy_smell_car,   $cop_deploy_5, $cop_deploy_hint, $cop_deploy_chase, $cop_random);
my @robbers =  ($robber_david2, $robber_pad, $robber_david1, $robber_david0);


# get stdout line
# parse score
#  while /x
# print if one round die (and print command line)
#  detect robber = 0
# score robber 
#  take current robber minus add all cops (only of course if score robber > 0)
#  sum score
# score cop
#  sum score
# report

# for i = 0 to 5 (and add each race)
# then try mix

my $scoreh = {};

# print if deadlock (CANT YEY)
# print of with less good level robber/cop,  get better result

##old: my $copA = $cop_deploy_hint;

##my $copA = $cop_deploy_5;
foreach my $what_cop (@opponents) {
    my $copA = $what_cop;
    print "AGAINST COP: $copA\n";
    for (my $more_bots = 1; $more_bots < $COUNT_TO_X_BOTS ; $more_bots++) {
        my $command_bots = "";
        if ($more_bots == 0) {
            $command_bots = "                                                                   --copE $mcgruff";
        } elsif ($more_bots == 1) {
            $command_bots = "--copA $copA                                                       --copE $mcgruff";
        } elsif ($more_bots == 2) {
            $command_bots = "--copA $copA --copB $copA                                          --copE $mcgruff";
        } elsif ($more_bots == 3) {
            $command_bots = "--copA $copA --copB $copA --copC $copA                             --copE $mcgruff";
        } elsif ($more_bots == 4) {
            $command_bots = "--copA $copA --copB $copA --copC $copA --copD $copA                --copE $mcgruff";
        } elsif ($more_bots == 5) {
            $command_bots = "--copA $copA --copB $copA --copC $copA --copD $copA --copE $copA"                  ;
        }

        #old: my $command_bots = "--copA $copA --copB $copA --copC $copA --copD $copA --copE $mcgruff";
        #my $command_robber = "$robber_pad";
        foreach my $what_robber (@robbers) { 
            print "WITH ROBBER: $what_robber\n";
            #my $robber = $what_robber;
            for (my $repeat = 0; $repeat < $COUNT_REPEAT; $repeat++) {
                launch_one_exp($command_bots, $what_robber);
            }

            #my $command_robber = "$robber_david0";
            #for (my $repeat = 0; $repeat < $COUNT_REPEAT; $repeat++) { launch_one_exp($command_bots, $command_robber); }
            #my $command_robber = "$robber_david1";
            #for (my $repeat = 0; $repeat < $COUNT_REPEAT; $repeat++) { launch_one_exp($command_bots, $command_robber); }
        }
        print "END 1 ROUND (adding cops)\n";

    }
}
print "\n";


